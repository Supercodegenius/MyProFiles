﻿
using Microsoft.Practices.EnterpriseLibrary.Caching;
using System;
using System.Linq;
using XLCapital.XLRE.EDestiny.Common.BusinessEntity;
using XLCapital.XLRE.EDestiny.Common.Constants;
using XLCapital.XLRE.Framework.Cache;

namespace EMP.Caching
{
    public class CacheLoader
    {
        public static string RefreshCache()
        {
            //clear cache items
            ICacheManager cacheManager = CacheFactory.GetCacheManager();
            cacheManager.Flush();
            //reload
            XLCacheManager.Load();
            //PopulateBrokers();
            //PopulateCedants();
            //PopulateCedantLocations();
            //PopulateBrokerLocations();
            return Guid.NewGuid().ToString();
        }

        public static SecurityInfoBECollection GetSecurityInfo()
        {
            return XLCacheManager.GetItem<SecurityInfoBECollection>("Security");
        }

        public static SecurityInfoBECollection GetSecurityInfo(string argLoginName)
        {
            return XLCacheManager.GetItem<SecurityInfoBECollection>("Security", argLoginName);
        }

        public static UserPrincipalBE GetSecurityPrincipal(string argLoginName)
        {
            if (!string.IsNullOrEmpty(argLoginName))
            {
                SecurityInfoBECollection l_SecurityInfo = GetSecurityInfo();
                //l_SecurityInfo = GetSecurityInfo(argLoginName);
                if (l_SecurityInfo != null && l_SecurityInfo.Count > CommonXLConstants.C_INT_ZERO)
                {
                    var l_UserSecInfo = l_SecurityInfo.Where(q => q.UserPrincipalBE.LoginName == argLoginName).FirstOrDefault();
                    if (l_UserSecInfo != null)
                    {
                        return l_UserSecInfo.UserPrincipalBE;
                    }
                }
            }
            return null;
        }
    }
}