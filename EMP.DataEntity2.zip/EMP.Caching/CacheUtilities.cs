﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace EMP.Caching
{
    public static class CacheUtilities
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static T CopyObject<T>(this T t, object obj) where T : class
        {
            var targetProperties = typeof(T).GetProperties();
            foreach (var pro in targetProperties)
            {
                var val = GetPropertyValue<object, object>(obj, pro.Name);
                SetPropertyValue(t, pro.Name, val);
            }

            return t;
        }

        /// <summary>
        /// Set value for the given property of an entity
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <param name="value"></param>
        public static void SetPropertyValue<TEntity, TValue>(TEntity entity, string propertyName, TValue value)
        {
            var func = SetPropertyExpression<TValue>(entity.GetType(), propertyName);
            if (func != null)
            {
                func(entity, value);
            }
        }

        /// <summary>
        /// get the value of the given properyt from an entity
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static TValue GetPropertyValue<TEntity, TValue>(TEntity entity, string propertyName)
        {
            var func = GetPropertyExpression<TValue>(entity.GetType(), propertyName);
            if (func == null)
            {
                return default(TValue);
            }
            return func(entity);
        }


        #region private static utility methods

        /// <summary>
        /// get a compile property expression
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        private static Func<object, TValue> GetPropertyExpression<TValue>(Type tEntity, string propertyName)
        {
            var cacheKey = string.Format("{0}-get-{1}", tEntity.FullName, propertyName);
            Func<object, TValue> func = Caches.GetCacheItem(cacheKey) as Func<object, TValue>;

            if (func == null && tEntity.GetProperties().Any(p => p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase)))
            {
                ParameterExpression target = Expression.Parameter(typeof(object), "target");
                Expression expr = Expression.Property(Expression.Convert(target, tEntity), propertyName);

                if (expr.Type != typeof(TValue) && (expr.Type is TValue))
                {
                    expr = Expression.Convert(expr, typeof(TValue));
                }

                func = Expression.Lambda<Func<object, TValue>>(expr, target).Compile();
                Caches.SaveCacheItem(cacheKey, func);
            }
            return func;
        }

        /// <summary>
        /// get a compiled assignment expression
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static Action<object, TValue> SetPropertyExpression<TValue>(Type tEntity, string propertyName)
        {
            var cacheKey = string.Format("{0}-set-{1}", tEntity.FullName, propertyName);
            Action<object, TValue> func = Caches.GetCacheItem(cacheKey) as Action<object, TValue>;
            if (func == null && tEntity.GetProperties().Any(p => p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase)))
            {
                BinaryExpression assignExpr;
                ParameterExpression value = Expression.Parameter(typeof(TValue), "value");
                ParameterExpression target = Expression.Parameter(typeof(object), "target");
                Expression propertyExpr = Expression.Property(Expression.Convert(target, tEntity), propertyName);

                if (propertyExpr.Type.IsAssignableFrom(typeof(TValue)))
                {
                    assignExpr = Expression.Assign(propertyExpr, value);
                }
                else
                {
                    assignExpr = Expression.Assign(propertyExpr, Expression.Convert(value, propertyExpr.Type));
                }

                func = Expression.Lambda<Action<object, TValue>>(assignExpr, target, value).Compile();
                Caches.SaveCacheItem(cacheKey, func);
            }
            return func;
        }


        #endregion
    }
}
