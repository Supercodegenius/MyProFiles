﻿using Microsoft.Practices.EnterpriseLibrary.Caching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.Cache;

namespace EMP.Caching
{
    public class Caches
    {

        /// <summary>
        /// This function is used to get the item from cache using the key name.
        /// </summary>
        /// <param name="argKey">Name of the item to be retrieved from cache.</param>
        /// <returns>returns a generic collection of the cache items.</returns>
        public static object GetCacheItem(string argKey)
        {
            return GetCacheItem(argKey, null);
        }

        /// <summary>
        /// This function is used to get the item from cache using the key name.
        /// </summary>
        public static T GetCacheItem<T>(string argKey) where T : class
        {
            return GetCacheItem(argKey) as T;
        }

        /// <summary>
        /// This function is used to get the item from cache using the key name.
        /// </summary>
        /// <param name="key">Name of the item to be retrieved from cache.</param>
        /// <param name="filterDataValue">Name of the item to be retrieved from cache.</param>
        /// <returns>returns a generic collection of the cache items.</returns>
        public static object GetCacheItem(string key, string filterDataValue)
        {
            object cachedItem = null;
            var loaders = LoaderDefinitions.Current?.AvailableLoaders.ToList();
            if (loaders != null && loaders.Exists(x => x.Key == key))
            {
                cachedItem = XLCacheManager.GetItem(key, filterDataValue);
            }
            else
            {
                ICacheManager cacheManager = CacheFactory.GetCacheManager();
                if (cacheManager.Contains(key))
                {
                    cachedItem = cacheManager.GetData(key);
                }
            }
           
            //if (XLCacheManager.IsItemLoaded(key))
            //{
            //    if (string.IsNullOrEmpty(filterDataValue))
            //    {
            //        cachedItem = XLCacheManager.GetItem(key);
            //    }
            //    else
            //    {
            //        cachedItem = XLCacheManager.GetItem(key, filterDataValue);
            //    }
            //}
            return cachedItem;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public static void SaveCacheItem(string key, object value)
        {
            ICacheManager cacheManager = CacheFactory.GetCacheManager();
            if (cacheManager.Contains(key))
            {
                cacheManager.Remove(key);
            }
            cacheManager.Add(key, value);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public static void SaveCacheItem(string key, object value, params ICacheItemExpiration[] expirations)
        {
            ICacheManager cacheManager = CacheFactory.GetCacheManager();
            cacheManager.Add(key, value, CacheItemPriority.Normal, null, expirations);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool IsCacheItemLoaded(string key)
        {
            ICacheManager cacheManager = CacheFactory.GetCacheManager();

            return cacheManager.Contains(key);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool SaveCacheInMemory(string key,object value)
        {
            XLRuntimeCacheManager.Add(key, value);
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetCacheFromMemory(string key)
        {
            return XLRuntimeCacheManager.GetData(key) as string; 
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static void RemoveCacheFromMemory(string key)
        {
            if (XLRuntimeCacheManager.GetData(key) != null)
                XLRuntimeCacheManager.Remove(key);
        }
        // private static List<string> _logginCategory;
        //public static List<string> GetLoggingCategory()
        //{
        //    if (_logginCategory == null)
        //    {
        //        _logginCategory = GetSystemConstantsByGroup(SystemConstant.GroupGuid.C_LOGGING_CATEGORY)?.FindAll(ent => ent.ConstVal == "1")
        //            .Select(ent => ent.ConstDescription).ToList();

        //    }
        //    return _logginCategory;
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public static IRwbSystemConstantBE GetSystemConstantsByKey(int key)
        //{
        //    return GetSystemConstants()?.FirstOrDefault(ent => ent.ConstKey == key);
        //}
    }
}
