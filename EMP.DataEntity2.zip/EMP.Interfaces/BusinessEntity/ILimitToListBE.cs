﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface ILimitToListBE
    {
         int ? LimitToListValuesGuid { get; set; }

         int RMSFieldGuid { get; set; }

        string RMSFieldName { get; set; }
        int EMPSchemeGuid { get; set; }
        string EMPSchemeName { get; set; }
        string Description { get; set; }
        string LookUp { get; set; }
        string Code { get; set; }
        int ActiveInd { get; set; }
        int OrderNum { get; set; }
        bool BulkOption { get; set; }
        //string IFM2or4digitOcc { get; set; }
        string ISO2ACountryCode { get; set; }
    }
}
