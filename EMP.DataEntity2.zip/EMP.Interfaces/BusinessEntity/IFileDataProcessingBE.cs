﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IFileDataProcessingBE : IBaseDataEntity
    {
        int? FileDataProcessingGuid { get; set; }
        int? FileProcessingTaskGuid { get; set; }
        string SourceData { get; set; }
        string StageData { get; set; }         
        string ConvertedData { get; set; }

        string SelectedOccupancy { get; set; }

    }
}
