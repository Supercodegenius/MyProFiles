﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IFileProcessingTasksBE :IBaseDataEntity
    {
        int ? FileProcessingTaskGuid { get; set; }
        string SourceSheet { get; set; }
        int StatusGuid { get; set; }
        int CompletedInd { get; set; }

    }
}