﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IUsPostalCodeBE
    {
       int? PostCodeGuid { get; set; }      
       string StateCode { get; set; }       
       string ZipCode { get; set; }        
       string County { get; set; }
    }
}
