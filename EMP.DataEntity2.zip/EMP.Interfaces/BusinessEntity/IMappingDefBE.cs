﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IMappingDefBE:IBaseDataEntity
    {
        int? MappingDefGuid { get; set; }
        int OwnerGuid { get; set; }
        string SourceColumns { get; set; }
        string Name { get; set; }
    }
}
