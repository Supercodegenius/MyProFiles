﻿using EMP.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface ISOVtoRMSFieldsBE 
    {

      //[Column("description")]
       int? SOVFieldGUID { get; set; }
       int RMSFieldGUID { get; set; }
       string SOVFieldName { get; set; }
       string RMSFieldName { get; set; }
        string DescriptiveName { get; set; }
        string RMSDescription { get; set; }
        bool IsMostCommon { get; set; }
        bool IsRequired { get; set; }
        int Priority { get; set; }
        bool IsValueField { get; set; }
        bool IsPrimaryChar { get; set; }
        bool IsSecMods { get; set; }
        bool IsMappAvailable { get; set; }
        bool IsBulkCodeAvailable { get; set; }
        string RequiredOptionalOrBoth { get; set; }
        bool IsAdjustValue { get; set; }
        int orderNum { get; set; }
        bool IsTemporaryMapping { get; set; }
        bool IsLimitToList { get; set; }
        bool IsSecModByCntry { get; set; }
        string RMSFieldType { get; set; }
        bool IsKeyWordSearchAvailable { get; set; }
        BulkCodeItem BulkCodeItem { get; set; }
        string BulkOptionCode { get; set; }
        int ? Version { get; set; }
        int ? MappingCount { get; set; }
        string AddedBy { get; set; }
        string ModifyBy { get; set; }
        string AddedApp { get; set; }
        string ModifyApp { get; set; }
        Nullable<DateTime> ModifyDt { get; set; }
        Nullable<DateTime> AddedDt { get; set; }
    }
}