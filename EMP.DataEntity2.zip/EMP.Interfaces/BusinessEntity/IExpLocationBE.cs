﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using XLCapital.XLRE.Framework.BaseLibrary;
namespace EMP.Interfaces.BusinessEntity
{
    public interface IExpLocationBE : IBaseDataEntity
    {

    long? ProgramGuid{ get; set; }
    string LocNum { get; set; }
	string LocName { get; set; }
	string PrimaryBldg { get; set; }
	string SiteName { get; set; }
	string StreetName { get; set; }
	string District { get; set; } 
	string City { get; set; }
	string State { get; set; }
	string StateCode { get; set; }
	string PostalCode { get; set; }
	string County { get; set; }
	string Iso2aCountryCode { get; set; }
	string CountryScheme { get; set; }
	string CountryCode { get; set; }
	decimal ? Latitude { get; set; }
	decimal? Longitude { get; set; }
	decimal?  RmsLatitude { get; set; }
	decimal? RmsLongitude { get; set; }
	string RmsGeocodingResolution { get; set; }
	string Cresta { get; set; }
	string BldgScheme { get; set; }
	string BldgClass { get; set; }
	string C_Atc { get; set; }
	string C_Rms { get; set; }
	string C_Ifm_Description { get; set; }
	string OccScheme { get; set; }
	string OccType { get; set; }
	string O_Atc { get; set; }
	string O_Ifm_2_Digit { get; set; }
	string O_Ifm_4_Digit { get; set; }
	DateTime ? YearBuilt { get; set; }
	int ? FloorArea { get; set; }
	int?  NumStories { get; set; }
	string UserId1 { get; set; }
	string UserId2 { get; set; }
	string UserTxt1 { get; set; }
	string UserTxt2 { get; set; }
	string UserTxt3 { get; set; }
	string UserTxt4 { get; set; }
	string UserTxt5 { get; set; }
	string UserTxt6 { get; set; }
	string SiteCurrency { get; set; }
	decimal Cv1Val { get; set; }
	decimal Cv2Val { get; set; }
	string Cv2Cvm { get; set; }
	string Eqcv2Eqslg { get; set; }
	decimal Cv3Val { get; set; }
	//string Cv6Cvm { get; set; }
	//string Eqcv6Eqslg { get; set; }
	decimal Cv9Val { get; set; }
	string Cv9Cvm { get; set; }
	string Eqcv9Eqslg { get; set; }
	decimal TotalValue { get; set; }
	string StoryProf { get; set; }
    }
}
