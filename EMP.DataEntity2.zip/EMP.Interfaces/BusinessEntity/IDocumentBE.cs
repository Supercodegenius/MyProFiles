﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IDocumentBE:IBaseDataEntity
    {

        int ? DocGuid { get; set; }
        string Id { get; set; }

        string Type { get; set; }

        string OwnerType { get; set; }
        int OwnerGuid { get; set; }

        string Description { get;set; }

        int AppTypeGuid { get; set; }
        int DocTypeGuid { get; set; }
        string FileName { get; set; }
    }
}
