﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IGeneralMappingIssuesBE :IBaseDataEntity
    {
        int ? RMSFieldGUID { get; set; }
        string RMSFieldName { get; set; }
        string Description { get; set; }
    }
}
