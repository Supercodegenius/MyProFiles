﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace EMP.Interfaces.BusinessEntity
{
    public interface ISecurityPrincipalBE
    {
        bool? ActiveInd { get; set; }
        string BusRole { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string LoginName { get; set; }
        string MiddleInitial { get; set; }
        string PrincipalType { get; set; }
        string Title { get; set; }
        int? UserGuid { get; set; }
        string DisplayName { get; }
        string ReverseDisplayName { get; }
        List<string> Roles { get; set; }
    }
}
