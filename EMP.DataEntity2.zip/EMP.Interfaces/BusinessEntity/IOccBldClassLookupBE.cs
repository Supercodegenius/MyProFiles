﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IOccBldClassLookupBE 
    {

        int ? OccTypeBldClassLookupGuid { get; set; }
        int RMSFieldGuid { get; set; }
        string RMSFieldName { get; set; }
        int EMPSchemeGuid { get; set; }
        string EMPSchemeName { get; set; }
        string Description { get; set; }
        string LookUp { get; set; }
        string Code { get; set; }
        int OrderNum { get; set; }
        int BulkOption { get; set; }
        string ISO2ACountryCode { get; set; }
        string C_ATC { get; set; }
        string C_RMS { get; set; }
        string C_IFMDescription { get; set; }
        string O_ATC { get; set; }
        string O_IFM_2digit { get; set; }

        string O_IFM_4digit { get; set; }

        //int ActiveInd { get; set; }

    }
}
