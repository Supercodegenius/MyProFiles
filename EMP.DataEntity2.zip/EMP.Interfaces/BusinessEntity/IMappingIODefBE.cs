﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IMappingIODefBE:IBaseDataEntity
    {
        int? MappingLinkingDefGuid { get; set; }     
        int MappingDefGuid { get; set; }
        string FromFieldName { get; set; }
         string ToFieldName { get; set; }
         string BulkCodeValue { get; set; }
         string AdjustValue { get; set; }
        string KeyWordSearch { get; set; }
    }
}
