﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;

namespace EMP.Interfaces.BusinessEntity
{
    public interface IMappedSOVRMS
    {
        string FromFieldName { get; set; }
        string ToFieldName { get; set; }
        string BulkCodeValue { get; set; }
        string AdjustValue { get; set; }
        string SelectedOccupancy { get; set; }
        string FilteredValue { get; set; }
        int FileProcessingId { get; set; }
        string KeyWordSearch { get; set; }
        bool IsTemporaryMapping { get; set; }
        int? SOVFieldGuid { get; set; }
    }
}
