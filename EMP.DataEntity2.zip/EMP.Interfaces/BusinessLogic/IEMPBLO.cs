﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMP.Interfaces.BusinessEntity;

namespace EMP.Interfaces
{
    public interface IEMPBLO
    {  
        List<ISOVtoRMSFieldsBE> GetSovtoRMSFields(string fileType);

        List<ILimitToListBE> GetLimitToListValues();

        List<IOccBldClassLookupBE> GetOccBldClassValues();

        string UploadDocumentToDocumentum(string filePath);    
    }
}
