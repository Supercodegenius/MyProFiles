﻿#region revs/comments

/**********************************************************************************************************
 * Class Name               :   IUserCompany.cs
 * Description              :   This class represents the  User Company.
 * Modification Log         :
 * -------------------------------------------------------------------------------------------------------
 * Date (mm/dd/yyyy)        Author              Request No                          Description
 * -------------------------------------------------------------------------------------------------------
  *  * ********************************************************************************************************/
/**********************************************************************************************************
 *  07/15/2019              Manoj kumar         15705                       Created the Inital version
 *                                                                          during the start of Design
 *                                                                          phase.
 * *******************************************************************************************************/

#endregion revs/comments
namespace EMP.Interfaces
{
    public interface IUserCompany
    {
        int CompanyGuid { get; set; }

        string CompanyName { get; set; }

        bool IsReadOnly { get; set; }
    }
}