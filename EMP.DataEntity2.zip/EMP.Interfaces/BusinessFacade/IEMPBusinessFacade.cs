﻿using System.Collections.Generic;
using XLCapital.XLRE.EDestiny.Common.Cache.BusinessEntity;
using EMP.Interfaces.BusinessEntity;

namespace EMP.Interfaces
{
    public interface IEMPBusinessFacade
    {
        ISecurityManager SecurityManager { get; set; }
        LookupBECollection GetLookupItem(int argLookupGroup);       
        string UploadDocumentToDocumentum(string filePath);

        //List<ISOVtoRMSFieldsBE> GetSOVtoRMsFields();
    }
}
