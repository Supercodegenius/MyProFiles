﻿#region revs/comments

/**********************************************************************************************************
 * Class Name               :   ISecurityManager.cs
 * Description              :   This class represents the  Security Manager.
 * Modification Log         :
 * -------------------------------------------------------------------------------------------------------
 * Date (mm/dd/yyyy)        Author              Request No                          Description
 * -------------------------------------------------------------------------------------------------------
  *  * ********************************************************************************************************/
/**********************************************************************************************************
 *  06/04/2019              Manoj kumar         15868                       Created the Inital version
 *                                                                          during the start of Design
 *                                                                          phase.
 * *******************************************************************************************************/

#endregion revs/comments
using System.Collections.Generic;
using XLCapital.XLRE.EDestiny.Common.BusinessEntity;

namespace EMP.Interfaces
{
    public interface ISecurityManager
    {
        string UserId { get; set; }

        /// <summary>
        ///
        /// </summary>
        string UserDisplayName { get; }

        /// <summary>
        /// the system(OS) login user
        /// </summary>
        string LoginUserId { get; set; }

        /// <summary>
        ///
        /// </summary>
        UserPrincipalBE Principal { get; }

        List<string> Roles { get; }

        List<IUserCompany> UserCompanies { get; }
    }
}