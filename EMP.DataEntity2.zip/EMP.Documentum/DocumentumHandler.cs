﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLC.Destiny.Framework.ContentManagement.Adaptor;
using XLC.Destiny.Framework.ContentManagement.Core;
using XLC.Destiny.Framework.ContentManagement.Core.Utilities;

namespace EMP.Documentum
{
    public class EMPDocumentum
    {
        private static IXLContentManager EDMSAdaptor { get; set; }
        private static IXLContentManagerLight EDMSAdaptorLight { get; set; }
        private string EdmsEnvironment { get; set; }

        public EMPDocumentum()
        {
            EdmsEnvironment = ConfigurationManager.AppSettings.Get("EDMSEnvironment");
        }
        /// <summary>
        /// The function to save document details
        /// </summary>
        /// <param name="docPath"></param>
        /// <returns></returns>
        public string UploadDocument(string argFilePath)
        {
            EDMSAdaptor = XLContentMgmtAdaptor.GetService(EdmsEnvironment);
            IXLMetaData l_MetaData = new ContentMetaData();
            bool result = EDMSAdaptor.PutDocument(argFilePath, l_MetaData);

            return l_MetaData.GetAttributeValue(AttributeName.UFID);
        }

        public string GetDocument(string argDocumentID, string argFileSharedPath)
        {
            EDMSAdaptor = XLContentMgmtAdaptor.GetService(EdmsEnvironment);
            string l_ExtractLoc = null;

            IXLMetaData l_MetaData = new ContentMetaData();
            l_MetaData.SetAttributeProperties(AttributeName.UFID, argDocumentID, XLC.Destiny.Framework.ContentManagement.Core.Utilities.AttributeDirection.In);
            var l_TargetFolder = string.IsNullOrEmpty(argFileSharedPath) ? System.IO.Path.GetTempPath() : argFileSharedPath;
            EDMSAdaptor.GetDocument(l_TargetFolder, l_MetaData, out l_ExtractLoc);

            return l_ExtractLoc;
        }

        public string GetDocumentLink(string argDocumentID, string argFileSharedPath)
        {
            EDMSAdaptorLight = XLContentMgmtAdaptor.GetServiceLight(EdmsEnvironment);
            string l_ExtractLocc = null;
            l_ExtractLocc = EDMSAdaptorLight.GetDocumentLink(argDocumentID, null);
            return l_ExtractLocc;
        }
        public byte[] GetDocumentStream(string argDocumentID, string argFileSharedPath)
        {
            EDMSAdaptor = XLContentMgmtAdaptor.GetService(EdmsEnvironment);
            return EDMSAdaptor.GetDocumentStream(argDocumentID);

        }
    }
}