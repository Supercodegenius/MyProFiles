﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace EMP.ExceptionManagement
{
    public class EMPExceptionManager
    {

        public static void HandleException(Exception err)
        {
            HandleException(err, "ExceptionPolicy");
        }


        public static void HandleException(Exception err, string policyName)
        {
            ExceptionPolicy.HandleException(err, policyName);
        }

    }
}
