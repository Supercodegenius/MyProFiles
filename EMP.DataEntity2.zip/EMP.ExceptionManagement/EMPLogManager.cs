﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
//using Newtonsoft.Json;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.Utilities;

namespace EMP.ExceptionManagement
{
    public class EMPLogManager : XLTrace
    {

        //public static List<string> LogginCategory { get; set; }

        public static Func<string, string, bool> IsLoggingCategory;


        public void TrackPerformance(DateTime argStartTime, object argMessage, string argCatagory, params object[] argMethodParameters)
        {
            //if (LogginCategory != null && LogginCategory.Contains(argCatagory))
            if (IsLoggingCategory != null && IsLoggingCategory(argCatagory, string.Empty))
            {
                //var message = JsonConvert.SerializeObject(argMessage);
                //LogPerformanceTrace(argStartTime, message, argCatagory, argMethodParameters);
            }
        }

        public void TrackPerformance(DateTime argStartTime, string methodName, object[] argMessages, string argCatagory, params object[] argMethodParameters)
        {
            //if (LogginCategory != null && LogginCategory.Contains(argCatagory))
            if (IsLoggingCategory != null && IsLoggingCategory(argCatagory, methodName))
            {
                //var message = JsonConvert.SerializeObject(argMessages);
                //LogPerformanceTrace(argStartTime, message, argCatagory, argMethodParameters);
            }
        }

    }
}
