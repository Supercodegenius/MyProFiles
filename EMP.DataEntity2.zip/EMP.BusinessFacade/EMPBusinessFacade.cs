﻿using EMP.Interfaces;
using EMP.Interfaces.BusinessEntity;
using EMP.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.EDestiny.Common.Cache.BusinessEntity;
using XLCapital.XLRE.EDestiny.Common.Constants;
using XLCapital.XLRE.Framework.Communications;

namespace EMP.BusinessFacade
{
    public class EMPBusinessFacade:IEMPBusinessFacade 
    {

        #region "Variables"
        protected ISecurityManager m_SecurityManager;
        protected IEMPBLO _empBLO;
        private LookupGroupBECollection l_LookupGroupBECollection = null;
        
        #endregion

        #region constructor
        public EMPBusinessFacade(IEMPBLO empBLO)
        {
            _empBLO = empBLO;

        }
        #endregion

        #region "Public Method"
        public ISecurityManager SecurityManager
        {
            get
            {
                return m_SecurityManager;
            }
            set
            {
                m_SecurityManager = value;
                ServiceContext.Current.SetContext(Constants.C_MODIFY_APP,
                                m_SecurityManager.UserId,
                                string.Empty,
                                null);
            }
        }
       
        public LookupBECollection GetLookupItem(int argLookupGroup)
        {
            LookupBECollection l_LookupColl;
            LookupGroupBE l_LookupGroup;
            l_LookupGroup = null;
            l_LookupColl = null;
            l_LookupGroup = l_LookupGroupBECollection.GetLookupGroup(argLookupGroup);
            if (l_LookupGroup != null && l_LookupGroup.LookupBECol != null && l_LookupGroup.LookupBECol.Count > CommonXLConstants.C_INT_ZERO)
            {
                return l_LookupGroup.LookupBECol;
            }
            return l_LookupColl;
        }
        
        public string UploadDocumentToDocumentum(string filePath)
        {
            return _empBLO.UploadDocumentToDocumentum(filePath);
        }
        #endregion
    }
}
