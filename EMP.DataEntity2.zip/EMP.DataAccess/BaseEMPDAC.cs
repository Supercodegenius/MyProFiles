﻿/*************************************************************************************
 * 1. Class Name				: BaseUWWBDAC					
 * 2. Description				: This is the base class of Data Access classes
 * 3. Modification Log
 * Date 		  Author	       Request No		 Description     
 * 10/11/2019                         N/A                Created
*************************************************************************************/
using System;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.DataAccess
{
   public class BaseEMPDAC : BaseDataAccessComponent
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual void Read(SqlDatabase argSqlDatabase, string argSelectSQL, Action<IDataReader> argHanderMethod)
        {
            using (var reader = NewDataReader(argSqlDatabase, argSelectSQL, 0))
            {
                while (reader.Read())
                {
                    if (argHanderMethod != null)
                    {
                        argHanderMethod(reader);
                    }
                }
            }
        }
        public virtual void Read(SqlDatabase argSqlDatabase, string argSelectSQL, int timeOut, Action<IDataReader> argHanderMethod)
        {
            using (var reader = NewDataReader(argSqlDatabase, argSelectSQL, timeOut))
            {
                while (reader.Read())
                {
                    if (argHanderMethod != null)
                    {
                        argHanderMethod(reader);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual void ReadEntity<T>(IDataEntity argDataEntity, Action<T> argHanderMethod)
        {
            var sql = this.SqlGenerator.GetSelectStatement(argDataEntity);
            this.ReadEntity<T>(sql, argDataEntity, argHanderMethod);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual void ReadEntity<T>(string argSql, IDataEntity argDataEntity, Action<T> argHanderMethod)
        {
            var database = XLDatabaseManager.Current.GetSqlDatabase(argDataEntity.GetType());
            using (var reader = NewDataReader(database, argSql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    argHanderMethod(ent);
                });
            }
        }
    }
}
