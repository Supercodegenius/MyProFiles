﻿/*************************************************************************************
 * 1. Class Name				: EMPDAC					
 * 2. Description				: Data Access classes for EMP DB
 * 3. Modification Log
 * Date 		  Author	       Request No		 Description     
 * 10/11/2019     Suganya R             N/A                Created
 * 13/03/2020     Arun Rajappa          N/A               Added GetLocationDetails method.
*************************************************************************************/
using EMP.BusinessEntity;
using EMP.BusinessEntity.BulkInsert;
using EMP.Interfaces.BusinessEntity;
using EMP.Utilities;
using EMP.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.DataAccess
{
    public class EMPDAC : BaseEMPDAC
    {


        /// <summary>
        /// Get RMS Filters
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="lookupGroupGuid"></param>
        /// <returns></returns>
        public List<FileLobBE> GetFileLob<T>() where T : FileLobBE
        {
            //var result = new List<FileLobBE>();
            //string sql = @"SELECT lob_guid,lob_name FROM [dbo].[t_emt_lob] With (NOLOCK) where active_ind = 1 order by lob_guid asc";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<FileLobBE>)base.ExecuteStoredProcedure<FileLobBE>
                   (Constants.FileLobs, new object[] { }, 0);

        }

        /// <summary>
        /// Get RMS Filters
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public List<LookupBE> GetRMSFilters<T>(int lookupGroupGuid) where T : LookupBE
        {
            //var result = new List<LookupBE>();
            //string sql = @"SELECT lookups_guid,description,lookups_group_guid  FROM [dbo].[t_lookups] With (NOLOCK) where lookups_group_guid = '" + lookupGroupGuid + "' order by order_column_num asc";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<LookupBE>)base.ExecuteStoredProcedure<LookupBE>
                   (Constants.RmsFilters, new object[] { lookupGroupGuid }, 0);

        }
        /// <summary>
        /// Get SOV to RMS Fields mapping
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="argDataEntity"></param>
        /// <returns></returns>

        public List<ISOVtoRMSFieldsBE> GetSOVtoRMSFields<T>(string fileType) where T : ISOVtoRMSFieldsBE
        {


            //var result = new List<ISOVtoRMSFieldsBE>();
            //string sql = @"select SOV.sov_field_guid,RMS.rms_field_guid, ISNULL(SOV.sov_field_name,'') sov_field_name, RMS.rms_field_name,
            //                  short_name,rms.description,is_most_common_field,
            //                  case when '1'='" + fileType + @"' then ISNULL(mand.casualty,0)
            //                  when '5'= '" + fileType + @"' then ISNULL(mand.aviation,0)
            //                  when '2'= '" + fileType + @"' then ISNULL(mand.marine,0)
            //                  when '3'= '" + fileType + @"' then ISNULL(mand.property,0)
            //                  when '4'= '" + fileType + @"' then ISNULL(mand.surety,0) end as is_required_field,rms.data_type rmsfieldtype,
            //                  is_value_field,is_primary_characteristics_field,is_secondary_mods,SOV.[Priority],is_bulk_option_available,
            //                  case when '1'='" + fileType + @"' then case when ISNULL(mand.casualty,0)=1 then 'R' else 'O' end
            //                  when '5'='" + fileType + @"' then  case when ISNULL(mand.aviation,0)=1 then 'R' else 'O' end
            //                  when '2'='" + fileType + @"' then  case when ISNULL(mand.marine,0)=1 then 'R' else 'O' end
            //                  when '3'='" + fileType + @"' then  case when ISNULL(mand.property,0)=1 then 'R' else 'O' end
            //                  when '4'='" + fileType + @"' then  case when ISNULL(mand.surety,0)=1 then 'R' else 'O' end end as req_optional
            //                  ,[ORDER],is_adjust_value,is_limitto_list,is_secondary_mods_bycntry,is_keyword_search, 
            //                  is_temporary_mapping, SOV.[version] as version,ISNULL(mapping_count, 0) AS mapping_count,SOV.added_dt,SOV.added_app, 
            //                  SOV.added_by,SOV.modify_by,SOV.modify_app, SOV.modify_dt into #t1 from t_emp_sov_fields as SOV With (NOLOCK)
            //                  inner join  t_emp_rms_fields as RMS With (NOLOCK)
            //                  on SOV.rms_field_guid = RMs.rms_field_guid 
            //                  inner join [t_emt_lob_fields] as lob on RMs.rms_field_guid=lob.rms_field_guid
            //                  left join t_xpo_rms_upload_mand mand on	RMS.rms_field_name=mand.rms_field_name
            //                  where RMs.is_rms_column = 1 	
            //                   and lob.lob_guid=" + fileType + @"
            //order by [ORDER],rms_field_name,[Priority];
            //                  select max(mapping_count) as mapping_count, sov_field_name into #t2 from #t1 group by sov_field_name;
            //                  select t1.* from #t1 t1 inner join #t2 t2 on t2.sov_field_name = t1.sov_field_name and t2.mapping_count = t1.mapping_count order by [ORDER],rms_field_name,[Priority]; ";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;
            var sOVtoRMSFieldBE = (List<SOVtoRMSFieldBE>)base.ExecuteStoredProcedure<SOVtoRMSFieldBE>
                   (Constants.SOVtoRMSFields, new object[] { fileType }, 0);
            List<ISOVtoRMSFieldsBE> sOVtoRMSFields = new List<ISOVtoRMSFieldsBE>(sOVtoRMSFieldBE);
            return sOVtoRMSFields;
        }

        /// <summary>
        /// Get list of limittolist values
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="argDataEntity"></param>
        /// <returns></returns>

        public List<ILimitToListBE> GetLimitToListValues<T>() where T : ILimitToListBE
        {
            //var result = new List<ILimitToListBE>();
            //string sql = @"select  lm.emp_limit_to_list_values_guid,lm.rms_field_guid,rms.rms_field_name,
            //               lm.emp_scheme_guid,lk.description schemename,lm.Lookup,lm.description,lm.Code,
            //               lm.order_num,bulk_option,ISO2ACountryCode from t_emp_limit_to_list_values lm  With (NOLOCK) 
            //               left join t_emp_rms_fields rms With (NOLOCK) on lm.rms_field_guid=rms.rms_field_guid
            //               left join t_lookups lk With (NOLOCK) on lm.emp_scheme_guid=lk.lookups_guid ";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            var limitToListBE = (List<LimitToListBE>)base.ExecuteStoredProcedure<LimitToListBE>
                     (Constants.LimitToListValues, new object[] { }, 0);
            List<ILimitToListBE> limitToListBEs = new List<ILimitToListBE>(limitToListBE);
            return limitToListBEs;

        }

        /// <summary>
        /// Get List of OccBldg class
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public List<IOccBldClassLookupBE> GetOccBldClassValues<T>() where T : IOccBldClassLookupBE
        {
            //var result = new List<IOccBldClassLookupBE>();
            //string sql = @"select occ.emp_bldgclass_occtype_lookup_guid,occ.rms_field_guid,rms.rms_field_name,
            //               occ.emp_scheme_guid,lk.description schemename,occ.Lookup,occ.description,occ.Code ,
            //               occ.order_num,bulk_option,occ.C_ATC,occ.C_RMS,occ.C_IFMDescription,occ.O_ATC,
            //               occ.O_IFM_2digit,occ.O_IFM_4digit,occ.ISO2ACountryCode from t_emp_bldgclass_occtype_lookup occ With (NOLOCK) 
            //               left join t_emp_rms_fields rms With (NOLOCK) on occ.rms_field_guid=rms.rms_field_guid
            //               left join t_lookups lk With (NOLOCK) on occ.emp_scheme_guid=lk.lookups_guid ";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            var occBldClassLookups = (List<OccBldClassLookupBE>)base.ExecuteStoredProcedure<OccBldClassLookupBE>
                  (Constants.OccBldClassValues, new object[] { }, 0);
            List<IOccBldClassLookupBE> occBldClassLookupLists = new List<IOccBldClassLookupBE>(occBldClassLookups);
            return occBldClassLookupLists;


        }

        /// <summary>
        /// Getting Secondary Mod Lookups
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<SecModLookupBE> GetSecModLookups<T>() where T : SecModLookupBE
        {
            //var result = new List<SecModLookupBE>();
            //string sql = @"select rms.rms_field_guid,rms.rms_field_name,code,secmod.iso2a_countrycode,secmod.emp_scheme_guid,
            //               lk.description schemeName,limit.description,limit.Lookup,rms.is_secondary_mods,limit.order_num,
            //               limit.bulk_option from t_emp_secmod_cntryscheme_mapping secmod With (NOLOCK)
            //         join t_emp_limit_to_list_values limit With (NOLOCK) on limit.rms_field_guid=secmod.rms_field_guid and limit.emp_scheme_guid=secmod.emp_scheme_guid
            //         left join t_emp_rms_fields rms With (NOLOCK) on rms.rms_field_guid=limit.rms_field_guid 
            //         left join t_lookups lk With (NOLOCK) on limit.emp_scheme_guid=lk.lookups_guid
            //      where secmod.emp_scheme_guid is not null";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<SecModLookupBE>)base.ExecuteStoredProcedure<SecModLookupBE>
                (Constants.SecModLookups, new object[] { }, 0);
        }

        /// <summary>
        /// Getting County by state and postal or zip code
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public List<IUsPostalCodeBE> GetCountyByStateandPostalCode<T>() where T : IUsPostalCodeBE
        {
            var result = new List<IUsPostalCodeBE>();
            string sql = @" select t_emp_us_postcodes_guid, StateCode, ZipCode,County from  t_emp_us_postcodes With (NOLOCK) ";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }

        /// <summary>
        /// Getting carribean countries list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<LookUpCBCountriesBE> GetCBCountries<T>() where T : LookUpCBCountriesBE
        {
            var result = new List<LookUpCBCountriesBE>();
            string sql = @" select t_emp_lkup_cbcountries_guid,ISO2ACountryCode,Country from t_emp_lookup_caribbeancountries With (NOLOCK) ";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }

        /// <summary>
        /// Getting Mapped SOVtoRMS Mapping
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public List<MapSOVRMSBE> GetMappedSOVtoRMSFileds<T>(int fileProcessingTaskGuid, int programFileGuid) where T : MapSOVRMSBE
        {
            //var result = new List<MapSOVRMSBE>();
            //string sql = @"select sov_field_guid, from_field_name,to_field_name,bulk_load_value,bulk_code_item, adjust_value,occupancy,
            //               filtervalue,owner_guid,keyword_search_value from t_emp_mapping_io_linkingdef as tmapiolink With (NOLOCK) inner join  t_emp_mappingdef as tmapdef With (NOLOCK) on " +
            //               "tmapiolink.emp_mappingdef_guid = tmapdef.emp_mappingdef_guid inner join t_emp_fileprocessing_tasks filetasks With (NOLOCK) on" +
            //               " filetasks.emp_fileprocessing_task_guid = tmapdef.owner_guid where" +
            //               " owner_guid =" + fileProcessingTaskGuid + " AND tmapdef.program_file_guid =" + programFileGuid + " order by filetasks.added_dt desc";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<MapSOVRMSBE>)base.ExecuteStoredProcedure<MapSOVRMSBE>
                    (Constants.MappedSOVtoRMSFileds, new object[] { fileProcessingTaskGuid, programFileGuid }, 0);

        }

        /// <summary>
        /// Getting Mapped SOVtoRMS Data For Final RMS Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<MapSOVRMSBE> GetSovToRMSMappedData<T>(int fileProcessingTaskGuid, int programFileGuid) where T : MapSOVRMSBE
        {
            //var result = new List<MapSOVRMSBE>();
            //string sql = @"Select from_field_name,to_field_name,bulk_load_value,bulk_code_item,sov_field_guid, adjust_value,occupancy,filtervalue,owner_guid,keyword_search_value from t_emp_mapping_io_linkingdef as tmapiolink With (NOLOCK) inner join  t_emp_mappingdef as tmapdef With (NOLOCK) on " +
            //            "tmapiolink.emp_mappingdef_guid = tmapdef.emp_mappingdef_guid inner join t_emp_fileprocessing_tasks filetasks With (NOLOCK) on" +
            //            " filetasks.emp_fileprocessing_task_guid = tmapdef.owner_guid " +
            //            "where owner_guid =" + fileProcessingTaskGuid + " AND tmapdef.program_file_guid =" + programFileGuid + " AND (from_field_name is not null OR bulk_load_value is Not null OR keyword_search_value = 'true') order by filetasks.added_dt desc";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<MapSOVRMSBE>)base.ExecuteStoredProcedure<MapSOVRMSBE>
                   (Constants.SovToRMSMappedData, new object[] { fileProcessingTaskGuid, programFileGuid }, 0);
        }


        /// <summary>
        /// Getting IFM Coutry countries list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<IFMRegionCntryMappingBE> GetIFMCountryMapping<T>() where T : IFMRegionCntryMappingBE
        {
            var result = new List<IFMRegionCntryMappingBE>();
            string sql = @" select distinct iso2acountrycode ISO2ACountryCode,bld.ifm_occdesc ifm_occdesc,ifm_2or4digit,
                            value code From[t_emp_ifm_regioncntry_mapping] ifmcntry With (NOLOCK)
                            left join[t_emp_ifmdesc_details] bld With (NOLOCK) on ifmcntry.emp_ifm_occdesc_guid= bld.emp_ifm_occdesc_guid
                            order by bld.ifm_occdesc ";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }

        /// <summary>
        /// Get Country Lookup
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<CountryLookupBE> GetCountryLookup<T>() where T : CountryLookupBE
        {
            var result = new List<CountryLookupBE>();
            string sql = @"SELECT [emp_cntry_lookup_guid],[Country],[ISO2A],[ISO3A],[ISO3N],[FIPS],[RMS_Code],[FIRE_construction_allowed] FROM [dbo].[t_emp_cntry_lookup] With (NOLOCK)";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }


        /// <summary>
        /// Delete SOVToRMS Mapping
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public int DeleteMappDef(int fileProcessingTaskGuid)
        {
            // int result = 0;
            // string sql = @" delete from t_emp_mappingdef where owner_guid =" + fileProcessingTaskGuid + ";" +
            // "delete from t_emp_mapping_io_linkingdef where emp_mappingdef_guid in ( " +
            // "Select  tmapiolink.emp_mappingdef_guid from t_emp_mapping_io_linkingdef as tmapiolink With (NOLOCK) inner join  t_emp_mappingdef as tmapdef With (NOLOCK) on " +
            //"tmapiolink.emp_mappingdef_guid = tmapdef.emp_mappingdef_guid where owner_guid = " + fileProcessingTaskGuid + ")";
            // var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            // result = Delete(sql);
            // return result;

            base.ExecuteStoredProcedure<int>(Constants.DeleteMappingDef, new object[] {
                fileProcessingTaskGuid
            }
                    , argCustomTimeOut: 0);
            return 1;
        }

        /// <summary>
        /// Update SOVToRMS Mapping
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public int UpdateMappDef(int programGuid, int fileProcessingTaskGuid)
        {
            //int result = 0;
            //string sql = @" update t_emp_mapping_io_linkingdef set active_ind = 0 where emp_mappingdef_guid not in (select emp_mappingdef_guid  from t_emp_mappingdef With (NOLOCK) where owner_guid = " + fileProcessingTaskGuid + ") and active_ind = 1 and program_guid = " + programGuid;
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //result = Update(sql);
            //return result;

            base.ExecuteStoredProcedure<int>(Constants.UpdateMappingDef, new object[] {
                fileProcessingTaskGuid, programGuid
            }
                 , argCustomTimeOut: 0);
            return 1;
        }


        /// <summary>
        /// Delete SOVToRMS data
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public int DeleteSOVRMSData(int fileProcessingTaskGuid)
        {
            //int result = 0;
            //string sql = @"delete from t_emt_insurance_stage where emp_fileprocessingtask_guid=" + fileProcessingTaskGuid + " and deleted_ind = 0";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //result = Delete(sql);
            //return result;
            base.ExecuteStoredProcedure<int>(Constants.DeleteSOVRMSData, new object[] {
                fileProcessingTaskGuid
            }
                , argCustomTimeOut: 0);
            return 1;
        }


        /// <summary>
        /// Delete SOVToRMS data
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>

        public int DeleteSOVRMSDataByProgramGuid(int programGuid, int deletedIndicator)
        {
            //int result = 0;
            //string sql = @"UPDATE t_emt_insurance_stage SET deleted_ind = " + deletedIndicator + " WHERE ProgramGuid=" + programGuid + " ";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //result = Delete(sql);
            //return result;

            base.ExecuteStoredProcedure<int>(Constants.DeleteSOVRMSData, new object[] {
                programGuid, deletedIndicator
            }
             , argCustomTimeOut: 0);
            return 1;
        }

        /// <summary>
        /// Get Location Details
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public DataTable GetLocationDetails(int programGuid, string[] sovColumns)
        {
            string sovMappingCols = string.Join(", rms.", sovColumns);
            //REPLACE RMS COLUMNS TO LOCATION COLUMNS
            sovMappingCols = sovMappingCols.Replace("rms.STREETNAME", "loc.street_name AS STREETNAME");
            sovMappingCols = sovMappingCols.Replace("rms.CITY", "loc.city AS CITY");
            sovMappingCols = sovMappingCols.Replace("rms.STATECODE", "loc.state_code AS STATECODE");
            sovMappingCols = sovMappingCols.Replace("rms.STATE", "loc.state AS STATE");
            sovMappingCols = sovMappingCols.Replace("rms.POSTALCODE", "loc.postal_code AS POSTALCODE");
            sovMappingCols = sovMappingCols.Replace("rms.COUNTY", "loc.county AS COUNTY");
            sovMappingCols = sovMappingCols.Replace("rms.DISTRICT", "loc.district AS DISTRICT");
            sovMappingCols = sovMappingCols.Replace("rms.CNTRYSCHEME", "loc.country_scheme AS CNTRYSCHEME");
            sovMappingCols = sovMappingCols.Replace("rms.RMS_LATITUDE", "loc.RMS_LATITUDE");
            sovMappingCols = sovMappingCols.Replace("rms.RMS_LONGITUDE", "loc.RMS_LONGITUDE");
            sovMappingCols = sovMappingCols.Replace("rms.RMS_GEOCODING_RESOLUTION", "loc.RMS_GEOCODING_RESOLUTION");
            sovMappingCols = sovMappingCols.Replace("rms.ISO2ACOUNTRYCODE", "loc.iso2a_country_code AS ISO2ACOUNTRYCODE");
            sovMappingCols = sovMappingCols.Replace("rms.CRESTA", "loc.cresta AS CRESTA");

            string sql = @"SELECT " + sovMappingCols + " FROM t_emp_converted_rms rms WITH (NOLOCK) INNER JOIN t_exp_location loc WITH (NOLOCK) ON rms.LOCNUM = loc.loc_num AND rms.ProgramGuid = loc.program_guid where rms.deleted_ind = 0 and rms.PROGRAMGUID = " + programGuid + " order by rms.ID asc";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            SqlCommand command = new SqlCommand(sql);
            DataSet ds;
            DataTable dt = new DataTable();
            ds = database.ExecuteDataSet(command);
            if (ds != null && ds.Tables.Count > 0)
            {
                dt = ds.Tables[0];
            }

            return dt;
        }


        /// <summary>
        /// Perform Auto Match.
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int PerformAutomatch(int fileProcessingTaskGuid, string aLoginUserId, bool preClean)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.AutoMatch, new object[] {
                fileProcessingTaskGuid,
                aLoginUserId,
                DateTime.Now,
                preClean
            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;
            }
            return -1; // Failure
        }

        /// <summary>
        /// Perform Marine Auto Match.
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int PerformMarineAutomatch(int fileProcessingTaskGuid, string aLoginUserId)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.MarineAutoMatch, new object[] {
                fileProcessingTaskGuid,
                aLoginUserId,
                DateTime.Now

            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;
            }
            return -1; // Failure
        }

        /// <summary>
        /// Returns name match status
        /// </summary>
        /// <param name="fileProcessingGuid"></param>
        /// <returns></returns>

        public int GetNameMatchStatus(int fileProcessingGuid)
        {
            object fileStatus = ExecuteScalar("select [file_status] from [dbo].[t_doc] where [owner_guid]=" + fileProcessingGuid);
            return Convert.ToInt32(fileStatus);  // Success
        }

        /// <summary>
        /// Save Location Details
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public void SaveLocationDetails(int fileProcessingTaskGuid)
        {

            string sql = @" DELETE FROM  t_emp_converted_rms WHERE  deleted_ind = 1 AND ProgramGuid = " + fileProcessingTaskGuid + ";" +
                "delete from t_exp_location where program_guid = " + fileProcessingTaskGuid + ";" +
                "Insert into t_exp_location([program_guid],[loc_num],[loc_name],[primary_bldg],[site_name],[street_name],[district],[city],[state]," +
                "[state_code],[postal_code],[county],[iso2a_country_code],[country_scheme],[country_code],[latitude],[longitude],[rms_latitude]," +
                "[rms_longitude],[rms_geocoding_resolution],[cresta],[bldg_scheme],[bldg_class],[c_atc],[c_rms],[c_ifm_description],[occ_scheme]," +
                "[occ_type],[o_atc],[o_ifm_2_digit],[o_ifm_4_digit],[year_built],[floor_area],[num_stories],[user_id1],[user_id2],[user_txt1]," +
                "[user_txt2],[user_txt3],[user_txt4],[user_txt5],[user_txt6],[site_currency],[cv1_val],[cv2_val],[cv2_cvm],[eqcv2_eqslg]," +
                "[cv3_val],[cv6_cvm],[eqcv6_eqslg],[cv9_val],[cv9_cvm],[eqcv9_eqslg],[total_value],[story_prof],[added_by],[added_app]," +
                "[modify_by],[modify_app],[added_dt],[modify_dt],[version]) select PROGRAMGUID, LOCNUM, LOCNAME, PRIMARYBLDG, SITENAME, " +
                "STREETNAME, DISTRICT, CITY,[STATE], STATECODE, POSTALCODE,COUNTY, ISO2ACountryCode, CNTRYSCHEME, CNTRYCODE, LATITUDE, LONGITUDE," +
                "[RMS_LATITUDE],[RMS_LONGITUDE],[RMS_Geocoding_Resolution],CRESTA, BLDGSCHEME, BLDGCLASS, C_ATC, C_RMS, C_IFMDescription, OCCSCHEME, " +
                "OCCTYPE, O_ATC,[O_IFM_2_digit],[O_IFM_4_digit],YEARBUILT, FLOORAREA, NUMSTORIES, USERID1, USERID2, USERTXT1, USERTXT2, USERTXT3," +
                "USERTXT4, USERTXT5, USERTXT6,SITECURRENCY, CV1VAL, CV2VAL, CV2CVM, EQCV2EQSLG, CV3VAL, CV6CVM, EQCV6EQSLG, CV9VAL, CV9CVM, EQCV9EQSLG, TOTALVALUE," +
                "STORYPROF, added_by, added_app, modify_by, modify_app, added_dt, modify_dt, 1 from t_emp_converted_rms where PROGRAMGUID = " + fileProcessingTaskGuid + " and deleted_ind = 0";

            XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            ExecuteScalar(sql);
        }


        /// <summary>
        /// Getting default mapping fields
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public List<DefaultMappingFieldsBE> GetDefaultMappingFields<T>() where T : DefaultMappingFieldsBE
        {
            var result = new List<DefaultMappingFieldsBE>();
            string sql = @" select emp_default_mapping_fields_guid,rms_field_guid,rms_field_name,[order] As FieldOrder,data_type,default_value 
                            from t_emp_default_mapping_fields With (NOLOCK) where active_ind = 1 ";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }

        /// <summary>
        /// Get RMS Data
        /// </summary>
        /// <param name="programGuid"></param>
        /// <param name="columns"></param>
        /// <returns></returns>

        public DataTable GetRMSData(int programGuid, string columns)
        {
            string sql;
            sql = @"SELECT " + columns + " FROM t_emt_insurance_stage With (NOLOCK) where PROGRAMGUID = " + programGuid + " and deleted_ind = 0";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            var reader = NewDataReader(database, sql, 0);
            var dtRMSData = new DataTable();
            dtRMSData.Load(reader);
            return dtRMSData;

            //DataTable rmsData = new DataTable();
            //var result =  (List<dynamic>)base.ExecuteStoredProcedure<dynamic>
            //      (Constants.GetRMSData, new object[] { columns, Convert.ToString(programGuid) }, 0);
            //rmsData = ToDataTable(result);
            //return rmsData;

        }

        /// <summary>
        /// Get Final Preview Data
        /// </summary>
        /// <param name="programGuid"></param>
        /// <param name="columns"></param>
        /// <returns></returns>

        public DataTable GetFinalPreviewData(int programGuid, string columns)
        {

            string sql;
            sql = @"SELECT top(1000) " + columns + " FROM t_emt_insurance_stage With (NOLOCK) where PROGRAMGUID = " + programGuid + " and deleted_ind = 0";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            var reader = NewDataReader(database, sql, 0);
            var dtRMSData = new DataTable();
            dtRMSData.Load(reader);
            return dtRMSData;

            //DataTable rmsData = new DataTable();
            //var result = base.ExecuteStoredProcedure<Array>
            //      (Constants.GetFinalPreviewData, new object[] { columns, Convert.ToString(programGuid) }, 0);
            //rmsData = ToDataTable(result);
            //return rmsData;
        }

        /// <summary>
        /// Get Matching Data
        /// </summary>
        /// <param name="programGuid"></param>
        /// <param name="columns"></param>
        /// <returns></returns>

        public DataTable GetMatchedData(int programGuid, string columns)
        {

            string colFormated = string.Empty;
            foreach (string col in columns.Split(','))
            {
                colFormated += "t_stage." + col + ",";
            }
            if (colFormated != string.Empty)
            {
                colFormated += "t_stage.row_match_status as MATCHSTATUS";
            }

            string sql = @"SELECT " + colFormated + " FROM t_emt_insurance_stage t_stage With(NOLOCK) " +
                  //"LEFT OUTER JOIN t_xpo_upload_error t_upload With(NOLOCK)" +
                  //" ON ISNULL(t_stage.emp_fileprocessingtask_guid,0) = ISNULL(t_upload.emt_spreadsheet_guid, 0)" +
                  //" AND ISNULL(t_stage.emt_insurance_guid,0) = ISNULL(t_upload.emt_insurance_guid, 0)" +
                  " where t_stage.PROGRAMGUID = " + programGuid + " and t_stage.deleted_ind = 0 " +
                  " order by t_stage.emt_insurance_guid";
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            var reader = NewDataReader(database, sql, 0);
            var dtRMSData = new DataTable();
            dtRMSData.Load(reader);
            return dtRMSData;

            //DataTable rmsData = new DataTable();
            //var matchData = (List<dynamic>)base.ExecuteStoredProcedure<dynamic>
            //     (Constants.GetMatchedData, new object[] { colFormated, Convert.ToString(programGuid) }, 0);
            //rmsData = ToDataTable(matchData);
            //return rmsData;
        }

        /// <summary>
        /// Update Location Details
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>

        public void UpdateLocationDetails(int programGuid)
        {
            string sql = @"Delete from t_emt_insurance_stage  where emp_fileprocessingtask_guid = " + programGuid + ";delete from [dbo].[t_doc] where [owner_guid]=" + programGuid;
            XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            ExecuteScalar(sql);
        }

        /// <summary>
        /// Delete OccupancySearch List Data
        /// </summary>
        /// <param name="programFileGuid"></param>
        /// <returns></returns>

        public int DeleteOccKeySearch(int programFileGuid)
        {

            string sql = @"delete from t_emp_occupancy_keyword_search where program_file_guid=" + programFileGuid;
            XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            return Delete(sql);

        }

        /// <summary>
        /// Get OccupancySearch List Data
        /// </summary>
        /// <param name="programFileGuid"></param>
        /// <returns></returns>

        public List<OccKeyWordSearchBE> GetOccupancySearchList<T>(int programFileGuid) where T : OccKeyWordSearchBE
        {
            var result = new List<OccKeyWordSearchBE>();
            string sql = @"select sov_field_name,bulk_code_item,priority,keyword_search,is_use_flag 
                        from t_emp_occupancy_keyword_search With (NOLOCK) where program_file_guid =" + programFileGuid;
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            return result;
        }

        /// <summary>
        /// Get Value Type RMS Fields
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>

        public List<SOVtoRMSFieldBE> GetValueRMSFields<T>() where T : SOVtoRMSFieldBE
        {
            //var result = new List<SOVtoRMSFieldBE>();
            //string sql = @"SELECT RMS.rms_field_guid, RMS.rms_field_name,short_name,rms.description,is_most_common_field,is_required_field,rms.data_type rmsfieldtype,
            //               is_value_field,is_primary_characteristics_field,is_secondary_mods,is_bulk_option_available,req_optional,[ORDER],
            //               is_adjust_value,is_limitto_list,is_secondary_mods_bycntry,is_keyword_search FROM
            //               (select *, ROW_NUMBER() OVER (PARTITION BY rms_field_name order by [order]) rownumber from t_emp_rms_fields With (NOLOCK) where rms_field_name = 'CV1VAL' OR rms_field_name = 'CV2VAL' OR rms_field_name = 'CV3VAL' OR rms_field_name = 'CV9VAL')
            //               AS RMS WHERE RMS.rownumber = 1 order by rms_field_name asc";

            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<SOVtoRMSFieldBE>)base.ExecuteStoredProcedure<SOVtoRMSFieldBE>
                   (Constants.ValueRMSFields, new object[] { }, 0);
        }


        /// <summary>
        /// Get All RMS Columns
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>

        public List<SOVRMSMappedColumnsBE> GetSOVRMSMappedColumns<T>(int programGuid, string fileType) where T : SOVRMSMappedColumnsBE
        {
            //var result = new List<SOVRMSMappedColumnsBE>();
            //string getExcelColsql = "select distinct to_field_name from t_emp_mapping_io_linkingdef def With (NOLOCK) where active_ind = 1 and program_guid = " + programGuid + " and (from_field_name is not null or bulk_load_value is not null or keyword_search_value = 'true')";
            //string sql = @"select replace(rms.rms_field_name,' ','') as rms_field_name,rms.filter_type,rms.rms_field_guid,rms.[order] as field_order from (" + getExcelColsql +
            //   ") colresult" +
            //    " inner join t_emp_rms_fields rms With (NOLOCK) on colresult.to_field_name = rms.rms_field_name AND rms.rms_field_name <> 'CVPDVAL' " +
            //    "inner join t_emt_lob_fields lob With (NOLOCK) on rms.rms_field_guid=lob.rms_field_guid" +
            //    " where lob.lob_guid=" + fileType + " order by rms.[order], rms.[rms_field_guid] asc";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<SOVRMSMappedColumnsBE>)base.ExecuteStoredProcedure<SOVRMSMappedColumnsBE>
                   (Constants.SOVRMSMappedColumns, new object[] { programGuid, fileType }, 0);
        }

        /// <summary>
        /// Get rms converted data for the given ProgramGuid
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>

        public bool GetConvertedRMS<T>(int programGuid) where T : RMSConvertedDataBE
        {
            bool valueResult = false;
            var result = new List<RMSConvertedDataBE>();
            string sql = @"select * from [dbo].[t_emt_insurance_stage] With (NOLOCK) where PROGRAMGUID =" + programGuid;
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (var reader = NewDataReader(database, sql, 0))
            {
                FetchDataEntity<T>(reader, ent =>
                {
                    result.Add(ent);
                });
            }
            if (result != null && result.Count > 0)
            {
                valueResult = true;
            }
            return valueResult;
        }

        #region Bulk Insert EMP Converted Location

        /// <summary>
        /// Bulk Insert of EmpConvertedR Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <param name="aLoginUserId"></param> 
        /// <returns></returns>

        public void BulkInsertConvertedRMS(List<RMSConvertedDataBE> aRmsConvertedDataBE, string aLoginUserId)
        {
            object locLocker = new object();
            int empConvertedRMSGuid = GenerateGuid(new RMSConvertedDataBE().GetPrimaryKeyID(), aRmsConvertedDataBE.Count);
            aRmsConvertedDataBE.ForEach(elem =>
            {
                lock (locLocker)
                {
                    elem.emt_insurance_guid = empConvertedRMSGuid++;
                }
                elem.AddedBy = aLoginUserId;
                elem.AddedApp = Constants.C_MODIFY_APP;
                elem.AddedDt = DateTime.Now;
                elem.ModifyBy = aLoginUserId;
                elem.ModifyApp = Constants.C_MODIFY_APP;
                elem.ModifyDt = DateTime.Now;
            });

            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                EMPConvertedLocationDataReader empConvertedLocationDataReader = new EMPConvertedLocationDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.C_EMP_CONVERTED_RMS_TABLE_NAME);
                this.BulkInsertData(empConvertedLocationDataReader);
            }

        }


        /// <summary>
        /// Bulk Insert of EmpConvertedRMS Data
        /// </summary>
        /// <param name="aDataReader"></param>        
        /// <param name="aSQLConnection"></param>
        /// <returns></returns>

        private void BulkInsertData(EMPConvertedLocationDataReader aDataReader)
        {

            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(database.ConnectionString,
                SqlBulkCopyOptions.KeepIdentity | SqlBulkCopyOptions.UseInternalTransaction))
            {
                try
                {

                    aDataReader.CreateBulkCopyMappings(sqlBulkCopy);
                    sqlBulkCopy.DestinationTableName = aDataReader.TableName;
                    sqlBulkCopy.BulkCopyTimeout = DatabaseConnnections.C_LONG_QUERY_TIMEOUT;
                    sqlBulkCopy.WriteToServer(aDataReader);
                }
                catch (SqlException ex)
                {
                    if (ex.Message.Contains("Received an invalid column length from the bcp client for colid"))
                    {
                        string pattern = @"\d+";
                        Match match = Regex.Match(ex.Message.ToString(), pattern);
                        var index = Convert.ToInt32(match.Value) - 1;

                        FieldInfo fi = typeof(SqlBulkCopy).GetField("_sortedColumnMappings", BindingFlags.NonPublic | BindingFlags.Instance);
                        var sortedColumns = fi.GetValue(sqlBulkCopy);
                        var items = (Object[])sortedColumns.GetType().GetField("_items", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(sortedColumns);

                        FieldInfo itemdata = items[index].GetType().GetField("_metadata", BindingFlags.NonPublic | BindingFlags.Instance);
                        var metadata = itemdata.GetValue(items[index]);

                        var column = metadata.GetType().GetField("column", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(metadata);
                        var length = metadata.GetType().GetField("length", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(metadata);
                        throw new Exception(string.Format("Column: {0} contains data with a length greater than: {1}", column, length));

                    }
                }
            }
        }
        /// <summary>
        /// Generates the unique identifier.
        /// </summary>
        /// <param name="aGuidIdentifierNo">The argument unique identifier identifier no.</param>
        /// <param name="aGuidCount">The argument unique identifier count.</param>
        /// <returns></returns>

        private int GenerateGuid(int aGuidIdentifierNo, int aGuidCount)
        {
            GuidDAC guidDAC = new GuidDAC();
            int newGuid;
            try
            {
                if (aGuidCount == 1)
                {
                    newGuid = guidDAC.GetGuid(aGuidIdentifierNo);
                }
                else
                {
                    newGuid = guidDAC.GetGuid(aGuidIdentifierNo, aGuidCount);
                }
            }
            finally
            {

            }
            return newGuid;
        }
        #endregion

        #region Upload Locations

        /// <summary>
        /// Update Uploaded Locations
        /// </summary>
        /// <param name="ProgramGuid"></param>
        /// <param name="rmsConvertedDataBE"></param>
        /// <param name="LoginUserId"></param>

        public void SaveUploadedLocations(int programGuid, List<RMSConvertedDataBE> rmsConvertedDataBE, string loginUserId)
        {
            try
            {
                //Delete existing converted rms records from table
                this.DeleteSOVRMSDataByProgramGuid(programGuid, 1);

                //insert new records in converted rms table       
                this.BulkInsertConvertedRMS(rmsConvertedDataBE, loginUserId);

                //Delete existing records and insert new records in location table.
                this.SaveLocationDetails(programGuid);

            }
            catch (Exception ex)
            {
                this.DeleteSOVRMSDataByProgramGuid(programGuid, 0);  // Reset
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get TransactionScope Options
        /// </summary>
        /// <returns></returns>

        public TransactionOptions GetTransactionScopeOptions()
        {
            //Fetch transaction scope isolation level from config and prepare transaction scope options
            var options = new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.Serializable,
                Timeout = TransactionManager.DefaultTimeout
            };
            return options;
        }
        #endregion

        #region NameMatch

        /// <summary>
        /// Get all file details pending for name match
        /// </summary>
        /// <returns></returns>

        public List<DocumentBE> GetNameMatchFiles<T>(int statusId) where T : DocumentBE
        {
            return (List<DocumentBE>)base.ExecuteStoredProcedure<DocumentBE>
                     (Constants.GetNameMatchFiles, new object[] { statusId }, 0);
        }

        /// <summary>
        /// Bulk Copy of NameMatch Data
        /// </summary>
        /// <param name="dtMatch"></param>        
        /// <returns></returns>

        public void BulkCopyNameMatchData(DataTable dtMatch)
        {
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(database.ConnectionString,
                SqlBulkCopyOptions.KeepIdentity | SqlBulkCopyOptions.UseInternalTransaction))
            {
                try
                {
                    sqlBulkCopy.DestinationTableName = Constants.StageTableName;
                    sqlBulkCopy.BulkCopyTimeout = DatabaseConnnections.C_LONG_QUERY_TIMEOUT;
                    sqlBulkCopy.WriteToServer(dtMatch);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        /// <summary>
        /// Perform API Match data
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param> 
        /// <param name="aLoginUserId"></param> 
        /// <returns></returns>

        public int PerformAPIMatch(int fileProcessingTaskGuid, string aLoginUserId)
        {

            var dt = base.ExecuteStoredProcedure<int>(Constants.APIMatch, new object[] { fileProcessingTaskGuid, aLoginUserId, DateTime.Now }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {
                object fileStatus = ExecuteScalar("select [file_status] from [dbo].[t_doc] where [owner_guid]=" + fileProcessingTaskGuid);

                return Convert.ToInt32(fileStatus);
            }
            return -1; // Failure
        }

        /// <summary>
        /// Get Unmatched Companies
        /// </summary>
        /// <param name="programGuid"></param> 
        /// <returns></returns>

        public List<UnmatchedCompaniesBE> GetUnmatchedCompanies(int programGuid)
        {
            //string sql = "select ROW_Number() over (order by CompanyName) AS CompanyGuid,* FROM(" +
            //    "select DISTINCT NAMEDINSURED AS CompanyName,LOCATION as Country,INDUSTRY " +
            //    "from t_emt_insurance_stage where emt_insurance_company_guid is null " +
            //    "AND emp_fileprocessingtask_guid=" + programGuid + ")t order by CompanyName";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //var reader = NewDataReader(database, sql, 0);
            //var dtCompanyData = new DataTable();
            //dtCompanyData.Load(reader);

            //return dtCompanyData;

            return (List<UnmatchedCompaniesBE>)base.ExecuteStoredProcedure<UnmatchedCompaniesBE>
                   (Constants.UnmatchedCompanies, new object[] { programGuid }, 0);
        }

        /// <summary>
        /// Update Company by Google Match
        /// </summary>
        /// <param name="matchBE"></param> 
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int UpdateCompanayByGoogleMatch(ApiMatchBE matchBE, string aLoginUserId)
        {
            var dt = base.ExecuteStoredProcedure<int>(Constants.APIMatch, new object[] {
                matchBE.FileProcessingGuid,
                aLoginUserId,
                DateTime.Now,
                matchBE.OriginalCompany,
                matchBE.OriginalCountry,
                matchBE.MatchedCompany
            }, argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {
                object fileStatus = ExecuteScalar("select [file_status] from [dbo].[t_doc] where [owner_guid]=" + matchBE.FileProcessingGuid);

                return Convert.ToInt32(fileStatus);
            }
            return -1;
        }

        /// <summary>
        /// Get All Unmatched Countries
        /// </summary>
        /// <param name="fileprocesingGuid"></param> 
        /// <returns></returns>

        public DataTable GetAllUnmatchedCountries(int fileprocesingGuid)
        {
            //string sql = @"SELECT DISTINCT t_stage.LOCATION
            //                FROM [dbo].t_emt_insurance_stage_temp t_stage INNER JOIN t_xpo_upload_error t_upload
            //                ON t_stage.emt_insurance_guid = t_upload.emt_insurance_guid
            //                WHERE t_stage.emp_fileprocessingtask_guid =" + fileprocesingGuid +
            //                " AND t_upload.error_type_desc = 'Unmatched' AND ISNULL(t_stage.[conformed_country],'')=''";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //var reader = NewDataReader(database, sql, 0);
            //var dtCompanyData = new DataTable();
            //dtCompanyData.Load(reader);

            var result = (List<UnmatchedCountryBE>)base.ExecuteStoredProcedure<UnmatchedCountryBE>
                   (Constants.AllUnmatchedCountries, new object[] { fileprocesingGuid }, 0);
            DataTable dtCompanyData = this.ToDataTable(result);
            return dtCompanyData;
        }

        /// <summary>
        /// Update Countries by Api 
        /// </summary>
        /// <param name="countryList"></param> 
        /// <param name="fileProcessingGuid"></param>
        /// <param name="isTitle"></param>
        /// <returns></returns>

        public void UpdateCountryFromApi(List<CountryMatchBE> countryList, int fileProcessingGuid, bool isTitle)
        {
            StringBuilder sqlQueryBuilder = new StringBuilder();
            foreach (CountryMatchBE countryMatch in countryList)
            {
                sqlQueryBuilder.AppendLine("UPDATE dbo.t_emt_insurance_stage_temp SET [conformed_country]='" + (isTitle ? countryMatch.Title.Replace("'", "''") : countryMatch.SubTitle.Replace("'", "''"))
                    + "' WHERE [Location]='" + countryMatch.OriginalName.Replace("'", "''") + "' AND emp_fileprocessingtask_guid=" + fileProcessingGuid);
            }
            Update(sqlQueryBuilder.ToString());
        }
        #endregion

        #region Get Duplicate file
        /// <summary>
        /// Get all file details pending for name match
        /// </summary>
        /// <returns></returns>

        public List<DocumentBE> GetDuplicateFiles<T>(string filename, int filetype) where T : DocumentBE
        {
            //var result = new List<DocumentBE>();
            //string sql = @"Select doc_guid,owner_guid,description,file_name,file_status,file_type from t_doc where file_type=" + filetype + " and file_name='" + filename + "' and file_status<>0";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<DocumentBE>)base.ExecuteStoredProcedure<DocumentBE>
                   (Constants.GetDuplicateFiles, new object[] { filetype, filename }, 0);

        }

        #endregion

        #region ReferenceTable

        /// <summary>
        /// Bulk Insert of Country LookUp Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public void BulkInsertConvertedReference(List<XPOCountryLookupBE> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOConvertedReferenceDataReader empConvertedLocationDataReader = new XPOConvertedReferenceDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.C_EMP_CONVERTED_REF_TABLE_NAME);
                this.BulkCopyRefData(empConvertedLocationDataReader, Constants.Country_Lookup);
            }

        }

        /// <summary>
        /// Bulk Insert of Casualty Lookup Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public void BulkInsertCasualtyCompanyRef(List<XPOCasultyCompanyLookupBE> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOCasultyCompanyRefDataReader empConvertedLocationDataReader = new XPOCasultyCompanyRefDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.Casualty_Company_Lookup);
                this.BulkCopyRefData(empConvertedLocationDataReader, Constants.Casualty_Company_Lookup);
            }
        }

        /// <summary>
        /// Bulk Insert of Marine Lookup Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public void BulkInsertMarineRef(List<XPOMarineLookupBE> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOMarineRefDataReader empConvertedLocationDataReader = new XPOMarineRefDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.Marine_Lookup);
                this.BulkCopyRefData(empConvertedLocationDataReader, Constants.Marine_Lookup);
            }
        }

        /// <summary>
        /// Bulk Insert of Industry Lookup Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <returns></returns>

        public void BulkInsertIndustryRef(List<XPOIndustryLookupBE> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOIndustryDataReader empConvertedLocationDataReader = new XPOIndustryDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.Industry_Lookup);
                this.BulkCopyRefData(empConvertedLocationDataReader, Constants.Industry_Lookup);
            }

        }

        /// <summary>
        /// Bulk Copy of Reference Data
        /// </summary>
        /// <param name="dtData"></param> 
        /// <param name="tableName"></param>
        /// <returns></returns>

        public void BulkCopyRefData(IDataReader dtData, string tableName)
        {
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(database.ConnectionString,
                 SqlBulkCopyOptions.UseInternalTransaction))
            {
                try
                {
                    sqlBulkCopy.DestinationTableName = tableName;
                    sqlBulkCopy.BulkCopyTimeout = DatabaseConnnections.C_LONG_QUERY_TIMEOUT;
                    sqlBulkCopy.WriteToServer(dtData);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        /// <summary>
        /// Get Country Lookup Version Number
        /// </summary>
        /// <returns></returns>

        public int GetCountryLokkupVersionNumber()
        {
            object fileStatus = ExecuteScalar("select max(ref_version) Ref_Version from [dbo].t_xpo_country_lookup");

            return fileStatus == DBNull.Value ? 1 : Convert.ToInt32(fileStatus) + 1;
        }

        /// <summary>
        /// Get Casualty Lookup Version Number
        /// </summary>
        /// <returns></returns>

        public int GetInsCompVersionNumber()
        {
            object fileStatus = ExecuteScalar("select max(ref_version) Ref_Version from [dbo].[t_xpo_insurance_company_feed]");

            return fileStatus == DBNull.Value ? 1 : Convert.ToInt32(fileStatus) + 1;
        }

        /// <summary>
        /// Get Marine Lookup Version Number
        /// </summary>
        /// <returns></returns>

        public int GetMarineVersionNumber()
        {
            object fileStatus = ExecuteScalar("select max(ref_version) Ref_Version from [dbo].[t_xpo_marine_insurance_feed]");

            return fileStatus == DBNull.Value ? 1 : Convert.ToInt32(fileStatus) + 1;
        }

        /// <summary>
        /// Get Industry Lookup Version Number
        /// </summary>
        /// <returns></returns>

        public int GetIndustryLookupVersionNumber()
        {
            object fileStatus = ExecuteScalar("select max(ref_version) Ref_Version from [dbo].t_xpo_industry_lookup");

            return fileStatus == DBNull.Value ? 1 : Convert.ToInt32(fileStatus) + 1;
        }

        /// <summary>
        /// Get Excel files details by lob
        /// </summary>
        /// <param name="filetype"></param>
        /// <returns></returns>

        public List<DocumentBE> GetexcelFilesbyLOB<T>(int filetype) where T : DocumentBE
        {
            //var result = new List<DocumentBE>();
            //string sql = @"Select doc_guid,owner_guid ,description,file_name ,file_status,file_type from [dbo].t_doc where file_type=" + filetype + " and file_status>1 ";
            //var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //using (var reader = NewDataReader(database, sql, 0))
            //{
            //    FetchDataEntity<T>(reader, ent =>
            //    {
            //        result.Add(ent);
            //    });
            //}
            //return result;

            return (List<DocumentBE>)base.ExecuteStoredProcedure<DocumentBE>
                    (Constants.GetexcelFilesbyLOB, new object[] { filetype }, 0);
        }

        /// <summary>
        /// Perform Update RefAuto Match.
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int PerformRefAutomatch(int fileProcessingTaskGuid, string aLoginUserId)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.RefAutoMatch, new object[] {
                fileProcessingTaskGuid,
                aLoginUserId,
                DateTime.Now

            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;
            }
            return -1; // Failure
        }

        public int SaveVoiceContentReport1(string spname, Dictionary<string, string> spparams)
        {
            object[] objects = null;


            foreach (var item in spparams)
            {
                objects = new object[] { item.Value };
            }
            var dt = base.ExecuteStoredProcedure<DataTable>(spname, objects
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;//success
            }
            return -1; // Failure
        }

        public int SaveVoiceContentReport(string vContent, string aLoginUserId)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.SaveVoiceContent, new object[] {
                vContent,
                aLoginUserId,
                DateTime.Now

            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;
            }
            return -1; // Failure
        }
        #endregion



        /// <summary>
        /// Get UnMatching Data
        /// </summary>
        /// <param name="mastertype"></param>
        /// <returns></returns>

        public List<UnMatchDataBE> GetUnMatchData(string mastertype, string assetName)
        {
            return (List<UnMatchDataBE>)base.ExecuteStoredProcedure<UnMatchDataBE>
                    (Constants.GetUnMatchData, new object[] { mastertype, assetName }, 0);
        }

        /// <summary>
        /// Get Matching Data
        /// </summary>
        /// <param name="mastertype"></param>
        /// <returns></returns>

        public List<MatchDataBE> GetMatchData(string mastertype)
        {
            return (List<MatchDataBE>)base.ExecuteStoredProcedure<MatchDataBE>
                    (Constants.GetMatchData, new object[] { mastertype }, 0);
        }

        /// <summary>
        /// Perform Update Match Data.
        /// </summary>
        /// <param name="matchBE"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int UpdateMatchData(RefDataMatchBE matchBE, string aLoginUserId)
        {
            var dt = base.ExecuteStoredProcedure<int>(Constants.RefDataMatch, new object[] {
                matchBE.InsuranceGuid,
                aLoginUserId,
                DateTime.Now,
                matchBE.OriginalName,
                matchBE.MappedName,
                matchBE.MasterType,
                matchBE.OriginalCountry,
                matchBE.MappedCountry,
                matchBE.OriginalIndustry,
                matchBE.addNewRow,
                matchBE.Ciq
            }, argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {
                object fileStatus = ExecuteScalar("select [file_status] from [dbo].[t_doc] where owner_guid= (select emp_fileprocessingtask_guid from [dbo].t_emt_insurance_stage where emt_insurance_guid=" + matchBE.InsuranceGuid + ")");

                return Convert.ToInt32(fileStatus);
            }
            return -1;
        }


        /// <summary>
        /// Override the file data.
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public bool OverrideFilesData(int fileProcessingTaskGuid)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.OverrideFileData, new object[] {
                fileProcessingTaskGuid
             }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return true;
            }
            return false; // Failure
        }

        /// <summary>
        /// Get Ref Data
        /// </summary>
        /// <param name="selectedFileType"></param>
        /// <param name="name"></param>
        /// <returns></returns>

        public DataTable GetRefData(string tableName)
        {
            DataTable dt = new DataTable();
            List<RefDataMarineInsuranceFeedBE> marineinsuranceFeed = new List<RefDataMarineInsuranceFeedBE>();
            switch (tableName)
            {
                case Constants.Casualty_Company_Lookup:
                    var insuranceCompanyFeedList = (List<RefDataInsuranceComapnyFeed>)base.ExecuteStoredProcedure<RefDataInsuranceComapnyFeed>(Constants.RefLookUpData, new object[] { tableName }
                      , argCustomTimeOut: 0);
                    var companyLookupList = (from i in insuranceCompanyFeedList
                                             select new
                                             {
                                                 i.Insured,
                                                 i.SavedName,
                                                 i.Country,
                                                 i.ConformCountry,
                                                 i.Industry,
                                                 i.ConformIndustry,
                                                 i.ReferenceID,
                                                 i.ValidationDate,
                                                 i.Revenue,
                                                 i.EmployeeCount
                                             }).ToList();
                    dt = ToDataTable(companyLookupList);
                    break;
                case Constants.Country_Lookup:
                    var countryList = (List<RefDataCountryLookUpBE>)base.ExecuteStoredProcedure<RefDataCountryLookUpBE>(Constants.RefLookUpData, new object[] { tableName }
                    , argCustomTimeOut: 0);
                    var countryLookupList = (from i in countryList
                                             select new { i.Location, i.MappedCountry, i.ValidatedDate, }).ToList();

                    dt = ToDataTable(countryLookupList);
                    break;
                case Constants.Marine_Lookup:
                    marineinsuranceFeed = (List<RefDataMarineInsuranceFeedBE>)base.ExecuteStoredProcedure<RefDataMarineInsuranceFeedBE>(Constants.RefLookUpData, new object[] { tableName }
                   , argCustomTimeOut: 0);
                    dt = ToDataTable(marineinsuranceFeed);
                    break;
                case Constants.Industry_Lookup:
                    var industryList = (List<RefDataIndustryLookUpBE>)base.ExecuteStoredProcedure<RefDataIndustryLookUpBE>(Constants.RefLookUpData, new object[] { tableName }
                    , argCustomTimeOut: 0);
                    var industryLookupList = (from i in industryList
                                              select new { i.Industry, i.MappedIndustry, i.ValidatedDate, }).ToList();
                    dt = ToDataTable(industryLookupList);
                    break;


            }
            return dt;
        }

        /// <summary>
        /// Convert List Data to Datatable
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>

        public DataTable ToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }

        /// <summary>
        /// Perform Clear for ManualEntries.
        /// </summary>
        /// <param name="MasterType"></param>
        /// <returns></returns>

        public int ClearManualEntries(string mastertype)
        {
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.ClerManualEntries, new object[] {
                mastertype
            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                return 1;
            }
            return -1; // Failure
        }

        /// <summary>
        /// Get Tower Match Data
        /// </summary>
        /// <param name="filetype"></param>
        /// <param name="coverage"></param>
        /// <param name="assetname"></param>
        /// <param name="savedName"></param>
        /// <returns></returns>

        public List<TowerMatchBE> GetTowerUnMatchData(string filetype, string coverage, string assetname, string savedName)
        {
            savedName = !string.IsNullOrWhiteSpace(savedName) ? savedName.Replace("'", "''") : string.Empty;
            assetname = !string.IsNullOrWhiteSpace(assetname) ? assetname.Replace("'", "''") : string.Empty;
            return (List<TowerMatchBE>)base.ExecuteStoredProcedure<TowerMatchBE>
                    (Constants.GetTowerUnMatchData, new object[] { filetype, coverage, savedName, assetname }, 0);
        }

        /// <summary>
        /// UpdateTowerMatch Data
        /// </summary>
        /// <param name="fpGuids"></param>
        /// <param name="userid"></param>
        /// <returns></returns>

        public bool UpdateTowerMatchData(string fpGuids, string userid)
        {
            bool status = false;
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.UpdateTowerMatchData, new object[] {
                fpGuids,
                userid
            }
                     , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {

                status = true;
            }
            return status; // Failure
        }


        /// <summary>
        /// UpdateTowerMatch
        /// </summary>
        /// <param name="savedName"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>

        public bool UpdateTowerMatch(string savedName, string UserId)
        {
            bool status = false;
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.ProcessTowerMatch, new object[] { savedName, UserId }
            , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// UpdateMarinedata
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public bool UpdateMarinedata(int fileProcessingTaskGuid)
        {
            bool status = false;
            var dt = base.ExecuteStoredProcedure<DataTable>(Constants.UpdateMarineData, new object[] { fileProcessingTaskGuid }
            , argCustomTimeOut: 0);
            if (dt != null && dt.Count > 0)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Get In-progressAsset Names
        /// </summary>
        /// <returns></returns>

        public List<AssetNamesBE> GetInProgressAssetNames()
        {
            return (List<AssetNamesBE>)base.ExecuteStoredProcedure<AssetNamesBE>
            (Constants.GetInproressAssetNames, new object[] { }, 0);
        }

        /// <summary>
        /// Get TowerMatch AssetNames
        /// </summary>
        /// <returns></returns>

        public List<AssetNamesBE> GetTowerMatchAssetNames()
        {
            return (List<AssetNamesBE>)base.ExecuteStoredProcedure<AssetNamesBE>
            (Constants.GetTowerMatchAssetNames, new object[] { }, 0);
        }


        /// <summary>
        /// Get TowerMatch Coverage
        /// </summary>
        /// <returns></returns>

        public List<CoverageBE> GetCoverage()
        {
            return (List<CoverageBE>)base.ExecuteStoredProcedure<CoverageBE>
            (Constants.GetCoverages, new object[] { }, 0);
        }


        /// <summary>
        /// Get All Matching Data
        /// </summary>
        /// <param name="mastertype"></param>
        /// <returns></returns>

        public List<AllMatchDataBE> GetAllMatchData(string mastertype, string assetName)
        {
            return (List<AllMatchDataBE>)base.ExecuteStoredProcedure<AllMatchDataBE>
                    (Constants.GetAllMatchData, new object[] { mastertype, assetName }, 0);
        }

        /// <summary>
        /// Perform Update Match Data with multi rows.
        /// </summary>
        /// <param name="matchBE"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int SaveMatchData(string masterType, string data, string aLoginUserId)
        {
            base.ExecuteStoredProcedure<int>(Constants.SaveMatchData, new object[] {
                aLoginUserId,
                masterType,
                data
            }, argCustomTimeOut: 0);

            return 1;
        }


        public int SavingMatchData(List<RefDataMatchBE> mappingData, string aLoginUserId)
        {
            foreach (var item in mappingData)
            {

                base.ExecuteStoredProcedure<int>(Constants.RefDataMatch, new object[] {
                0,
                aLoginUserId,
                DateTime.Now,
                item.OriginalName,
                item.MappedName,
                item.MasterType,
                item.OriginalCountry,
                item.MappedCountry,
                item.OriginalIndustry,
                item.addNewRow,
                item.Ciq
            }, argCustomTimeOut: 0);
            }

            return 1;
        }

        public List<CoverageBE> GetTCoverage()
        {
            return (List<CoverageBE>)base.ExecuteStoredProcedure<CoverageBE>
            (Constants.GetTCoverages, new object[] { }, 0);
        }


        /// <summary>
        /// TowerMatch API
        /// </summary>
        /// <returns></returns>

        public bool TowerMatchProcess(string coverage, int flg)
        {
            base.ExecuteStoredProcedure<bool>(Constants.TowerMatchAPI, new object[] {
                coverage,
                flg

            }, argCustomTimeOut: 0);
            return true;
        }

        public List<SubStage> GetdatabyCoverage(string cov)
        {
            return (List<SubStage>)base.ExecuteStoredProcedure<SubStage>
            (Constants.GetDatabyCoverage, new object[] { cov }, 0);
        }



        public List<PrevTable> spu_GetPrevTable()
        {
            return (List<PrevTable>)base.ExecuteStoredProcedure<PrevTable>
            (Constants.GetPrevData, new object[] { }, 0);
        }

        public List<SubStage> GetNexcycleData(int runcycle)
        {
            return (List<SubStage>)base.ExecuteStoredProcedure<SubStage>
            (Constants.Getnextcycledata, new object[] { runcycle }, 0);
        }
        /// <summary>
        /// Bulk Insert of Casualty Lookup Data
        /// </summary>
        /// <param name="aRmsConvertedDataBE"></param> 
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public void BulkInsertTowerMatchoutPut(List<MainStage> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOTowerMatchDataReader empConvertedLocationDataReader = new XPOTowerMatchDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.TowerMatchProcMaster);
                this.BulkInsertTowerMatchData(empConvertedLocationDataReader, Constants.TowerMatchProcMaster);
            }
        }
        public void BulkInsertTowerMatchNexcycle(List<MainStage> aRmsConvertedDataBE)
        {
            if (aRmsConvertedDataBE != null && aRmsConvertedDataBE.Count > 0)
            {
                XPOTowerMatchDataReader empConvertedLocationDataReader = new XPOTowerMatchDataReader(aRmsConvertedDataBE, 0, aRmsConvertedDataBE.Count - 1, Constants.TowerMatchNextcycle);
                this.BulkInsertTowerMatchData(empConvertedLocationDataReader, Constants.TowerMatchNextcycle);
            }
        }



        public void BulkInsertTowerMatchData(IDataReader dtData, string tableName)
        {
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(database.ConnectionString,
                 SqlBulkCopyOptions.UseInternalTransaction))
            {
                try
                {
                    sqlBulkCopy.DestinationTableName = tableName;
                    sqlBulkCopy.BulkCopyTimeout = DatabaseConnnections.C_LONG_QUERY_TIMEOUT;
                    sqlBulkCopy.WriteToServer(dtData);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }


        public int InsertdateTime(int runcycle, int count, string cov)
        {
            base.ExecuteStoredProcedure<int>("spu_insertDateandTime", new object[] {
                runcycle,
                count,
                cov

            }, argCustomTimeOut: 0);

            return 1;
        }

        public int FinalTowerMatch(string Cov)
        {
            base.ExecuteStoredProcedure<int>("spu_FinalTowerMatch", new object[] {
                Cov,

            }, argCustomTimeOut: 0);

            return 1;
        }

        public List<TowerMatchUsersBE> GetTowerMatchAccessUsers()
        {
            return (List<TowerMatchUsersBE>)base.ExecuteStoredProcedure<TowerMatchUsersBE>
            (Constants.GetTowerMatchAccessUsers, new object[] { }, 0);
        }


        public List<ResultSearchResult> LoadResults()
        {
            return (List<ResultSearchResult>)base.ExecuteStoredProcedure<ResultSearchResult>
            ("spu_LoadReportData", new object[] { }, 0);
        }

        public DataTable LoadResults1(string entityname)
        {
            DataTable dt = new DataTable();
            
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            // string connectionstring = Encryptor.Decrypt(database.ConnectionString);
            string connectionstring = database.ConnectionString;
            //DataSet ds = new DataSet("TimeRanges");
            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                SqlCommand sqlComm = new SqlCommand("spu_LoadReportData", conn);
                sqlComm.Parameters.AddWithValue("@entityname", entityname);


                sqlComm.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;

                da.Fill(dt);
            }



            //var result = base.ExecuteStoredProcedure<DataTable>
            // ("spu_LoadReportData", new object[] { entityname }, argCustomTimeOut: 0);
            //dt = ToDataTable(result);
            //if (entityname.Contains("TSI"))
            //{
            //    var result = base.ExecuteStoredProcedure<ResultSearchTSIReports>
            // ("spu_LoadReportData", new object[] { entityname }, argCustomTimeOut: 0);
            //    dt = ToDataTable(result);
            //}
            //else if (entityname.Contains("Banded"))
            //{
            //    var result = base.ExecuteStoredProcedure<ResultSearchBandedReports>
            //("spu_LoadReportData", new object[] { entityname }, argCustomTimeOut: 0);

            //    dt = ToDataTable(result);
            //}
            //else if (entityname.Contains("PremiumComparison"))
            //{
            //    var result = base.ExecuteStoredProcedure<PremiumComparisonReportdBE>
            //("spu_LoadReportData", new object[] { entityname }, argCustomTimeOut: 0);

            //    dt = ToDataTable(result);
            //}
            //else
            //{
            //    var result = base.ExecuteStoredProcedure<ResultSearchResult>
            //    ("spu_LoadReportData", new object[] { entityname }, argCustomTimeOut: 0);
            //    dt = ToDataTable(result);
            //}
            // need to drop the table here 
            DropEntity(entityname);
            return dt;
        }
        public DataTable LoadAviExpResult(bool isHeader)
        {
            DataTable dt = new DataTable();

            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
           // string connectionstring = Encryptor.Decrypt(database.ConnectionString);
            string connectionstring = database.ConnectionString;
            //DataSet ds = new DataSet("TimeRanges");
            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                SqlCommand sqlComm = new SqlCommand("spu_LoadAviExpResult", conn);
                sqlComm.Parameters.AddWithValue("@isHeader", isHeader);
                sqlComm.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;

                da.Fill(dt);
            }
             
            return dt;
        }
        public int DropEntity(string entityname)
        {
            //var dt = base.ExecuteStoredProcedure<DataTable>("spu_DropEntity", new object[] {
            //    entityname
            //}
            //         , argCustomTimeOut: 0);

            DataTable dt = new DataTable();

            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            //string connectionstring = Encryptor.Decrypt(database.ConnectionString); 
            string connectionstring = database.ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionstring)) 
            {
                SqlCommand sqlComm = new SqlCommand("spu_DropEntity", conn);
                sqlComm.Parameters.AddWithValue("@entityname", entityname);


                sqlComm.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;

                da.Fill(dt);
            }
            if (dt != null && dt.Rows.Count > 0)
            {
                return 1;
            }
            return -1; // Failure
        }

        public List<RefreshExtractBE> GetRefreshExtractCon(string value)
        {
            return (List<RefreshExtractBE>)base.ExecuteStoredProcedure<RefreshExtractBE>
            (Constants.RefreshExtract, new object[] { value }, 0);



        }
        
        public List<RefreshExtractBE> GetFilePath()
        {

            return (List<RefreshExtractBE>)base.ExecuteStoredProcedure<RefreshExtractBE>
            (Constants.GetFilePath, new object[] {  }, 0);
            


        }
        public List<RefreshExtractBE> GetUserProfile(string loginid)
        {
            return (List<RefreshExtractBE>)base.ExecuteStoredProcedure<RefreshExtractBE>
            (Constants.GetUserProfile, new object[] { loginid }, 0);


        }
        public string GetConnectionString()
        {
            var database = XLDatabaseManager.Current.GetSqlDatabase(DatabaseConnnections.C_DEFAULT);
            return database.ToString();


        }



    }
}
