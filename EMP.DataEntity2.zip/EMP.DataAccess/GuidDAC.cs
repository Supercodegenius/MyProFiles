﻿using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using XLCapital.XLRE.Framework.BaseLibrary;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;

namespace EMP.DataAccess
{
    public class GuidDAC : BaseDataAccessComponent, IGuidDAC
    {

        #region class level variables
        //Constant declaration
        private const string STORED_PROCEDURE_SELECT_GUID = "spu_getguid";
        #endregion

        #region constructors/destructors
        /// <summary>
        /// This the default constructor of the GuidDAC class.
        /// </summary>
        /// <author> Suvajit </author>
        /// <date>06-July-2005</date>       
        public GuidDAC() : base()
        {

        }
        #endregion

        #region public methods
        /// <summary>
        /// This method is used to return Guid Value from t_guid table.
        /// </summary>
        /// <param name="inputForGuid">Guid Id. 1-Lynx Guid;2-Audit Number;3-RSG Number;4-Submission Number;5-Document ID;6-Claims To Do List;8-IR Property Submission;9-IR Casualty Submission;10-Cash Log ID;11-Retro Program ID;12-Retro Contract ID;13-EDI XRef ID;14-User Guid;15-EDIMsgCatalogID </param>
        /// <returns>int</returns>
        /// <author> Suvajit </author>
        /// <date>06-July-2005</date> 
        public override int GetGuid(int inputForGuid)
        {

            int l_Guid;
            SqlDatabase l_SqlAccess;
            l_SqlAccess = this.SqlDataAccess;
            string sqlCommand = STORED_PROCEDURE_SELECT_GUID;
            SqlCommand dbCommand = (SqlCommand)l_SqlAccess.GetStoredProcCommand(sqlCommand);

            // Add paramters
            // Input parameters can specify the input value
            l_SqlAccess.AddInParameter(dbCommand, "@guid_id", DbType.Int32, 1);
            l_SqlAccess.AddInParameter(dbCommand, "add2guid", DbType.Int32, 1);
            // Output parameters specify the size of the return data
            l_SqlAccess.AddOutParameter(dbCommand, "@next_guid", DbType.Int32, 8);

            using (TransactionScope l_TransactionScope = new TransactionScope(TransactionScopeOption.Suppress))
            {
                l_SqlAccess.ExecuteNonQuery(dbCommand);
                l_TransactionScope.Complete();
            }


            l_Guid = (int)l_SqlAccess.GetParameterValue(dbCommand, "@next_guid");

            return l_Guid;


        }

        /// <summary>
        /// This method is used to return Guid Value from guid table. It returns batch guid values based on 
        /// </summary>
        /// <param name="inputForGuid">Guid Id.</param>
        /// /// <param name="inputForGuidCount">Guid count.</param>
        /// <returns>int</returns>
        /// <author> Sethuraj </author>
        /// <date>11-Jan-2007</date> 
        public int GetGuid(int inputForGuid, int inputForGuidCount)
        {
            int l_Guid;
            SqlDatabase l_SqlAccess;
            l_SqlAccess = this.SqlDataAccess;
            string sqlCommand = STORED_PROCEDURE_SELECT_GUID;
            SqlCommand dbCommand = (SqlCommand)l_SqlAccess.GetStoredProcCommand(sqlCommand);
            // Input parameters can specify the input value
            l_SqlAccess.AddInParameter(dbCommand, "@guid_id", DbType.Int32, inputForGuid);
            l_SqlAccess.AddInParameter(dbCommand, "add2guid", DbType.Int32, inputForGuidCount);
            // Output parameters specify the size of the return data
            l_SqlAccess.AddOutParameter(dbCommand, "@next_guid", DbType.Int32, 8);
            using (TransactionScope l_TransactionScope = new TransactionScope(TransactionScopeOption.Suppress))
            {
                l_SqlAccess.ExecuteNonQuery(dbCommand);
                l_TransactionScope.Complete();
            }
            l_Guid = (int)l_SqlAccess.GetParameterValue(dbCommand, "@next_guid");
            return l_Guid;
        }
        #endregion
    }
}
