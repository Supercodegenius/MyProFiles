﻿using EMP.BusinessEntity;
using EMP.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.Constants;
using XLCapital.XLRE.Framework.ExceptionManagement;
using EMP.ExceptionManagement;
using EMP.Utilities;

namespace EMP.BusinessLogic
{
    public class BaseEMPBLO : BaseBusinessLogicObject
    {
        #region protected methods

        /// <summary>
        /// It is used to retrieve a business entity collection 
        /// using passed method which is implemented in the data access class.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="argBE"></param>
        /// <param name="argDacOverrideMethod"></param>
        /// <returns></returns>
        protected List<T> RetrieveCollection<T>(T argBE, string argDacOverrideMethod) where T : BaseBusinessEntity, new()
        {
            //Instantiate Variables            
            List<T> searchResultCol = this.MaterializeCollection(argBE, argDacOverrideMethod);
            //checking for null
            if (searchResultCol == null)
            {
                searchResultCol = new List<T>();

            }
            return searchResultCol;
        }

        /// <summary>
        /// The method is used to retrieve a business entity collection 
        /// using the default method which is implemented in the base class.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="argBE"></param>
        /// <returns></returns>
        protected List<T> RetrieveCollection<T>(T argBE) where T : BaseBusinessEntity, new()
        {
            return this.RetrieveCollection(argBE, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="argSearchParam"></param>
        /// <param name="argSearchResult"></param>
        /// <returns></returns>
        public List<T> RetrieveSearch<T>(BaseSearchParameter argSearchParam, BaseSearchResult argSearchResult)
        {
            // Method level variables
            List<object> l_SearchResultCollection = null;
           // l_SearchResultCollection = (new BaseEMPDAC()).Retrieve(argSearchResult, argSearchParam.GetSqlStatement);

            return l_SearchResultCollection.ConvertAll(obj => (T)obj);
        }

        /// <summary>
        /// save a business entity
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="argBE"></param>
        /// <returns></returns>
        protected T SaveBusinessEntity<T>(T argBE) where T : BaseBusinessEntity, new()
        {
            try
            {
                var resultEntity = this.Persist(argBE, Constants.C_MODIFY_APP);
                argBE = resultEntity as T;
                if (argBE is BaseEMPAuditableBusinessEntity<T>)
                {
                    (argBE as BaseEMPAuditableBusinessEntity<T>).Version = resultEntity.Version;
                }
                return argBE;
            }
            catch (Exception l_SysException)
            {
                throw new XLSystemException(FrameworkConstants.C_DEFAULT_ERR_CODE, l_SysException.Message, SeverityLevel.Error, l_SysException);
            }
        }

        #endregion


        /// <summary>
        /// This method is inherited from the Framework, generates the Guid. 
        /// </summary>
        /// <returns></returns>
        public override IGuidDAC GetGuidDAC()
        {
            return new GuidDAC();
        }

        /// <summary>
        ///  
        /// </summary>
        /// <returns></returns>
        public int GetGuid(int guidType)
        {
            return this.GetGuidDAC().GetGuid(guidType);
        }

        /// <summary>
        /// This method is inherited from the Framework. 
        /// It is used to generate the GUID while a business entity 
        /// is being inserting into database without primary key.
        /// </summary>
        /// <param name="argPrimaryKeyID"></param>
        /// <returns></returns>
        public override int GeneratePrimaryKey(int argPrimaryKeyID)
        {
            return this.GetGuidDAC().GetGuid(argPrimaryKeyID);
        }


    }
}

