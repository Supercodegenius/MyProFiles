﻿using System;
using System.Collections.Generic;
using System.Linq;
using EMP.BusinessEntity;
using EMP.DataAccess;
using EMP.Interfaces;
using EMP.Caching;
using EMP.Utilities;
using EMP.Interfaces.BusinessEntity;
using XLCapital.XLRE.Framework.Constants;
using EMP.Documentum;
using EMP.ViewModel;
using System.Data;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml.Serialization;
using System.Globalization;
using System.Web;
using Newtonsoft.Json.Linq;
using System.Reflection;
using XLCapital.XLRE.Framework.Utilities;
using System.Diagnostics;
using System.Configuration;
using System.Net.Http;
using System.ComponentModel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using LinqToExcel;
using System.Net.Http.Headers;
using System.Text;
using System.IO.Compression;

namespace EMP.BusinessLogic
{
    public class EMPBLO : BaseEMPBLO, IEMPBLO
    {
        private readonly EMPDAC _empDAC;
        private int? _programGuid;
        private int? _programFileGuid;

        public EMPBLO()
        {
            _empDAC = new EMPDAC();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="argSecurityPrincipleBE"></param>
        /// <returns></returns>
        public List<ISecurityPrincipalBE> RetrieveSecurityPrinciple(ISecurityPrincipalBE argSecurityPrincipleBE)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var list = new List<ISecurityPrincipalBE>();
                _empDAC.ReadEntity<ISecurityPrincipalBE>((SecurityPrincipalBE)argSecurityPrincipleBE, ent =>
                {
                    list.Add(ent);
                });
                return list;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #region Common
        public void GetFileDetailByTaskGuid(int fileProcessingTaskGuid)
        {
            if (fileProcessingTaskGuid > 0)
            {
                FileProcessingTasksBE fileProcessingTasksBE = this.GetFileProcessingTaskByOwnerGuid(fileProcessingTaskGuid);
                if (fileProcessingTasksBE != null && fileProcessingTasksBE.FileProcessingTaskGuid > 0)
                {
                    _programGuid = fileProcessingTasksBE.ProgramGuid;
                    _programFileGuid = fileProcessingTasksBE.ProgramFileGuid;
                }
            }
        }

        public void GetFileDetailByProgramguid(int? programGuid)
        {
            if (programGuid > 0)
            {
                FileProcessingTasksBE fileProcessingTasksBE = this.GetFileProcessingTaskByProgramGuid(programGuid.Value);
                if (fileProcessingTasksBE != null && fileProcessingTasksBE.ProgramFileGuid > 0)
                {
                    _programGuid = fileProcessingTasksBE.ProgramGuid;
                    _programFileGuid = fileProcessingTasksBE.ProgramFileGuid;
                }
            }
        }

        #endregion Common

        #region CacheLoading
        /// <summary>
        /// Retrieve mapped SOV to RMS fields
        /// </summary>
        /// <returns></returns>
        public List<ISOVtoRMSFieldsBE> GetSovtoRMSFields(string fileType = "1")//filetype=1 equals casulty
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                EMPDAC empDAC = new EMPDAC();
                XLTrace.Write("Started Retrieving All SOV to RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                var result = empDAC.GetSOVtoRMSFields<SOVtoRMSFieldBE>(fileType);
                XLTrace.Write("Completed Retrieving All SOV to RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                //Database Logging

                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All SOV to RMS Mapping Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

        }

        /// <summary>
        /// Retrieve limit to list values
        /// </summary>
        /// <returns></returns>
        public List<ILimitToListBE> GetLimitToListValues()
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                EMPDAC empDAC = new EMPDAC();
                XLTrace.Write("Started Retrieving All Limit to List Data Succesfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                var result = empDAC.GetLimitToListValues<LimitToListBE>();
                XLTrace.Write("Completed Retrieving All Limit to List Data Succesfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All Limit to List Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

        }

        /// <summary>
        /// Retrieve OCCBldClassValues data
        /// </summary>
        /// <returns></returns>
        public List<IOccBldClassLookupBE> GetOccBldClassValues()
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                EMPDAC empDAC = new EMPDAC();
                XLTrace.Write("Started Retrieving All Occupancy Succesfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                var result = empDAC.GetOccBldClassValues<OccBldClassLookupBE>();
                XLTrace.Write("Completed Retrieving All Occupancy Succesfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All Occupancy Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        #endregion

        #region Home
        /// <summary>
        /// Get BulkCode by RMS FieldGuid
        /// </summary>
        /// <param name="rmsFieldGuid"></param>
        /// <returns></returns>
        public BulkCodeValues GetBulkCodeByRMSFieldGuid(int rmsFieldGuid, int fileProcessingTaskGuid)
        {
            BulkCodeValues l_BulkCodeValues = null;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var limitTo = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
                IEnumerable<ILimitToListBE> l_LimitToListBE = limitTo.Where(S => S.RMSFieldGuid == rmsFieldGuid && S.BulkOption == true);
                if (l_LimitToListBE.Count() > 0)
                {
                    bool isSchemeAvail = l_LimitToListBE.Any(x => !string.IsNullOrEmpty(x.EMPSchemeName));
                    l_BulkCodeValues = new BulkCodeValues
                    {
                        IsSchemeReq = isSchemeAvail,
                        Note = string.Empty,
                        BulkCodes = l_LimitToListBE.OrderBy(x => x.OrderNum).Select(S => new BulkCodeItem
                        {
                            Code = S.Code,
                            Description = S.Description,
                            Schema = S.EMPSchemeName
                        }).ToList()
                    };
                    XLTrace.Write("Stage - 2 : Retrieved Bulk Code Values Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid, null, rmsFieldGuid);

                }
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Bulk Code Values Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid, null, rmsFieldGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return l_BulkCodeValues;
        }

        ///// <summary>
        ///// Create file processing task and save in DB
        ///// </summary>
        ///// <param name="argfileProcessingTasksBE"></param>
        ///// <returns></returns>
        public FileProcessingTasksBE CreateFileProcessingTasks(FileProcessingTasksBE argfileProcessingTasksBE, int? programGuid)
        {
            FileProcessingTasksBE resFileProcessingTasksBE = new FileProcessingTasksBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                string docId = string.Empty;
                FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
                if (programGuid > 0)
                {
                    Random random = new Random();
                    argfileProcessingTasksBE.ProgramGuid = programGuid;
                    argfileProcessingTasksBE.ProgramFileGuid = random.Next();
                    _programGuid = programGuid.Value;
                    _programFileGuid = argfileProcessingTasksBE.ProgramFileGuid.Value;
                }

                argfileProcessingTasksBE.ChangedStatus = EntityStatus.StatusInsert;
                argfileProcessingTasksBE.StatusGuid = (int)EMPStatus.New;
                argfileProcessingTasksBE.FileDataColl[0].ChangedStatus = EntityStatus.StatusInsert;
                argfileProcessingTasksBE.DocumentBEColl[0].ChangedStatus = EntityStatus.StatusInsert;
                resFileProcessingTasksBE = SaveBusinessEntity((FileProcessingTasksBE)argfileProcessingTasksBE);
                XLTrace.Write("Stage-1 : SOV File Uploaded Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid, argfileProcessingTasksBE.SourceSheet);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage-1 : SOV File Upload Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid, argfileProcessingTasksBE.SourceSheet);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return resFileProcessingTasksBE;

        }

        /// <summary>
        /// Upload document in documentum
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public string UploadDocumentToDocumentum(string filePath)
        {
            string id;
            try
            {
                EMPDocumentum eMPDocumentum = new EMPDocumentum();
                id = eMPDocumentum.UploadDocument(filePath);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return id;
        }

        /// <summary>
        /// Retrieve data from FileDataProcessing 
        /// </summary>
        /// <returns></returns>
        public FileDataProcessingBE GetFileProcessingTask(int fileProcessingTaskGuid)
        {
            FileDataProcessingBE fileDataProcessingBE = new FileDataProcessingBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                FileDataProcessingBE fileDataProcessing = new FileDataProcessingBE();
                fileDataProcessing.FileProcessingTaskGuid = fileProcessingTaskGuid;
                List<FileDataProcessingBE> fileDatas = base.MaterializeCollection<FileDataProcessingBE>(fileDataProcessing, null);
                XLTrace.Write("Retrieved File Processing Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                fileDataProcessingBE = fileDatas.OrderByDescending(x => x.PrimaryKey).FirstOrDefault();
                return fileDataProcessingBE;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File Processing Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

        }

        /// <summary>
        /// Retrieve data from FileProcessingTask
        /// </summary>
        /// <returns></returns>
        public FileProcessingTasksBE GetFileProcessingTaskByOwnerGuid(int argFileProcessingTaskGuid)
        {
            FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileProcessingTasksBE fileDataProcessing = new FileProcessingTasksBE();
                fileDataProcessing.FileProcessingTaskGuid = argFileProcessingTaskGuid;
                List<FileProcessingTasksBE> fileDatas = base.MaterializeCollection<FileProcessingTasksBE>(fileDataProcessing, null);
                fileProcessingTasksBE = fileDatas?[0];
                XLTrace.Write("Retrieved File Processing Task Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, fileProcessingTasksBE.ProgramGuid, fileProcessingTasksBE.ProgramFileGuid);
                return fileProcessingTasksBE;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File Processing Task Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, fileProcessingTasksBE.ProgramGuid, fileProcessingTasksBE.ProgramFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Retrieve data from FileProcessingTask
        /// </summary>
        /// <returns></returns>
        public DocumentBE GetDocumentByOwnerGuid(int argFileProcessingTaskGuid)
        {
            DocumentBE docBE = new DocumentBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                DocumentBE doc = new DocumentBE();
                doc.OwnerGuid = argFileProcessingTaskGuid;
                List<DocumentBE> fileDatas = base.MaterializeCollection<DocumentBE>(doc, null);
                docBE = fileDatas?[0];
                XLTrace.Write("Retrieved File Processing Task Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, docBE.PrimaryKey);
                return docBE;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File Processing Task Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, docBE.PrimaryKey);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }
        public DocumentBE GetDocumentByProgramGuid(int programGuid)
        {
            try
            {
                FileProcessingTasksBE tasksBE = this.GetFileProcessingTaskByProgramGuid(programGuid);
                //Calling StartTrace() method
                return this.GetDocumentByOwnerGuid(tasksBE.FileProcessingTaskGuid.Value);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File Processing Task Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Retrieve data from FileProcessingTask
        /// </summary>
        /// <returns></returns>
        public FileProcessingTasksBE GetFileProcessingTaskByProgramGuid(int programGuid)
        {
            FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileProcessingTasksBE fileDataProcessing = new FileProcessingTasksBE();
                fileDataProcessing.ProgramGuid = programGuid;
                List<FileProcessingTasksBE> fileDatas = base.MaterializeCollection<FileProcessingTasksBE>(fileDataProcessing, null);
                fileProcessingTasksBE = fileDatas.Where(x => x.ProgramGuid == fileDataProcessing.ProgramGuid).OrderByDescending(x => x.AddedDt).FirstOrDefault();
                XLTrace.Write("Retrieved File Processing Task Data By Program Guid Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, programGuid, fileProcessingTasksBE.ProgramFileGuid);
                return fileProcessingTasksBE;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File Processing Task Data By Program Guid Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, programGuid, fileProcessingTasksBE.ProgramFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Validate Uploaded SOV File
        /// </summary>
        /// <param name="dtexcelContent"></param>
        /// <returns></returns>
        public DataTable ValidateExcelData(DataTable dtexcelContent, string fileType)
        {
            var l_ISOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            l_ISOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields(fileType);
            var lRMSFieldData = l_ISOVRMSMappingBE.Select(item => new { SOVFieldName = item.SOVFieldName, RMSFieldType = item.RMSFieldType, RMSFieldName = item.RMSFieldName }).Distinct().ToList();

            DataTable dtclone = dtexcelContent.Clone();
            foreach (DataColumn dc in dtclone.Columns)
            {
                var lData = lRMSFieldData.Exists(i => i.SOVFieldName.Equals(dc.ColumnName, StringComparison.OrdinalIgnoreCase));
                if (lData)
                {

                    var lFieldType = lRMSFieldData.Find(i => i.SOVFieldName.Equals(dc.ColumnName, StringComparison.OrdinalIgnoreCase)).RMSFieldType;
                    if (lFieldType.Contains("char"))
                    {
                        dc.DataType = typeof(string);
                    }
                    if (lFieldType.Contains("Integer"))
                    {
                        dc.DataType = typeof(int);
                    }
                    if (lFieldType.Contains("numeric"))
                    {
                        dc.DataType = typeof(double);
                    }
                    if (lFieldType.Contains("date"))
                    {
                        dc.DataType = typeof(DateTime);
                    }

                }
                else
                {
                    dc.DataType = typeof(string);
                }

            }
            foreach (DataRow dr in dtexcelContent.Rows)
            {
                var drRow = dr.ItemArray.All(r => r is DBNull || string.IsNullOrEmpty(r as string));
                if (!drRow)
                {
                    DataRow drowNew = dtclone.NewRow();
                    foreach (DataColumn col in dtclone.Columns)
                    {
                        string lFieldName = string.Empty;
                        var lData = lRMSFieldData.Exists(x => x.SOVFieldName.Equals(col.ColumnName, StringComparison.OrdinalIgnoreCase));
                        if (lData)
                        {
                            lFieldName = lRMSFieldData.Find(i => i.SOVFieldName.Equals(col.ColumnName, StringComparison.OrdinalIgnoreCase)).RMSFieldName;
                        }
                        Type excelType = col.DataType;
                        var excelRow = lFieldName == "NAMED INSURED" || lFieldName == "LOCATION" || lFieldName == "INDUSTRY" ? dr[col.ColumnName].ToString().Trim().ToUpper() : dr[col.ColumnName];
                        string checkValue = "null";
                        if (excelRow.ToString().ToLower() == checkValue)
                        {
                            excelRow = string.Empty;
                        }
                        if (!(excelRow is DBNull))
                        {
                            if (excelType.Equals(typeof(double)))
                            {
                                double dType = 0.00;
                                if (double.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(double));
                                else
                                    drowNew[col.ColumnName] = string.IsNullOrEmpty(excelRow.ToString()) ? 0.0 : ConvertLatLong(excelRow.ToString());
                            }
                            if (excelType.Equals(typeof(int)))
                            {
                                int dType = 0;
                                if (excelRow.Equals(typeof(double)))
                                {
                                    excelRow = Math.Round(Convert.ToDouble(excelRow));
                                }
                                else if (excelRow.Equals(typeof(int)))
                                {
                                    excelRow = Convert.ToInt32(excelRow);
                                }
                                else if (excelRow.Equals(typeof(string)))
                                {
                                    excelRow = Convert.ToString(excelRow);
                                }
                                else
                                {
                                    //changing comma seperated values into 0
                                    if (!string.IsNullOrEmpty(lFieldName) && lFieldName == RMSColumn.NUM_STORIES)
                                    {
                                        var numstories = excelRow.ToString().Split(',');
                                        if (numstories.Length > 1)
                                        {
                                            excelRow = 0;
                                        }
                                    }
                                    else
                                    {
                                        //taking only prefix number from the values
                                        excelRow = new String(excelRow.ToString().TakeWhile(Char.IsDigit).ToArray());
                                    }
                                }
                                if (int.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(int));
                                else
                                    drowNew[col.ColumnName] = 0;
                            }
                            if (excelType.Equals(typeof(string)))
                            {
                                drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(string));
                            }
                            if (excelType.Equals(typeof(DateTime)))
                            {
                                DateTime dType = DateTime.MinValue;
                                if (DateTime.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(DateTime));
                                else
                                    drowNew[col.ColumnName] = DateTime.MinValue;
                            }
                        }
                        else
                        {
                            if (excelType.Equals(typeof(double)))
                            {
                                drowNew[col.ColumnName] = 0.0;
                            }
                            if (excelType.Equals(typeof(int)))
                            {
                                drowNew[col.ColumnName] = 0;
                            }
                            if (excelType.Equals(typeof(string)))
                            {
                                drowNew[col.ColumnName] = string.Empty;
                            }
                            if (excelType.Equals(typeof(DateTime)))
                            {
                                drowNew[col.ColumnName] = DateTime.MinValue;
                            }
                        }
                    }

                    dtclone.Rows.Add(drowNew);
                }

            }
            dtclone.AcceptChanges();
            return dtclone;
        }

        public List<ExcelSheetData> GetExcelSheetData(DataSet dsExcel)
        {
            List<ExcelSheetData> excelSheets = new List<ExcelSheetData>();
            foreach (DataTable dtSheet in dsExcel.Tables)
            {
                ExcelSheetData excelSheet = new ExcelSheetData();
                excelSheet.SheetName = dtSheet.TableName;
                excelSheet.IsEmptySheet = dtSheet.Rows.Count <= 0;
                excelSheet.IsInvalidHeaders = ValidateExcelHeader(dtSheet.Columns);
                excelSheet.SheetColumnCount = dtSheet.Columns.Count;
                excelSheets.Add(excelSheet);
            }
            return excelSheets;
        }
        public static bool ValidateExcelHeader(DataColumnCollection columns)
        {
            bool isInvalidHeaderColumn = false;
            foreach (DataColumn columnName in columns)
            {
                if (string.IsNullOrWhiteSpace(columnName.ColumnName) || Regex.Replace(columnName.ColumnName, "\\s / g", string.Empty).Length > 255)
                {
                    isInvalidHeaderColumn = true;
                    break;
                }
            }
            return isInvalidHeaderColumn;
        }
        /// <summary>
        /// Validate excel header
        /// </summary>
        /// <param name="columns"></param>
        /// <returns></returns>
        public static bool ValidateExcelHeader(List<string> columns)
        {
            bool isInvalidHeaderColumn = false;
            foreach (string columnName in columns)
            {
                if (string.IsNullOrWhiteSpace(columnName) ||
                    Regex.Replace(columnName, "\\s / g", string.Empty).Length > 255 ||
                    columnName.Equals("REF_") ||
                     Regex.Matches(columnName, "[^A-Za-z0-9\\s-_]").Count > 0 ||
                    string.IsNullOrEmpty(columnName.Replace("-", string.Empty).Replace("_", string.Empty)))
                {
                    isInvalidHeaderColumn = true;
                    break;
                }
            }
            return isInvalidHeaderColumn;
        }

        public List<string> GetHeaders(DataColumnCollection columns)
        {
            List<string> headers = new List<string>();
            foreach (DataColumn header in columns)
            {
                headers.Add(Regex.Replace(header.ColumnName, "[^A-Za-z0-9-_#&*%()/ \n]", string.Empty));
            }
            return headers;
        }

        /// <summary>
        /// Read xlsb file and get sheet information
        /// </summary>
        /// <param name="inputFile"></param>
        /// <returns></returns>
        public List<ExcelSheetData> ReadExcelBinary(string inputFile)
        {
            List<ExcelSheetData> excelSheets = new List<ExcelSheetData>();
            var excel = new ExcelQueryFactory(inputFile);
            excel.ReadOnly = true;
            excel.TrimSpaces = LinqToExcel.Query.TrimSpacesType.Both;
            var sheets = excel.GetWorksheetNames();
            ExcelSheetData excelSheet;
            foreach (string sheet in sheets)
            {
                var workSheet = excel.Worksheet(sheet);
                var columnNames = excel.GetColumnNames(sheet).ToList();
                bool invalidHeader = RemoveInvalidColumnsFromExcelBinary(columnNames);
                excelSheet = new ExcelSheetData();
                excelSheet.SheetName = sheet;
                excelSheet.IsMergeCellExist = false;
                excelSheet.IsEmptySheet = workSheet.Count() <= 0;
                excelSheet.SheetColumnCount = excelSheet.IsEmptySheet ? 0 : columnNames.Count;
                excelSheet.IsInvalidHeaders = excelSheet.IsEmptySheet ? false : invalidHeader ? true : ValidateExcelHeader(columnNames);
                excelSheets.Add(excelSheet);
            }
            return excelSheets;
        }

        /// <summary>
        /// Read XLSB files and return data as a datatable
        /// </summary>
        /// <param name="inputFile"></param>
        /// <param name="sheetName"></param>
        /// <returns></returns>
        public DataTable ReadExcelBinaryData(string inputFile, string sheetName)
        {
            var excel = new ExcelQueryFactory(inputFile);
            excel.ReadOnly = true;
            excel.TrimSpaces = LinqToExcel.Query.TrimSpacesType.Both;
            var workSheet = excel.Worksheet(sheetName);
            var columnNames = excel.GetColumnNames(sheetName).ToList();
            DataTable dataTable = new DataTable();
            foreach (string columnName in columnNames)
            {
                dataTable.Columns.Add(columnName, typeof(string));
            }
            foreach (LinqToExcel.Row row in workSheet)
            {
                DataRow dataRow = dataTable.NewRow();

                foreach (string column in columnNames)
                {
                    dataRow[column] = row[column];
                }
                dataTable.Rows.Add(dataRow);
            }
            return dataTable;
        }

        /// <summary>
        /// Validate excel header 
        /// </summary>
        /// <param name="columnNames"></param>
        /// <returns></returns>
        private bool RemoveInvalidColumnsFromExcelBinary(List<string> columnNames)
        {
            int count = columnNames.Count() - 1;
            bool inValidColumn = false;
            for (int columnCount = count; columnCount >= 0; columnCount--)
            {
                if (columnNames[columnCount].Equals("F" + (columnCount + 1)))
                {
                    inValidColumn = true;
                    break;
                }

            }

            return inValidColumn;
        }
        public List<ExcelSheetData> ReadExcelUsingOpenXML(Stream inputStream)
        {
            List<ExcelSheetData> excelSheets = new List<ExcelSheetData>();
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(inputStream, false))
            {
                WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;
                Sheets workSheets = workbookPart.Workbook.Sheets;
                foreach (Sheet sheet in workSheets)
                {
                    Worksheet Worksheet = ((WorksheetPart)workbookPart.GetPartById(sheet.Id)).Worksheet;
                    SheetData sheetData = Worksheet.Elements<SheetData>().First();
                    IEnumerable<DocumentFormat.OpenXml.Spreadsheet.Row> rows = sheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>();
                    ExcelSheetData excelSheet = new ExcelSheetData();
                    excelSheet.SheetName = sheet.Name;
                    excelSheet.IsMergeCellExist = Worksheet.Descendants<MergeCells>().Any();
                    excelSheet.IsEmptySheet = !rows.Any();
                    excelSheet.SheetColumnCount = excelSheet.IsEmptySheet ? 0 : rows.First().Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Count();
                    List<string> headers = new List<string>();
                    foreach (DocumentFormat.OpenXml.Spreadsheet.Row r in rows)
                    {
                        foreach (DocumentFormat.OpenXml.Spreadsheet.Cell c in r.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>())
                        {
                            string currentcellvalue = string.Empty;
                            if (c.DataType != null)
                            {
                                if (c.DataType == CellValues.SharedString)
                                {
                                    int id = -1;

                                    if (Int32.TryParse(c.InnerText, out id))
                                    {
                                        SharedStringItem item = GetSharedStringItemById(workbookPart, id);

                                        if (item.Text != null)
                                        {

                                            currentcellvalue = item.Text.Text;
                                        }
                                        else if (item.InnerText != null)
                                        {
                                            currentcellvalue = item.InnerText;
                                        }
                                        else if (item.InnerXml != null)
                                        {
                                            currentcellvalue = item.InnerXml;
                                        }
                                    }

                                }
                            }
                            headers.Add(currentcellvalue);
                        }
                        break;
                    }
                    excelSheet.IsInvalidHeaders = ValidateExcelHeader(headers);
                    excelSheets.Add(excelSheet);
                }
            }
            return excelSheets;
        }

        public static SharedStringItem GetSharedStringItemById(WorkbookPart workbookPart, int id)
        {
            return workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(id);
        }

        /// <summary>
        /// adjust Excel Data
        /// </summary>
        /// <param name="dtexcelContent"></param>
        /// <returns></returns>
        public DataTable AdjustExcelData(DataTable dtexcelContent)
        {
            var l_ISOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            l_ISOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields();
            var lRMSFieldData = l_ISOVRMSMappingBE.Select(item => new { RMSFieldName = item.RMSFieldName, RMSFieldType = item.RMSFieldType }).Distinct().ToList();

            DataTable dtclone = dtexcelContent.Clone();
            foreach (DataColumn dc in dtclone.Columns)
            {
                dc.ColumnName = dc.ColumnName.ToUpper();
                var lData = lRMSFieldData.Exists(i => i.RMSFieldName.Equals(dc.ColumnName, StringComparison.OrdinalIgnoreCase));
                if (lData)
                {

                    var lFieldType = lRMSFieldData.Find(i => i.RMSFieldName.Equals(dc.ColumnName, StringComparison.OrdinalIgnoreCase)).RMSFieldType;
                    if (lFieldType.Contains("char"))
                    {
                        dc.DataType = typeof(string);
                    }
                    if (lFieldType.Contains("Integer"))
                    {
                        dc.DataType = typeof(int);
                    }
                    if (lFieldType.Contains("numeric"))
                    {
                        dc.DataType = typeof(double);
                    }
                    if (lFieldType.Contains("date"))
                    {
                        dc.DataType = typeof(DateTime);
                    }

                }
                else
                {
                    dc.DataType = typeof(string);
                }

            }
            foreach (DataRow dr in dtexcelContent.Rows)
            {
                var drRow = dr.ItemArray.All(r => r is DBNull || string.IsNullOrEmpty(r as string));
                if (!drRow)
                {
                    DataRow drowNew = dtclone.NewRow();
                    foreach (DataColumn col in dtclone.Columns)
                    {
                        string lFieldName = string.Empty;
                        var lData = lRMSFieldData.Exists(x => x.RMSFieldName.Equals(col.ColumnName, StringComparison.OrdinalIgnoreCase));
                        if (lData)
                        {
                            lFieldName = lRMSFieldData.Find(i => i.RMSFieldName.Equals(col.ColumnName, StringComparison.OrdinalIgnoreCase)).RMSFieldName;
                        }
                        Type excelType = col.DataType;
                        var excelRow = dr[col.ColumnName];
                        string checkValue = "null";
                        if (excelRow.ToString().ToLower() == checkValue)
                        {
                            excelRow = string.Empty;
                        }
                        if (!(excelRow is DBNull))
                        {
                            if (excelType.Equals(typeof(double)))
                            {
                                double dType = 0.00;
                                if (double.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(double));
                                else
                                    drowNew[col.ColumnName] = 0.0;
                            }
                            if (excelType.Equals(typeof(int)))
                            {
                                int dType = 0;
                                if (excelRow.Equals(typeof(double)))
                                {
                                    excelRow = Math.Round(Convert.ToDouble(excelRow));
                                }
                                else if (excelRow.Equals(typeof(int)))
                                {
                                    excelRow = Convert.ToInt32(excelRow);
                                }
                                else if (excelRow.Equals(typeof(string)))
                                {
                                    excelRow = Convert.ToString(excelRow);
                                }
                                else
                                {
                                    //changing comma seperated values into 0
                                    if (!string.IsNullOrEmpty(lFieldName) && lFieldName == RMSColumn.NUM_STORIES)
                                    {
                                        var numstories = excelRow.ToString().Split(',');
                                        if (numstories.Length > 1)
                                        {
                                            excelRow = 0;
                                        }
                                    }
                                    else
                                    {
                                        //taking only prefix number from the values
                                        excelRow = new String(excelRow.ToString().TakeWhile(Char.IsDigit).ToArray());
                                    }
                                }
                                if (int.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(int));
                                else
                                    drowNew[col.ColumnName] = 0;
                            }
                            if (excelType.Equals(typeof(string)))
                            {
                                drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(string));
                            }
                            if (excelType.Equals(typeof(DateTime)))
                            {
                                DateTime dType = DateTime.MinValue;
                                if (DateTime.TryParse(Convert.ToString(excelRow), out dType))
                                    drowNew[col.ColumnName] = Convert.ChangeType(excelRow, typeof(DateTime));
                                else
                                    drowNew[col.ColumnName] = DateTime.MinValue;
                            }

                        }
                        else
                        {
                            if (excelType.Equals(typeof(double)))
                            {
                                drowNew[col.ColumnName] = 0.0;
                            }
                            if (excelType.Equals(typeof(int)))
                            {
                                drowNew[col.ColumnName] = 0;
                            }
                            if (excelType.Equals(typeof(string)))
                            {
                                drowNew[col.ColumnName] = string.Empty;
                            }
                            if (excelType.Equals(typeof(DateTime)))
                            {
                                drowNew[col.ColumnName] = DateTime.MinValue;
                            }
                        }
                    }

                    dtclone.Rows.Add(drowNew);
                }

            }
            dtclone.AcceptChanges();
            return dtclone;
        }

        #endregion

        #region SOVtoRMSMapping

        /// <summary>
        /// Checking Temp Mapping SOV Fields
        /// </summary>
        /// <param name="SOVRMSMappingList"></param>
        public List<TempSOVRMSMappingBE> CheckTemporaryMapping(List<SOVRMSDetails> SOVRMSMappingList, int fileProcessingGuid)
        {
            var l_SOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            SOVRMSMappingList = SOVRMSMappingList.Where(x => (x.SOVFieldName != null && x.IsMappAvailable == true)).ToList();
            List<TempSOVRMSMappingBE> lstTempSOVRMSMapping = new List<TempSOVRMSMappingBE>();
            string lobType = this.GetDocumentByOwnerGuid(fileProcessingGuid).Type;
            l_SOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields(lobType);
            foreach (var mappingList in SOVRMSMappingList)
            {
                TempSOVRMSMappingBE tempSOVRMSMappingBE = new TempSOVRMSMappingBE();
                //get temp mapping columns
                var tempMappingList = l_SOVRMSMappingBE.Where(x => x.SOVFieldName.ToLower() == mappingList.SOVFieldName.ToLower() && x.RMSFieldGUID == mappingList.RMSFieldGUID).ToList();
                if (tempMappingList?.Count == 0)
                {
                    int? priority = l_SOVRMSMappingBE.Where(x => x.RMSFieldGUID == mappingList.RMSFieldGUID)?.Max(x => x.Priority);
                    if (priority.HasValue && priority.Value > 0)
                    {
                        priority++;
                    }
                    else
                    {
                        priority = 1;
                    }

                    tempSOVRMSMappingBE.Priority = priority.Value;
                    tempSOVRMSMappingBE.ChangedStatus = EntityStatus.StatusInsert;
                    tempSOVRMSMappingBE.SOVFieldName = mappingList.SOVFieldName;
                    tempSOVRMSMappingBE.RMSFieldGuid = mappingList.RMSFieldGUID;
                    tempSOVRMSMappingBE.IsTempMapping = true;
                    tempSOVRMSMappingBE.ActiveInd = true;
                    tempSOVRMSMappingBE = SaveBusinessEntity((TempSOVRMSMappingBE)tempSOVRMSMappingBE);
                    lstTempSOVRMSMapping.Add(tempSOVRMSMappingBE);
                }
                else
                {
                    if (tempMappingList.FirstOrDefault().IsTemporaryMapping)
                    {
                        var oItem = tempMappingList.FirstOrDefault();
                        tempSOVRMSMappingBE.SOVFieldGuid = oItem.SOVFieldGUID;
                        tempSOVRMSMappingBE.SOVFieldName = oItem.SOVFieldName;
                        tempSOVRMSMappingBE.IsTempMapping = true;
                        tempSOVRMSMappingBE.RMSFieldGuid = mappingList.RMSFieldGUID;
                        tempSOVRMSMappingBE.ActiveInd = true;
                        lstTempSOVRMSMapping.Add(tempSOVRMSMappingBE);
                    }
                }

            }
            return lstTempSOVRMSMapping;
        }

        public IEnumerable<ISOVtoRMSFieldsBE> GetSovtoRMSMapping(string[] argSovColumns, int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var l_ISOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
                var l_SOVRMSResultBE = new List<ISOVtoRMSFieldsBE>();
                List<string> sovCols = argSovColumns.Select(c => c.Trim()).ToList();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                if (fileProcessingTaskGuid > 0)
                {
                    DocumentBE doc = this.GetDocumentByOwnerGuid(fileProcessingTaskGuid);
                    l_ISOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields(doc.Type);
                }
                else
                {
                    l_ISOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields();
                }


                //map only system mappings on sov rms mapping                
                // X138892 - Remove IsTemporaryMapping flag condition for EMP requirement.
                List<ISOVtoRMSFieldsBE> l_userISOVRMSMappingBE = l_ISOVRMSMappingBE.ToList();
                //get data for header cols
                l_SOVRMSResultBE = GetSovDataHeaderColumns(l_SOVRMSResultBE, l_userISOVRMSMappingBE, sovCols);

                //distinct RMS columns
                var l_ISOVRMSdistMappingBE = l_userISOVRMSMappingBE.GroupBy(x => x.RMSFieldGUID).Select(x => x.First()).ToList();
                var l_SOVRMSDistinctResultBE = l_SOVRMSResultBE.Where(x => x.RMSFieldName == "CNTRYSCHEME");
                bool isCntrySchemeExist = true;
                BulkCodeItem bulkCodeItem = null;
                if (!l_SOVRMSDistinctResultBE.Any())
                {
                    //get bulkcode for country scheme
                    var cntrySchemeRmsGuid = l_userISOVRMSMappingBE.Where(x => x.RMSFieldName == RMSColumn.CNTRY_SCHEME).Select(x => x.RMSFieldGUID).FirstOrDefault();
                    BulkCodeValues bulkCodeValues = this.GetBulkCodeByRMSFieldGuid(cntrySchemeRmsGuid, fileProcessingTaskGuid);
                    if (bulkCodeValues != null)
                    {
                        if (bulkCodeValues.BulkCodes != null && bulkCodeValues.BulkCodes.Count() > 0)
                        {
                            bulkCodeItem = bulkCodeValues.BulkCodes.Where(x => x.Code == "ISO2A").FirstOrDefault();
                        }
                    }
                    isCntrySchemeExist = false;
                }

                l_SOVRMSResultBE = GetSovToRmsFieldsResult(l_SOVRMSResultBE, l_ISOVRMSdistMappingBE);
                var l_SOVRMSFieldNameGroup = l_SOVRMSResultBE.Where(x => x.IsValueField == false).GroupBy(a => a.RMSFieldName).Select(y => y.First()).ToList();
                if (!isCntrySchemeExist)
                {
                    //update cntryscheme to ISO2A if not present
                    l_SOVRMSFieldNameGroup.Where(x => x.RMSFieldName == RMSColumn.CNTRY_SCHEME).Select(x => { x.BulkCodeItem = bulkCodeItem; x.BulkOptionCode = bulkCodeItem.Code; return x; }).ToList();
                }
                if (fileProcessingTaskGuid > 0)
                {
                    var l_SOVRMSFieldNameMapped = GetSovToRMSMappedDataList(fileProcessingTaskGuid).ToList();
                    if (l_SOVRMSFieldNameMapped.Count() > 0)
                    {
                        //getting mapped value fields
                        var mappedList = from mapped in l_SOVRMSFieldNameMapped
                                         join src in l_ISOVRMSMappingBE
                                         on mapped.SOVFieldGuid equals src.SOVFieldGUID
                                         where src.IsValueField == true
                                         select src;
                        mappedList.ToList().ForEach(x => x.IsMappAvailable = true);
                        l_SOVRMSFieldNameGroup.AddRange(mappedList.ToList());

                        //getting ummapped value fields
                        var list = l_SOVRMSResultBE.Where(x => x.IsValueField == true).GroupBy(x => new { x.SOVFieldGUID, x.RMSFieldName }).Select(y => y.First()).ToList();
                        var unMappedList = list.Where(x => !mappedList.Any(y => y.RMSFieldName == x.RMSFieldName)).ToList();
                        l_SOVRMSFieldNameGroup.AddRange(unMappedList.ToList());
                    }
                    else
                    {
                        var l_SOVRMSFieldNameGroupValFields = l_SOVRMSResultBE.Where(x => x.IsValueField == true).GroupBy(x => new { x.SOVFieldGUID, x.RMSFieldName }).Select(y => y.First()).ToList();
                        l_SOVRMSFieldNameGroup.AddRange(l_SOVRMSFieldNameGroupValFields);
                    }
                }
                XLTrace.Write("Stage - 2 : SOV to RMS Mapping builded Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                return l_SOVRMSFieldNameGroup;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : SOV to RMS Mapping builded Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Get All Occupancy
        /// </summary>
        /// <returns></returns>
        public List<BulkCodeItem> GetOccupancyList(int fileProcessingTaskGuid)
        {
            List<BulkCodeItem> occupancyList = new List<BulkCodeItem>();
            try
            {
                //Calling StartTrace() methodRetrieved File Processing Data Successfully
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var data = (IEnumerable<IOccBldClassLookupBE>)this.GetOccBldClassValues();
                IEnumerable<IOccBldClassLookupBE> l_OccBldClassBE = data.Where(S => S.BulkOption == 1 && S.RMSFieldName == RMSColumn.OCC_TYPE);
                occupancyList = l_OccBldClassBE.OrderBy(x => x.OrderNum).ToList().
                                            Where(s => s.Description != RMSValue.UNKNOWN && s.Code != "0").ToList().Select(x => new BulkCodeItem
                                            {
                                                Code = x.Code,
                                                Description = x.Description,
                                                Schema = x.EMPSchemeName
                                            }).ToList();
                XLTrace.Write("Retrieved All Occupancy Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All Occupancy Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return occupancyList;

        }

        /// <summary>
        /// Get RMS Filters
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<string> GetRMSFilters(int fileProcessingTaskGuid)
        {
            List<string> data = new List<string>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                List<LookupBE> lookupBE = new List<LookupBE>();
                lookupBE = _empDAC.GetRMSFilters<LookupBE>(Constants.C_RMS_FILTER_GUID);
                foreach (var lookup in lookupBE)
                {
                    data.Add(lookup.Description);
                }
                XLTrace.Write("Retrieved RMS Filter Lookup Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving RMS Filter Lookup Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return data;
        }

        public List<FileLobBE> GetFileLobNames()
        {
            List<FileLobBE> lookupBE = new List<FileLobBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                lookupBE = _empDAC.GetFileLob<FileLobBE>();
                XLTrace.Write("Retrieved File LOB Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving File LOB Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return lookupBE;
        }

        /// <summary>
        /// Create Stage data
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="sOVRMSDetails"></param>
        /// <param name="selectedOccupancy"></param>
        /// <returns></returns>
        public DataTable CreateStageData(DataTable dt, List<SOVRMSDetails> sOVRMSDetails)
        {
            DataTable stageDt = new DataTable();
            DataTable tempDt = new DataTable();
            sOVRMSDetails = sOVRMSDetails.Where(x => !string.IsNullOrEmpty(x.RMSFieldName)).ToList();
            var distinctSOVRMSDetails = sOVRMSDetails.GroupBy(x => x.RMSFieldName).Select(x => x.FirstOrDefault()).ToList();
            double result = 0.0;

            foreach (SOVRMSDetails sovrms in distinctSOVRMSDetails)
            {
                DataColumn dc = new DataColumn();
                dc.ColumnName = sovrms.RMSFieldName;
                Type datatype = System.Type.GetType("System.String");
                dc.DataType = GetDatatype(sovrms.RMSFieldType);
                stageDt.Columns.Add(dc);
            }

            foreach (DataRow row in dt.Rows)
            {
                if (!IsEmpty(row))
                {
                    DataRow dr = stageDt.NewRow();
                    dynamic colValue = 0.00;
                    foreach (SOVRMSDetails sovrmsdata in sOVRMSDetails)
                    {
                        //to remove line breaks
                        if (!string.IsNullOrEmpty(sovrmsdata.SOVFieldName))
                        {
                            sovrmsdata.SOVFieldName = Regex.Replace(sovrmsdata.SOVFieldName, @"\r\n?|\n", " ");
                        }

                        if (string.IsNullOrEmpty(sovrmsdata.BulkOptionCode) && !string.IsNullOrEmpty(sovrmsdata.SOVFieldName) && dt.Columns.Contains(sovrmsdata.SOVFieldName.Trim()))
                        {
                            colValue = EMPBLO.GetConvertedValues(sovrmsdata.RMSFieldType.ToLower(), row[sovrmsdata.SOVFieldName]);

                            if (sovrmsdata.IsAdjustValue)
                            {
                                //apply adjust value
                                if (!string.IsNullOrEmpty(sovrmsdata.AdjustValue))
                                {
                                    colValue = this.AdjustNegativeValues(sovrmsdata.RMSFieldName, colValue);
                                    result = PerformArithMeticOperationOnSOVField(colValue, sovrmsdata);
                                    //handling multiple same rms fields like CV1Val..etc
                                    dr[sovrmsdata.RMSFieldName] = dr[sovrmsdata.RMSFieldName] is DBNull ? result : Convert.ToDouble(dr[sovrmsdata.RMSFieldName]) + result;
                                }
                                else
                                {
                                    colValue = this.AdjustNegativeValues(sovrmsdata.RMSFieldName, colValue);
                                    //handling multiple same rms fields like CV1Val..etc
                                    dr[sovrmsdata.RMSFieldName] = dr[sovrmsdata.RMSFieldName] is DBNull ? colValue : Convert.ToDouble(dr[sovrmsdata.RMSFieldName]) + colValue;
                                }
                            }
                            else
                            {
                                dr[sovrmsdata.RMSFieldName] = colValue;
                            }
                        }
                        else if (!string.IsNullOrEmpty(sovrmsdata.BulkOptionCode))
                        {

                            colValue = EMPBLO.GetConvertedValues(sovrmsdata.RMSFieldType.ToLower(), sovrmsdata.BulkOptionCode);
                            dr[sovrmsdata.RMSFieldName] = colValue;
                            if (stageDt.Columns.Contains(string.Format("sys{0}scheme", sovrmsdata.RMSFieldName.ToLower())))
                            {
                                dr[string.Format("sys{0}scheme", sovrmsdata.RMSFieldName.ToLower())] = sovrmsdata.BulkCodeItem != null ? sovrmsdata.BulkCodeItem.Schema + ": " + sovrmsdata.BulkCodeItem.Code : sovrmsdata.BulkCodeItem.Description;
                            }
                        }

                    }
                    stageDt.Rows.Add(dr);
                }
            }

            //Updating ISO2ACNTRYCODE
            var lookUpValues = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
            return stageDt;
        }

        public Type GetDatatype(string rmsFieldType)
        {
            Type datatype = System.Type.GetType("System.String");
            if (!string.IsNullOrEmpty(rmsFieldType))
            {
                switch (rmsFieldType.Substring(0, 3).ToLower())
                {
                    case "int":
                        datatype = System.Type.GetType("System.Int32");
                        break;
                    case "dat":
                        datatype = System.Type.GetType("System.DateTime");
                        break;
                    case "num":
                        datatype = System.Type.GetType("System.Double");
                        break;
                    default:
                        datatype = System.Type.GetType("System.String");
                        break;

                }
            }
            return datatype;
        }
        /// <summary>
        /// Compress or Decompress Data
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="formatData"></param>
        /// <returns></returns>
        public DataTable CompressOrDeCompressData(string Data, FormatData formatData)
        {
            DataTable dt = new DataTable();
            if (formatData == FormatData.Compress)
            {
                dt = (DataTable)JsonConvert.DeserializeObject(FileAdaptor.Decompress(Data), (typeof(DataTable)));
            }
            else if (formatData == FormatData.DeCompress)
            {
                dt = (DataTable)JsonConvert.DeserializeObject(FileAdaptor.Decompress(Data), (typeof(DataTable)));
            }
            return dt;
        }

        /// <summary>
        /// Adjust Negative values for value fields
        /// </summary>
        /// <param name="rmsFieldName"></param>
        /// <param name="colValue"></param>
        /// <returns></returns>
        public double AdjustNegativeValues(string rmsFieldName, double colValue)
        {
            double cValue = 0.00;
            if (double.TryParse(Convert.ToString(colValue), out cValue))
            {
                if (rmsFieldName == "CV1VAL" || rmsFieldName == "CV2VAL" || rmsFieldName == "CV9VAL")
                {
                    if (colValue < 0)
                    {
                        colValue = 0.00;
                    }
                }
                else if (rmsFieldName == "CV3VAL")
                {
                    if (colValue < 0)
                    {
                        colValue = Math.Abs(colValue);
                    }
                }
            }
            return colValue;
        }

        public double PerformArithMeticOperationOnSOVField(double sourceVal,
                                                           SOVRMSDetails sOVRMSDetails)
        {
            double calVal = 0;
            string[] strOperations = { "*", "/", "+", "-" };
            bool isNumeric = CommonMethods.IsValueNumeric(Convert.ToChar(sOVRMSDetails.AdjustValue.Substring(0, 1)));
            string optr = sOVRMSDetails.AdjustValue.Substring(0, 1);
            double adjustValue = Convert.ToDouble(sOVRMSDetails.AdjustValue.Substring(1));
            if (!isNumeric && strOperations.Any(optr.Contains))
            {
                switch (optr)
                {
                    case "+":
                        calVal = sourceVal + adjustValue;
                        break;

                    case "-":
                        calVal = sourceVal - adjustValue;
                        break;

                    case "*":
                        calVal = sourceVal * adjustValue;
                        break;

                    case "/":
                        calVal = sourceVal / adjustValue;
                        break;
                }
            }
            return calVal;
        }

        /// <summary>
        /// Save Mapping data Issues
        /// </summary>
        /// <param name="mappingDefBE"></param>
        /// <returns></returns>
        public bool SaveMappingDefIssues(List<MappingIssuesDefBE> mappingDefBE, string loginId)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                List<MappingIssuesDefBE> lstexistingmappingIssuesDefBEs = new List<MappingIssuesDefBE>();
                List<MappingIssuesDefBE> lstallmappingIssuesDefBEs = new List<MappingIssuesDefBE>();
                MappingIssuesDefBE mappingIssuesDef = new MappingIssuesDefBE();
                lstallmappingIssuesDefBEs = base.MaterializeCollection<MappingIssuesDefBE>(mappingIssuesDef, null);
                if (lstallmappingIssuesDefBEs != null && lstallmappingIssuesDefBEs.Count > 0)
                {
                    lstexistingmappingIssuesDefBEs = lstallmappingIssuesDefBEs.Where(x => x.AddedBy == loginId && x.IsActive == true).ToList();
                }
                foreach (MappingIssuesDefBE allIssues in mappingDefBE)
                {
                    MappingIssuesDefBE existingMapping = new MappingIssuesDefBE();
                    existingMapping = lstexistingmappingIssuesDefBEs.Where(x => x.RMSFieldName == allIssues.RMSFieldName && x.SOVSourceData == allIssues.SOVSourceData && x.RMSSelectedValue == allIssues.RMSSelectedValue
                                                                     && x.SOVFieldName == allIssues.SOVFieldName && x.CountryCode == allIssues.CountryCode).OrderByDescending(x => x.ModifyDt).FirstOrDefault();
                    if (existingMapping != null && existingMapping.Count > 0)
                    {
                        allIssues.MappingCount = existingMapping.MappingCount + 1;
                        allIssues.IssuesDefGuid = existingMapping.IssuesDefGuid;
                        allIssues.Version = existingMapping.Version;
                        allIssues.ChangedStatus = EntityStatus.StatusUpdate;
                    }
                    else
                    {
                        allIssues.MappingCount = 1;
                        allIssues.ChangedStatus = EntityStatus.StatusInsert;
                    }
                    allIssues.IsActive = true;
                    base.Persist(allIssues, "EMP");
                }
                XLTrace.Write("Stage - 3 : Saved General Mapping Resolved Issues Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 3 : Saving General Mapping Resolved Issues Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        /// <summary>
        /// Get SovToRMS Mapping Data For Back Functionality
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<MapSOVRMSBE> GetMappedSOVRMSFields(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var result = _empDAC.GetMappedSOVtoRMSFileds<MapSOVRMSBE>(fileProcessingTaskGuid, _programFileGuid.Value);
                XLTrace.Write("Retrieved All Builded SOV to RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All Builded SOV to RMS Mapping Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();

            }
        }
        /// <summary>
        ///
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<MapSOVRMSBE> GetSovToRMSMappedDataList(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var result = _empDAC.GetSovToRMSMappedData<MapSOVRMSBE>(fileProcessingTaskGuid, _programFileGuid.Value);
                XLTrace.Write("Retrieved All Builded SOV to RMS Mapping Data with DefaulMapping Columns Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving All Builded SOV to RMS Mapping Data with DefaulMapping Columns Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();

            }
        }

        /// <summary>
        /// Get Sov to RMS Mapped data
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<SOVRMSDetails> GetSOVtoRMSMapppedData(int fileProcessingTaskGuid)
        {
            List<SOVRMSDetails> detailList = new List<SOVRMSDetails>();
            var l_SOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
            DocumentBE doc = this.GetDocumentByOwnerGuid(fileProcessingTaskGuid);
            l_SOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields((doc != null ? doc.Type : "1"));
            FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
            fileProcessingTasksBE.FileProcessingTaskGuid = fileProcessingTaskGuid;
            var data = this.Materialize(fileProcessingTasksBE, null);
            List<string> RMScolumns = data.MappingDefColl[0].MappingIODefCollection.Select(x => x.ToFieldName).ToList();
            List<MappingIODefBE> lst = data.MappingDefColl[0].MappingIODefCollection.ToList();
            var finalList = EMPBLO.GetMappingFinalList(l_SOVRMSMappingBE, lst);
            foreach (var details in finalList)
            {

                SOVRMSDetails sOVRMSDetails = new SOVRMSDetails();
                sOVRMSDetails.RMSFieldGUID = details.RMSFieldGUID;
                sOVRMSDetails.SOVFieldName = details.FromFieldName;
                sOVRMSDetails.RMSFieldName = details.RMSFieldName;
                sOVRMSDetails.RMSDescription = details.RMSDescription;
                sOVRMSDetails.IsSecModByCntry = details.IsSecModByCntry;
                sOVRMSDetails.IsSecMods = details.IsSecMods;
                sOVRMSDetails.IsValueField = details.IsValueField;
                sOVRMSDetails.IsBulkCodeAvailable = details.IsBulkCodeAvailable;
                sOVRMSDetails.IsAdjustValue = details.IsAdjustValue;
                sOVRMSDetails.IsLimitToList = details.IsLimitToList;
                sOVRMSDetails.IsMappAvailable = true;
                sOVRMSDetails.IsPrimaryChar = details.IsPrimaryChar;
                sOVRMSDetails.IsRequired = details.IsRequired;
                sOVRMSDetails.IsValueField = details.IsValueField;
                sOVRMSDetails.IsMostCommon = details.IsMostCommon;
                sOVRMSDetails.IsKeyWordSearchAvailable = details.IsKeyWordSearchAvailable;
                detailList.Add(sOVRMSDetails);
            }
            return detailList;
        }

        /// <summary>
        /// Delete Mapping I/O Linking
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public int DeleteMappDef(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var result = _empDAC.DeleteMappDef(fileProcessingTaskGuid);
                XLTrace.Write("Stage - 2 : Deleted SOV to RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Deleting SOV to RMS Mapping Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Delete Mapping I/O Linking 
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>
        public int UpdateMappingDef(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var result = _empDAC.UpdateMappDef(_programGuid.Value, fileProcessingTaskGuid);
                XLTrace.Write("Stage - 2 : Updated SOV to RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                return result;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Updating SOV to RMS Mapping Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        public DataTable UpdateOccKeyWordSearch(DataTable dt, List<SOVRMSDetails> sOVRMSDetails, string selectedOccupancy, int fileProcessingTaskGuid)
        {
            DataTable occDt = new DataTable();
            var l_OccupancySearchList = GetOccupancySearchList(fileProcessingTaskGuid).FindAll(x => x.IsUseFlag == true);

            if (l_OccupancySearchList.Count() > 0)
            {

                DataTable stageDt = dt.Clone();
                var selOccupancyList = JObject.Parse(selectedOccupancy);

                foreach (DataRow row in dt.Rows)
                {
                    if (!IsEmpty(row))
                    {
                        DataRow dr = stageDt.NewRow();
                        foreach (SOVRMSDetails sovrmsdata in sOVRMSDetails)
                        {
                            if (!string.IsNullOrEmpty(sovrmsdata.SOVFieldName) && dt.Columns.Contains(sovrmsdata.RMSFieldName))
                            {
                                var occList = l_OccupancySearchList.FindAll(x => x.SovFieldName.Contains(sovrmsdata.SOVFieldName)).OrderByDescending(y => y.Priority);

                                if (occList.Count() > 0)
                                {
                                    foreach (OccKeyWordSearchBE occKeyWordSearchBE in occList)
                                    {
                                        if (row[sovrmsdata.RMSFieldName].ToString().ToLower().Contains(occKeyWordSearchBE.KeyWordSearch.ToLower()))
                                        {
                                            var objBulkCodeItem = JObject.Parse(occKeyWordSearchBE.BulkCodeItem);
                                            if (stageDt.Columns.Contains(RMSColumn.SYS_OCC_TYPE_SCHEME))
                                            {
                                                dr[RMSColumn.SYS_OCC_TYPE_SCHEME] = objBulkCodeItem != null ? objBulkCodeItem["Schema"].ToString() + ": " + objBulkCodeItem["Code"].ToString() : objBulkCodeItem["Description"].ToString();
                                                dr[sovrmsdata.RMSFieldName] = row[sovrmsdata.RMSFieldName];
                                            }

                                            break;
                                        }
                                        else
                                        {
                                            if (dr[RMSColumn.SYS_OCC_TYPE_SCHEME] == null || string.IsNullOrEmpty(dr[RMSColumn.SYS_OCC_TYPE_SCHEME].ToString()))
                                            {
                                                if (selOccupancyList["description"] != null)
                                                    dr[RMSColumn.SYS_OCC_TYPE_SCHEME] = selOccupancyList["schema"].ToString() + ": " + selOccupancyList["code"].ToString();
                                                dr[sovrmsdata.RMSFieldName] = row[sovrmsdata.RMSFieldName];
                                            }
                                            if (sovrmsdata.RMSFieldName != RMSColumn.SYS_OCC_TYPE_SCHEME)
                                            {
                                                dr[sovrmsdata.RMSFieldName] = row[sovrmsdata.RMSFieldName];
                                            }
                                        }
                                    }


                                }

                                else
                                {
                                    if (sovrmsdata.RMSFieldName == RMSColumn.SYS_OCC_TYPE_SCHEME)
                                    {

                                    }
                                    else
                                    {
                                        dr[sovrmsdata.RMSFieldName] = row[sovrmsdata.RMSFieldName];
                                    }
                                }
                            }
                            else
                            {
                                dr[sovrmsdata.RMSFieldName] = row[sovrmsdata.RMSFieldName];
                            }

                        }
                        if (dr[RMSColumn.OCC_TYPE] == null || string.IsNullOrEmpty(dr[RMSColumn.OCC_TYPE].ToString()))
                        {
                            dr[RMSColumn.OCC_TYPE] = row[RMSColumn.OCC_TYPE];
                        }
                        dr[RMSColumn.SYS_CNTRY_CODE_SCHEME] = row[RMSColumn.SYS_CNTRY_CODE_SCHEME];
                        dr[RMSColumn.SYS_BLDG_CLASS_SCHEME] = row[RMSColumn.SYS_BLDG_CLASS_SCHEME];
                        dr[RMSColumn.ISO2A_CNTRY_CODE] = row[RMSColumn.ISO2A_CNTRY_CODE];
                        stageDt.Rows.Add(dr);
                    }
                }

                occDt = stageDt;
            }
            else
            {
                occDt = dt;
            }

            bool isoccscheme = dt.Columns.Contains(RMSColumn.OCC_SCHEME);

            occDt.AsEnumerable().ToList<DataRow>().ForEach(r =>
            {
                r[RMSColumn.SYS_OCC_TYPE_SCHEME] = string.IsNullOrEmpty(r[RMSColumn.SYS_OCC_TYPE_SCHEME].ToString()) ? isoccscheme ? string.IsNullOrEmpty(r[RMSColumn.OCC_SCHEME].ToString()) ? (r[RMSColumn.OCC_TYPE]) : $"{r[RMSColumn.OCC_SCHEME]}: {r[RMSColumn.OCC_TYPE]}" : r[RMSColumn.OCC_TYPE] : r[RMSColumn.SYS_OCC_TYPE_SCHEME];
            });
            return occDt;
        }
        #endregion


        #region private methods
        private static dynamic GetMappingFinalList(List<ISOVtoRMSFieldsBE> l_SOVRMSMappingBE, List<MappingIODefBE> lst)
        {
            var mappingList = from order in l_SOVRMSMappingBE
                              join plan in lst
                                   on order.RMSFieldName equals plan.ToFieldName
                              where order.SOVFieldName.Equals(plan.FromFieldName, StringComparison.OrdinalIgnoreCase) || (plan.FromFieldName == null && plan.BulkCodeValue != null)
                              select (new
                              {
                                  order.RMSFieldGUID,
                                  order.SOVFieldGUID.Value,
                                  order.RMSDescription,
                                  plan.BulkCodeValue,
                                  plan.AdjustValue,
                                  plan.FromFieldName,
                                  order.RMSFieldName,
                                  order.IsMostCommon,
                                  order.IsPrimaryChar,
                                  order.IsRequired,
                                  order.IsValueField,
                                  order.IsAdjustValue,
                                  order.IsSecModByCntry,
                                  order.IsMappAvailable,
                                  order.IsLimitToList,
                                  order.IsSecMods,
                                  order.IsBulkCodeAvailable,
                                  order.DescriptiveName,
                                  plan.KeyWordSearch,
                                  order.IsKeyWordSearchAvailable
                              });

            var finalList = mappingList.ToList().GroupBy(x => x.RMSFieldGUID).Select(y => y.FirstOrDefault());
            return finalList;
        }

        private static List<ISOVtoRMSFieldsBE> GetSovDataHeaderColumns(List<ISOVtoRMSFieldsBE> l_SOVRMSResultBE, List<ISOVtoRMSFieldsBE> l_userISOVRMSMappingBE, List<string> sovCols)
        {
            l_SOVRMSResultBE.AddRange(l_userISOVRMSMappingBE.Join(sovCols, x => x.SOVFieldName.ToLower(), y => y.ToLower(), (x, y) =>
                        new SOVtoRMSFieldBE()
                        {
                            Priority = x.Priority,
                            SOVFieldGUID = x.SOVFieldGUID,
                            SOVFieldName = y,
                            RMSFieldGUID = x.RMSFieldGUID,
                            RMSFieldName = x.RMSFieldName,
                            RMSFieldType = x.RMSFieldType,
                            RMSDescription = x.RMSDescription,
                            DescriptiveName = x.DescriptiveName,
                            IsAdjustValue = x.IsAdjustValue,
                            IsBulkCodeAvailable = x.IsBulkCodeAvailable,
                            IsMappAvailable = true,
                            IsMostCommon = x.IsMostCommon,
                            IsPrimaryChar = x.IsPrimaryChar,
                            IsRequired = x.IsRequired,
                            IsSecMods = x.IsSecMods,
                            IsValueField = x.IsValueField,
                            IsLimitToList = x.IsLimitToList,
                            orderNum = x.orderNum,
                            IsSecModByCntry = x.IsSecModByCntry,
                            RequiredOptionalOrBoth = x.RequiredOptionalOrBoth,
                            IsKeyWordSearchAvailable = x.IsKeyWordSearchAvailable
                        }).ToList());
            return l_SOVRMSResultBE;
        }

        private static List<ISOVtoRMSFieldsBE> GetSovToRmsFieldsResult(List<ISOVtoRMSFieldsBE> l_SOVRMSResultBE, List<ISOVtoRMSFieldsBE> l_ISOVRMSdistMappingBE)
        {
            l_SOVRMSResultBE.AddRange(l_ISOVRMSdistMappingBE.Where(y => !l_SOVRMSResultBE.Any(s => s.RMSFieldGUID == y.RMSFieldGUID)).
                                           Select(x => new SOVtoRMSFieldBE()
                                           {
                                               Priority = x.Priority,
                                               RMSFieldGUID = x.RMSFieldGUID,
                                               RMSFieldName = x.RMSFieldName,
                                               RMSFieldType = x.RMSFieldType,
                                               RMSDescription = x.RMSDescription,
                                               DescriptiveName = x.DescriptiveName,
                                               IsAdjustValue = x.IsAdjustValue,
                                               IsBulkCodeAvailable = x.IsBulkCodeAvailable,
                                               IsMappAvailable = false,
                                               IsMostCommon = x.IsMostCommon,
                                               IsPrimaryChar = x.IsPrimaryChar,
                                               IsRequired = x.IsRequired,
                                               IsSecMods = x.IsSecMods,
                                               IsValueField = x.IsValueField,
                                               IsLimitToList = x.IsLimitToList,
                                               orderNum = x.orderNum,
                                               IsSecModByCntry = x.IsSecModByCntry,
                                               RequiredOptionalOrBoth = x.RequiredOptionalOrBoth,
                                               IsKeyWordSearchAvailable = x.IsKeyWordSearchAvailable
                                           }).ToList());
            return l_SOVRMSResultBE;
        }

        #endregion

        #region MappingIssues

        /// <summary>
        /// Get List of General Mapping Issues from Uploaded SOV File
        /// </summary>
        /// <param name="sovToRmsMappingmodel"></param>
        /// <param name="rmsdt"></param>
        /// <returns></returns>
        //validation to be done on rms fields with
        //select distinct rms_field_name from t_emp_rms_fields where is_limitto_list=1 and is_secondary_mods_bycntry=0
        public List<MappingDataIssuesDto> GetGeneralMappingIssues(SaveSovToRmsMappingDto sovToRmsMappingmodel, DataTable rmsdt, string loginId)
        {
            List<MappingDataIssuesDto> mappingIssues = new List<MappingDataIssuesDto>();
            int fileProcessingTaskGuid = sovToRmsMappingmodel.FileProcessingTaskGuid;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var sovRMSMappingList = sovToRmsMappingmodel.SOVRMSMappingList.Where(sm => sm.IsMappAvailable == true && sm.SOVFieldName != null && sm.IsLimitToList == true && sm.IsSecModByCntry != true && !sm.RMSFieldName.ToLower().Contains("scheme"));
                List<string> ids;

                if (sovRMSMappingList.Count() > 0)
                {
                    var lookUpValues = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
                    foreach (SOVRMSDetails rmsField in sovRMSMappingList)
                    {
                        var l_LimitToListBE = lookUpValues.Where(S => S.RMSFieldGuid == rmsField.RMSFieldGUID).OrderBy(x => x.OrderNum)
                                 .Select(x => new BulkCodeItem() { Lookup = x.LookUp, Description = x.Description, Code = x.Code, Schema = x.EMPSchemeName, BulkOption = x.BulkOption == true ? 1 : 0 }).Distinct().ToList();
                        if (l_LimitToListBE.Count() > 0)
                        {
                            if (rmsField.RMSFieldName == RMSColumn.CNTRY_CODE | rmsField.RMSFieldName == RMSColumn.BLDG_CLASS | rmsField.RMSFieldName == RMSColumn.OCC_TYPE)
                                ids = rmsdt.AsEnumerable().Select(r => r[$"sys{rmsField.RMSFieldName.ToLower()}scheme"].ToString()).ToList();
                            else
                                ids = rmsdt.AsEnumerable().Select(r => r[rmsField.RMSFieldName].ToString()).ToList();
                            var lkupData = ids.Where(p => !l_LimitToListBE.Any(x => x.Lookup != null && x.Lookup.Equals(p, StringComparison.OrdinalIgnoreCase))).GroupBy(i => i);
                            var result = lkupData.Select(grp => new MappingDataIssuesDto
                            {
                                RMSFieldGUID = rmsField.RMSFieldGUID,
                                RMSFieldName = rmsField.RMSFieldName,
                                SOVFieldName = rmsField.SOVFieldName,
                                SOVSourceData = string.IsNullOrEmpty(grp.Key) ? null : grp.Key,
                                ISPrimaryCharact = true,
                                ISFillBlanks = true,
                                Count = grp.Count(),
                                RMSFieldLookUp = l_LimitToListBE.Where(x => x.BulkOption == 1).ToList()
                            }).ToList();
                            mappingIssues.AddRange(result);
                        }
                    }
                    if (mappingIssues.Count > 0)
                    {
                        mappingIssues = UpdateMappingIssues(mappingIssues, loginId);
                    }
                    mappingIssues = mappingIssues.OrderBy(x => x.RMSFieldName).ToList();
                }
                if (mappingIssues.Count > 0)
                {
                    XLTrace.Write("Stage - 3 : Retrieved General Mapping Issues Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);

                }
                else
                {
                    mappingIssues = this.GetSecModIssues(fileProcessingTaskGuid, rmsdt, loginId);
                    mappingIssues.AddRange(this.GetStateCodeIssues(fileProcessingTaskGuid, rmsdt, loginId));
                }
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 3 : Retrieving General Mapping Issues Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return mappingIssues;
        }

        /// <summary>
        /// Get List of Secondary Modifier Issues from Uploaded SOV File
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<MappingDataIssuesDto> GetSecModIssues(int fileProcessingTaskGuid, DataTable dt, string loginId)
        {
            List<MappingDataIssuesDto> mappingIssues = new List<MappingDataIssuesDto>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
                fileProcessingTasksBE.FileProcessingTaskGuid = fileProcessingTaskGuid;
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);

                List<SOVRMSDetails> sOVRMSDetails = this.GetSOVtoRMSMapppedData(fileProcessingTaskGuid);
                var sovRMSMappingList = sOVRMSDetails.Where(sm => sm.IsMappAvailable == true && sm.SOVFieldName != null && sm.IsLimitToList == true && sm.IsSecModByCntry == true);
                if (sovRMSMappingList.Count() > 0)
                {
                    var secModValues = this.GetSecModLookups(fileProcessingTaskGuid);
                    foreach (SOVRMSDetails rmsField in sovRMSMappingList)
                    {
                        var l_SecMods = secModValues.Where(S => S.RMSFieldGUID == rmsField.RMSFieldGUID).ToList();
                        if (l_SecMods.Count() > 0)
                        {
                            var query = dt.AsEnumerable().
                                   Select(item => new
                                   {
                                       RMSFieldValues = item.Field<string>(rmsField.RMSFieldName),
                                       CountryCode = item.Field<string>(RMSColumn.ISO2A_CNTRY_CODE),
                                       Scheme = l_SecMods.Where(x => x.Country_Code == item.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)).Select(x => x.SchemeName).FirstOrDefault()
                                   }).ToList();

                            var result = query.Where(p => (!string.IsNullOrEmpty(p.Scheme) && !l_SecMods.Where(x => x.SchemeName == p.Scheme).Any(x => x.LookUp.Equals(p.RMSFieldValues))))
                                .GroupBy(x => new { x.Scheme, x.RMSFieldValues, x.CountryCode }).ToList()
                                  .Select(grp => new MappingDataIssuesDto
                                  {
                                      RMSFieldGUID = rmsField.RMSFieldGUID,
                                      RMSFieldName = rmsField.RMSFieldName,
                                      SOVFieldName = rmsField.SOVFieldName,
                                      SOVSourceData = grp.Key.RMSFieldValues,
                                      Scheme = grp.Key.Scheme,
                                      CountryCode = grp.Key.CountryCode,
                                      ISSecondCharact = true,
                                      ISFillBlanks = true,
                                      Count = grp.Count(),
                                  }).ToList();
                            result.ForEach(x =>
                            {
                                x.RMSFieldLookUp = l_SecMods.Where(a => a.SchemeName == x.Scheme && a.BulkOption == 1).OrderBy(xc => xc.OrderNum).Select(b => new { b.LookUp, b.SchemeName, b.Description }).Distinct()
                                            .Select(y => new BulkCodeItem() { Code = y.LookUp, Description = y.Description, Schema = y.SchemeName }).Distinct().OrderBy(b => b.Schema).ThenBy(c => c.Code).ToList();
                            });
                            mappingIssues.AddRange(result);
                        }
                    }
                    if (mappingIssues.Count > 0)
                    {
                        mappingIssues = UpdateMappingIssues(mappingIssues, loginId);
                    }
                    mappingIssues = mappingIssues.OrderBy(x => x.RMSFieldName).ToList();
                }
                if (mappingIssues.Count > 0)
                {
                    XLTrace.Write("Stage - 3 : Retrieved Secondary Modifier Related Issues Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);

                }
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 3 : Retrieving Secondary Modifier Related Issues Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return mappingIssues;
        }

        /// <summary>
        /// Get List of Statecode Issues from Uploaded SOV File
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<MappingDataIssuesDto> GetStateCodeIssues(int fileProcessingTaskGuid, DataTable dt, string loginId)
        {
            List<MappingDataIssuesDto> mappingIssues = new List<MappingDataIssuesDto>();
            try
            {
                FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
                fileProcessingTasksBE.FileProcessingTaskGuid = fileProcessingTaskGuid;
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                List<SOVRMSDetails> sOVRMSDetails = this.GetSOVtoRMSMapppedData(fileProcessingTaskGuid);
                var sovRMSMappingList = sOVRMSDetails.Where(sm => sm.IsMappAvailable == true && (sm.SOVFieldName != null || sm.IsBulkCodeAvailable == true));
                if (sovRMSMappingList.Count() > 0 && (sovRMSMappingList.Any(x => x.RMSFieldName == RMSColumn.STATE_CODE) || dt.Columns.Contains(RMSColumn.STATE_CODE)) && sovRMSMappingList.Any(x => x.RMSFieldName == RMSColumn.CNTRY_CODE))
                {
                    var l_stateCntryValues = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
                    l_stateCntryValues = l_stateCntryValues.Where(x => x.RMSFieldName == RMSColumn.STATE_CODE);
                    SOVRMSDetails stateCodeMapping = new SOVRMSDetails();
                    stateCodeMapping.RMSFieldName = RMSColumn.STATE_CODE;
                    stateCodeMapping.RMSFieldGUID = l_stateCntryValues.First().RMSFieldGuid;
                    stateCodeMapping.SOVFieldName = sovRMSMappingList.Any(x => x.RMSFieldName == RMSColumn.STATE_CODE) ? sovRMSMappingList.Where(x => x.RMSFieldName == RMSColumn.STATE_CODE).Select(x => x.SOVFieldName).FirstOrDefault().ToString() : RMSColumn.STATE;
                    if (l_stateCntryValues.Count() > 0)
                    {
                        var sourceData = dt.AsEnumerable().
                                   Select(item => new
                                   {
                                       StateCodeValues = item.Field<string>(stateCodeMapping.RMSFieldName),
                                       CountryCode = item.Field<string>(RMSColumn.ISO2A_CNTRY_CODE),
                                   }).ToList();
                        var result = sourceData.Where(p => l_stateCntryValues.Any(x => x.ISO2ACountryCode.ToLower() == p.CountryCode.ToLower()) && !l_stateCntryValues.Where(x => x.ISO2ACountryCode.ToLower() == p.CountryCode.ToLower()).Select(x => x.LookUp.ToLower()).Contains(p.StateCodeValues.ToLower()))
                            .GroupBy(x => new { x.CountryCode, x.StateCodeValues }).ToList()
                              .Select(grp => new MappingDataIssuesDto
                              {
                                  RMSFieldGUID = stateCodeMapping.RMSFieldGUID,
                                  RMSFieldName = stateCodeMapping.RMSFieldName,
                                  SOVFieldName = stateCodeMapping.SOVFieldName,
                                  SOVSourceData = grp.Key.StateCodeValues,
                                  Scheme = grp.Key.CountryCode,
                                  CountryCode = grp.Key.CountryCode,
                                  RMSFieldLookUp = l_stateCntryValues.Where(x => x.ISO2ACountryCode == grp.Key.CountryCode)
                                   .GroupBy(x =>
                                            new
                                            {
                                                x.Code,
                                                x.Description

                                            }).Select(y => new BulkCodeItem
                                            {
                                                Code = y.Key.Code,
                                                Description = y.Key.Description
                                            }).ToList(),
                                  ISStateCodeIssue = true,
                                  ISFillBlanks = true,
                                  Count = grp.Count(),
                              }).ToList();
                        mappingIssues.AddRange(result);
                    }
                    if (mappingIssues.Count > 0)
                    {
                        mappingIssues = UpdateMappingIssues(mappingIssues, loginId);
                    }
                    mappingIssues = mappingIssues.OrderBy(x => x.RMSFieldName).ToList();
                }
                if (mappingIssues.Count > 0)
                {
                    XLTrace.Write("Stage - 3 : Retrieved State Code Related Issues Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);

                }
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 3 : Retrieving State Code Related Issues Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return mappingIssues;
        }



        /// <summary>
        /// Update stage data
        /// </summary>
        /// <param name="fileDataProcessingBE"></param>
        /// <returns></returns>
        public FileDataProcessingBE UpdateStageData(FileDataProcessingBE fileDataProcessingBE)
        {
            FileDataProcessingBE resFileDataProcessing = new FileDataProcessingBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileDataProcessingBE fileDataProcessing = new FileDataProcessingBE();
                this.GetFileDetailByTaskGuid(fileDataProcessingBE.FileProcessingTaskGuid.Value);
                fileDataProcessing = GetFileProcessingTask(fileDataProcessingBE.FileProcessingTaskGuid.Value);
                fileDataProcessing.StageData = fileDataProcessingBE.StageData;
                fileDataProcessing.ChangedStatus = EntityStatus.StatusUpdate;
                fileDataProcessing.SelectedOccupancy = fileDataProcessingBE.SelectedOccupancy;
                resFileDataProcessing = SaveBusinessEntity((FileDataProcessingBE)fileDataProcessing);
                XLTrace.Write("Saved Intermediate RMS Converted Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                return resFileDataProcessing;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Intermediate RMS Converted Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Update Converted Data
        /// </summary>
        /// <param name="fileDataProcessingBE"></param>
        /// <returns></returns>
        public FileDataProcessingBE UpdateConvertedData(FileDataProcessingBE fileDataProcessingBE)
        {
            FileDataProcessingBE resFileDataProcessing = new FileDataProcessingBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileDataProcessingBE fileDataProcessing = new FileDataProcessingBE();
                this.GetFileDetailByTaskGuid(fileDataProcessingBE.FileProcessingTaskGuid.Value);
                fileDataProcessing = GetFileProcessingTask(fileDataProcessingBE.FileProcessingTaskGuid.Value);
                fileDataProcessing.ConvertedData = fileDataProcessingBE.ConvertedData;
                fileDataProcessing.ChangedStatus = EntityStatus.StatusUpdate;

                resFileDataProcessing = SaveBusinessEntity((FileDataProcessingBE)fileDataProcessing);
                XLTrace.Write("Stage - 4 : Saved Final RMS Converted Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 4 : Saving Final RMS Converted Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return resFileDataProcessing;
        }
        public DocumentBE SaveDocumentFileStatus(int fileProcessingTaskGuid)
        {
            DocumentBE document = new DocumentBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                document = this.GetDocumentByOwnerGuid(fileProcessingTaskGuid);
                document.FileStatus = 1;
                document.ChangedStatus = EntityStatus.StatusUpdate;
                document = SaveBusinessEntity((DocumentBE)document);
                XLTrace.Write("Stage - 4 : Saved document file status Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, fileProcessingTaskGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 4 : Saving Final RMS Converted Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return document;
        }

        /// <summary>
        /// Save Mapping Definition
        /// </summary>
        /// <param name="saveSovRmsMappingBE"></param>
        /// <returns></returns>
        public MappingDefBE SaveMappingDef(MappingDefBE mappingDefBE, string mode)
        {
            MappingDefBE resMappingDef = new MappingDefBE();
            FileProcessingTasksBE fileProcessing = new FileProcessingTasksBE();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                fileProcessing = this.GetFileProcessingTaskByOwnerGuid(mappingDefBE.OwnerGuid.Value);
                fileProcessing.StatusGuid = (int)EMPStatus.Uploaded;
                fileProcessing.FileProcessingTaskGuid = mappingDefBE.OwnerGuid;
                fileProcessing.ChangedStatus = EntityStatus.StatusUpdate;

                var mappingData = mappingDefBE.MappingIODefCollection.Where(x => !string.IsNullOrEmpty(x.FromFieldName)).ToList();
                var mappedList = this.GetSovToRMSMappedDataList(mappingDefBE.OwnerGuid.Value).Where(x => !string.IsNullOrEmpty(x.FromFieldName)).ToList();
                if (mappedList.Count() > 0)
                {
                    var newlyAddedorUpdated = mappingData.Where(x => !mappedList.Any(y => y.FromFieldName.ToLower() == x.FromFieldName.ToLower())).ToList();
                    //update only mapping_count of newly added mapping 
                    if ((mappingData.Count() > mappedList.Count()) || newlyAddedorUpdated.Count() > 0)
                    {
                        if (newlyAddedorUpdated.Count() > 0)
                        {
                            mappingData.Clear();
                            mappingData = newlyAddedorUpdated;
                        }
                    }
                    else
                    {
                        mappingData.Clear();
                    }
                }

                if (!string.IsNullOrEmpty(mode) && mode == "overwrite")
                {
                    UpdateMappingDef(mappingDefBE.OwnerGuid.Value);
                }
                this.DeleteMappDef(mappingDefBE.OwnerGuid.Value);
                SaveBusinessEntity((FileProcessingTasksBE)fileProcessing);
                mappingDefBE.ProgramFileGuid = fileProcessing.ProgramFileGuid;
                mappingDefBE.MappingIODefCollection.ToList().ForEach(x => x.ProgramGuid = fileProcessing.ProgramGuid);
                mappingDefBE.MappingIODefCollection.ToList().ForEach(x => x.ActiveInd = true);
                resMappingDef = SaveBusinessEntity((MappingDefBE)mappingDefBE);
                //update mapping count
                updateSOVMappingCount(mappingData, mappingDefBE.OwnerGuid.Value);
                XLTrace.Write("Stage - 2 : Saved SOV To RMS Mapping Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, fileProcessing.ProgramFileGuid);
                return resMappingDef;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Saving SOV To RMS Mapping Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, fileProcessing.ProgramFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Update SOV Mapping Count
        /// </summary>
        /// <param name="mappingIODefBEs"></param>
        public void updateSOVMappingCount(List<MappingIODefBE> mappingIODefBEs, int fileProcessingGuid)
        {
            var l_SOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            List<TempSOVRMSMappingBE> lsttempSOVRMSMappingBE = new List<TempSOVRMSMappingBE>();
            DocumentBE document = this.GetDocumentByOwnerGuid(fileProcessingGuid);
            l_SOVRMSMappingBE = this.GetSovtoRMSFields(document != null ? document.Type : "1");
            foreach (var mappingList in mappingIODefBEs)
            {
                TempSOVRMSMappingBE tempSOVRMSMappingBE = new TempSOVRMSMappingBE();
                int? mappedCount = l_SOVRMSMappingBE.Where(x => x.SOVFieldName.ToLower() == mappingList.FromFieldName.ToLower() && x.RMSFieldName.ToLower() == mappingList.ToFieldName.ToLower()).Select(x => x.MappingCount).FirstOrDefault();
                if (mappedCount.HasValue && mappedCount.Value > 0)
                {
                    mappedCount++;
                }
                else
                {
                    mappedCount = 1;
                }

                var sovMapping = l_SOVRMSMappingBE.Where(x => x.SOVFieldName.ToLower() == mappingList.FromFieldName.ToLower() && x.RMSFieldName.ToLower() == mappingList.ToFieldName.ToLower()).FirstOrDefault();
                if (sovMapping != null)
                {
                    tempSOVRMSMappingBE = new TempSOVRMSMappingBE()
                    {
                        SOVFieldGuid = sovMapping.SOVFieldGUID,
                        RMSFieldGuid = sovMapping.RMSFieldGUID,
                        SOVFieldName = sovMapping.SOVFieldName,
                        MappingCount = mappedCount,
                        ActiveInd = true,
                        IsTempMapping = sovMapping.IsTemporaryMapping,
                        Priority = sovMapping.Priority,
                        Version = sovMapping.Version,
                        AddedApp = sovMapping.AddedApp,
                        AddedDt = sovMapping.AddedDt,
                        AddedBy = sovMapping.AddedBy,
                        ChangedStatus = EntityStatus.StatusUpdate
                    };
                    SaveBusinessEntity<TempSOVRMSMappingBE>(tempSOVRMSMappingBE);
                }
            }
        }

        #endregion

        #region SOVToRMSConversion

        /// <summary>
        /// Retrieve Secondary Modifier lookup
        /// </summary>
        /// <returns></returns>
        public List<SecModLookupBE> GetSecModLookups(int fileProcessingTaskGuid)
        {
            List<SecModLookupBE> secModLookups = new List<SecModLookupBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                secModLookups = _empDAC.GetSecModLookups<SecModLookupBE>();
                XLTrace.Write("Retrieved all Secondary Modifier Lookup Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all Secondary Modifier Lookup Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return secModLookups;
        }

        /// <summary>
        /// Get List of Carribean Countries 
        /// </summary>
        /// <returns></returns>
        public List<LookUpCBCountriesBE> GetCBcountries(int fileProcessingTaskGuid)
        {
            List<LookUpCBCountriesBE> lstlookUpCBCountries = new List<LookUpCBCountriesBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                lstlookUpCBCountries = _empDAC.GetCBCountries<LookUpCBCountriesBE>();
                XLTrace.Write("Stage - 4 : Retrieved all CB Countries Country Code Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 4 : Retrieving all CB Countries Country Code Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return lstlookUpCBCountries;

        }


        /// <summary>
        /// Get Default Mappings
        /// </summary>
        /// <returns></returns>
        public List<DefaultMappingFieldsBE> GetDefaultMappings(int fileProcessingTaskGuid, int programFileGuid)
        {
            List<DefaultMappingFieldsBE> lstdefaultMappingFields = new List<DefaultMappingFieldsBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                lstdefaultMappingFields = _empDAC.GetDefaultMappingFields<DefaultMappingFieldsBE>();
                XLTrace.Write("Stage - 2 : Retrieved Final RMS Column list from Default Mappings Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Retrieved Final RMS Column list from Default Mappings Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return lstdefaultMappingFields;

        }

        /// <summary>
        /// Getting RMS Converted Data
        /// </summary>
        /// <param name="fileTaskGuid"></param>
        /// <returns></returns>
        public DataTable GetRMSConvertedData(int fileTaskGuid, string mode)
        {
            DataTable rmsdata = new DataTable();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileTaskGuid);
                XLTrace.Write("Stage - 4 : Started Final RMS Conversion Logic Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
                var list = new List<dynamic>();
                string[] rmsfields = { RMSColumn.BLDG_SCHEME, RMSColumn.BLDG_CLASS, RMSColumn.OCC_SCHEME, RMSColumn.OCC_TYPE, RMSColumn.CVPDVAL,
                RMSColumn.CV1VAL, RMSColumn.CV2VAL, RMSColumn.CV3VAL, RMSColumn.CV4VAL, RMSColumn.CV5VAL, RMSColumn.CV6VAL, RMSColumn.CV7VAL, RMSColumn.CV8VAL, RMSColumn.CV9VAL,
                 RMSColumn.CV10VAL, RMSColumn.CNTRY_SCHEME };
                string[] rmsVALFields = { RMSColumn.CVPDVAL, RMSColumn.CV1VAL, RMSColumn.CV2VAL, RMSColumn.CV3VAL, RMSColumn.CV9VAL };
                var l_SOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
                l_SOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)this.GetSovtoRMSFields();

                List<SOVtoRMSFieldBE> l_RMSFields = l_SOVRMSMappingBE.GroupBy(x =>
                       new
                       {
                           x.RMSFieldName,
                           x.IsLimitToList,
                           x.orderNum,
                           x.IsSecModByCntry,
                           x.RMSFieldType
                       }).Select(y => new SOVtoRMSFieldBE
                       {
                           RMSFieldName = y.Key.RMSFieldName,
                           IsLimitToList = y.Key.IsLimitToList,
                           orderNum = y.Key.orderNum,
                           IsSecModByCntry = y.Key.IsSecModByCntry,
                           RMSFieldType = y.Key.RMSFieldType
                       }).ToList();
                FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
                fileProcessingTasksBE.FileProcessingTaskGuid = fileTaskGuid;

                var data = this.Materialize(fileProcessingTasksBE, null);
                var filedataCol = data.FileDataColl.OrderByDescending(x => x.PrimaryKey).FirstOrDefault();
                DataTable dt = (DataTable)JsonConvert.DeserializeObject(FileAdaptor.Decompress(filedataCol.StageData), (typeof(DataTable)));
                var limitTo = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
                //var l_stateCntryValues = GetStateCountryLookups();
                var rmscolumns = data.MappingDefColl[0].MappingIODefCollection.Where(x => (!string.IsNullOrEmpty(x.FromFieldName) || !string.IsNullOrEmpty(x.BulkCodeValue) || x.KeyWordSearch == "true")).Select(x => x.ToFieldName).ToList();
                //RMS fields
                l_RMSFields.Where(x => rmscolumns.Any(r => x.RMSFieldName == r)).ToList()
                    .ForEach(x => x.IsMappAvailable = true);
                var rmsfieldslistnotVal = l_RMSFields.Where(x => x.IsMappAvailable == true && x.IsSecModByCntry == false && !rmsfields.Contains(x.RMSFieldName)).ToList();
                int CurrentYr = DateTime.Now.Year;

                //RMS val fields
                var rmsfieldslistVal = l_RMSFields.Where(x => x.RMSFieldName.Contains(RMSValue.VAL) && x.RMSFieldName.Contains(RMSValue.CV)).Select(x => x.RMSFieldName).Distinct().ToList<string>();
                double val;
                double cvval;
                if (rmsfieldslistVal.Count > 0)
                {
                    foreach (string rmsvalfield in rmsfieldslistVal)
                    {
                        if (l_RMSFields.Any(x => x.IsMappAvailable == true && x.RMSFieldName == rmsvalfield))
                        {
                            dt.AsEnumerable().ToList().ForEach(y =>
                            {

                                var fieldVal = y[rmsvalfield].ToString();
                                double.TryParse(fieldVal, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out cvval);
                                if (rmsvalfield == RMSColumn.CV3VAL)
                                    val = double.Parse((fieldVal == null) ? "0.00" : Math.Abs(Convert.ToDouble(fieldVal.ToString())).ToString());
                                else
                                    val = double.Parse((fieldVal == null) ? "0.00" : Val(fieldVal.ToString()).ToString());
                                y.SetField(rmsvalfield, val);
                                //return y;
                            });
                        }
                        else if (!dt.Columns.Contains(rmsvalfield) && rmsVALFields.Contains(rmsvalfield))
                        {
                            dt.Columns.Add(rmsvalfield, typeof(double));
                            dt.AsEnumerable().ToList().ForEach(y =>
                            {
                                y.SetField(rmsvalfield, 0);
                                //return y;
                            });

                        }
                    }
                }
                rmsdata = dt;

                XLTrace.Write("Stage - 4 : Completed Final RMS Conversions Logic Successfully", Constants.C_LOGGING_USER_ACTIVITY, TraceEventType.Information, _programGuid, _programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 4 : Final RMS Conversions Logic Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

            return rmsdata;

        }
        public void GetLimitToListLookup()
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var limitTo = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
                IEnumerable<ILimitToListBE> l_LimitToListBE = limitTo.ToList();
                BulkCodeValues l_BulkCodeValues = null;
                if (l_LimitToListBE.Count() > 0)
                {
                    bool isSchemeAvail = l_LimitToListBE.Any(x => !string.IsNullOrEmpty(x.EMPSchemeName));
                    l_BulkCodeValues = new BulkCodeValues
                    {
                        IsSchemeReq = isSchemeAvail,
                        Note = string.Empty,
                        BulkCodes = l_LimitToListBE.OrderBy(x => x.OrderNum).Select(S => new BulkCodeItem
                        {
                            Code = S.Code,
                            Description = S.Description,
                            Schema = S.EMPSchemeName
                        }).ToList()
                    };
                }
            }
            catch (Exception ex)
            {
                XLTrace.Write(ex.Message, ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Final RMS Conversion
        /// </summary>
        /// <param name="fileprocessingTaskGuid"></param>
        /// <param name="dt"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public DataTable FinalConversion(int fileprocessingTaskGuid, DataTable dt, string mode)
        {
            if (dt.Columns.Contains(RMSColumn.OCC_TYPE))
            {
                MappingDefBE mappingDefBE = new MappingDefBE();
                mappingDefBE.OwnerGuid = fileprocessingTaskGuid;
                var data = base.Materialize<MappingDefBE>(mappingDefBE, null);
                JObject jObject = JObject.Parse(data.SelectedOccupancy);
                EMPDAC empDAC = new EMPDAC();
                var occBldgClassValues = empDAC.GetOccBldClassValues<OccBldClassLookupBE>();
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.OCC_TYPE) == "0")).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.OCC_TYPE, (string)jObject.Property("code").Value);
                    var occSelectedValue = occBldgClassValues.Where(y => y.Description == (string)jObject.Property("description").Value && y.Code == (string)jObject.Property("code").Value && y.BulkOption == 1);
                    x.SetField(RMSColumn.OCC_SCHEME, occSelectedValue.FirstOrDefault().EMPSchemeName);
                    x.SetField(RMSColumn.O_ATC, occSelectedValue.FirstOrDefault().O_ATC);
                    x.SetField(RMSColumn.O_IFM_2_digit, occSelectedValue.FirstOrDefault().O_IFM_2digit);
                    x.SetField(RMSColumn.O_IFM_4_digit, occSelectedValue.FirstOrDefault().O_IFM_4digit);
                });
            }

            if (!dt.Columns.Contains(RMSColumn.ID))
            {
                DataColumn dc = new DataColumn(RMSColumn.ID);
                dt.Columns.Add(dc);
            }
            int i = 1;
            if (mode == "append")
            {
                var locationDetails = _empDAC.GetRMSData(_programGuid.Value, RMSColumn.ID);
                i = Convert.ToInt32(locationDetails.Compute("max([ID])", string.Empty));
                if (i > 0)
                {
                    i++;
                }
            }

            dt.AsEnumerable().ToList().ForEach(x =>
            {
                x[RMSColumn.ID] = i++;
            });

            string path = HttpContext.Current.Server.MapPath("~/Config/BldngOccUpdateLogic.xml");
            XmlSerializer serializer = new XmlSerializer(typeof(BldOccUpdates));
            BldOccUpdates list = new BldOccUpdates();
            DataTable result = dt.Copy();
            using (StreamReader reader = new StreamReader(path))
            {
                list = (BldOccUpdates)serializer.Deserialize(reader);
            }
            if (list.UpdateLogic.Count() > 0)
            {
                List<OccBldClassLookupBE> occbldlist = new List<OccBldClassLookupBE>();

                foreach (UpdateLogic up in list.UpdateLogic.Where(x => x.Category == null))
                {
                    string strFilter = string.Empty;
                    DataView dv = new DataView(dt);
                    foreach (var filterItem in up.FilterExpression)
                    {
                        strFilter += $"( ";
                        foreach (var f in filterItem.Filters.Filter)
                        {
                            strFilter += $" (IsNull({f.Column},'') {f.Operator} {f.Value}) {f.JoiningOperator}";
                        }

                        strFilter += $") {filterItem.JoiningExpression} ";
                    }

                    dv.RowFilter = strFilter;

                    foreach (DataRowView dvItem in dv)
                    {
                        foreach (var targetItem in up.Target)
                        {
                            dvItem[targetItem.Column] = !string.IsNullOrEmpty(targetItem.SourceColumn) ? dvItem[targetItem.SourceColumn] : targetItem.Value;
                        }
                    }
                }
            }
            return dt;
        }


        /// <summary>
        /// Get Max Location Number by ProgramGuid
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>
        public int GetMaxLoctionNumber(int programGuid)
        {
            int maxLocationNumber = 0;
            var locationDetails = _empDAC.GetRMSData(programGuid, RMSColumn.LOC_NUM);
            maxLocationNumber = locationDetails.AsEnumerable().Max(x => Convert.ToInt32(x.Field<string>("LOCNUM")));
            if (maxLocationNumber > 0)
            {
                maxLocationNumber++;
            }
            return maxLocationNumber;
        }

        /// <summary>
        /// Adjustments of RMS IND
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable RMSINDAdjustments(DataTable dt)
        {
            EMPDAC empdac = new EMPDAC();
            var occBldclasslk = (IEnumerable<IOccBldClassLookupBE>)this.GetOccBldClassValues();
            IFMOccupancyBE ifmoccbe = new IFMOccupancyBE();
            var ifmocclst = base.MaterializeCollection<IFMOccupancyBE>(ifmoccbe, null);
            var lookup_IFMCountryDescriptionMapping = empdac.GetIFMCountryMapping<IFMRegionCntryMappingBE>();
            string[] schems = { "RMS BR", "EURO_FR", "RMSMARINE", "EURO", "RMS OP", "WCOCC", "JPOCC" };
            var bldIFM = occBldclasslk.Where(x => x.RMSFieldName == RMSColumn.BLDG_CLASS && x.O_IFM_4digit != null);

            //Updates [O_IFM_4-digit] in SOVrms where a RMS IND Occupancy can be inferred from the ATC Construction code - this doesn't change the actual OCCSHEME and OCCTPYE...But only where OCCSCHEME Not In ('RMS BR','EURO_FR','RMSMARINE','EURO','RMS OP','WCOCC','JPOCC')
            dt = dt.AsEnumerable().GroupJoin(bldIFM,
                           y => y.Field<string>(RMSColumn.C_ATC), x => x.C_ATC,
                           (y, x) =>
                           {
                               if (string.IsNullOrEmpty(y.Field<string>(RMSColumn.O_IFM_4_digit)) && !schems.Contains(y.Field<string>(RMSColumn.OCC_SCHEME)) && x.Count() > 0)
                                   y.SetField(RMSColumn.O_IFM_4_digit, x.FirstOrDefault().O_IFM_4digit);
                               return y;
                           }).CopyToDataTable();

            //Updates [O_IFM_2-digit] in SOVrms where is null and [O_IFM_4-digit] is populated...
            //this means that the [O_IFM_4-digit] was inferred from an ATC Occupancy - this doesn't change the actual OCCSHEME and OCCTPYE
            dt = dt.AsEnumerable().GroupJoin(ifmocclst,
                         y => y.Field<string>(RMSColumn.O_IFM_4_digit), x => Convert.ToString(x.Occ4digit),
                         (y, x) =>
                         {
                             if (string.IsNullOrWhiteSpace(y.Field<string>(RMSColumn.O_IFM_2_digit)) && x.Count() > 0)
                                 y.SetField(RMSColumn.O_IFM_2_digit, x.FirstOrDefault().Occ2digit);
                             return y;
                         }).CopyToDataTable();


            //Allocate CVPDVALs and then delete this column        
            if (dt.Columns.Contains(RMSColumn.CVPDVAL))
            {
                if (!dt.Columns.Contains(RMSColumn.CV1VAL))
                {
                    DataColumn column = new DataColumn(RMSColumn.CV1VAL, System.Type.GetType("System.Double"));
                    column.DefaultValue = 0;
                    dt.Columns.Add(column);
                }
                if (!dt.Columns.Contains(RMSColumn.CV2VAL))
                {
                    DataColumn column = new DataColumn(RMSColumn.CV2VAL, System.Type.GetType("System.Double"));
                    column.DefaultValue = 0;
                    dt.Columns.Add(column);
                }

                double cv1, cv2;
                dt = dt.AsEnumerable().GroupJoin(ifmocclst, x => x.Field<string>(RMSColumn.O_IFM_4_digit), y => Convert.ToString(y.Occ4digit),
                    (dr1, result) =>
                    {
                        if (result.Count() > 0)
                        {
                            //CV1 Calculation
                            double cv1CalculatedValue = 0;
                            if (double.TryParse(dr1[RMSColumn.CV1VAL].ToString(), out cv1))
                            {
                                if (!result.FirstOrDefault().Structure.HasValue)
                                {
                                    cv1CalculatedValue = 0.85;
                                }
                                else
                                {
                                    cv1CalculatedValue = result.FirstOrDefault().Structure.Value / Convert.ToDouble(100);
                                    cv1CalculatedValue *= (dr1.Field<double>(RMSColumn.CVPDVAL));
                                    cv1CalculatedValue = cv1 + cv1CalculatedValue;
                                }
                            }
                            //CV2 Calculation                          
                            double cv2CalculatedValue = 0;
                            if (double.TryParse(dr1[RMSColumn.CV2VAL].ToString(), out cv2))
                            {
                                if (!result.FirstOrDefault().Contents.HasValue)
                                {
                                    cv2CalculatedValue = 0.15;
                                }
                                else
                                {
                                    cv2CalculatedValue = result.FirstOrDefault().Contents.Value / Convert.ToDouble(100);
                                    cv2CalculatedValue *= (dr1.Field<double>(RMSColumn.CVPDVAL));
                                    cv2CalculatedValue = cv2 + cv2CalculatedValue;
                                }
                            }
                            dr1.SetField(RMSColumn.CV1VAL, double.TryParse(dr1[RMSColumn.CV1VAL].ToString(), out cv1) ? cv1CalculatedValue : cv1);
                            dr1.SetField(RMSColumn.CV2VAL, double.TryParse(dr1[RMSColumn.CV2VAL].ToString(), out cv1) ? cv2CalculatedValue : cv2);
                        }
                        else
                        {
                            dr1.SetField(RMSColumn.CV1VAL, double.TryParse(dr1[RMSColumn.CV1VAL].ToString(), out cv1) ? (cv1 + (0.85 * dr1.Field<double>(RMSColumn.CVPDVAL))) : cv1);
                            dr1.SetField(RMSColumn.CV2VAL, double.TryParse(dr1[RMSColumn.CV2VAL].ToString(), out cv2) ? (cv2 + (0.15 * dr1.Field<double>(RMSColumn.CVPDVAL))) : cv2);
                        }
                        return dr1;
                    }).CopyToDataTable();


                dt.Columns.Remove(RMSColumn.CVPDVAL);
            }

            //country ifm mappings
            //'Update Occupancy to RMS IND where it's not already an RMS IND code and RMS IND is valid:
            dt = dt.AsEnumerable().
                GroupJoin(lookup_IFMCountryDescriptionMapping.Where(x => x.IFM2or4digitOcc != RMSValue.TWO_DIGIT), x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
               (x, y) =>
               {
                   if (y?.Count() > 0 && x?.Field<string>(RMSColumn.OCC_SCHEME) != RMSValue.RMS_IND && x.Field<string>(RMSColumn.O_IFM_4_digit)?.Length > 0)
                   {
                       x.SetField(RMSColumn.OCC_SCHEME, RMSValue.RMS_IND);
                       x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.O_IFM_4_digit));
                   }
                   return x;
               }).CopyToDataTable();

            //'Update Occupancy to RMS IND where it's not already an RMS IND code and RMS IND is valid:'for 2-digit countries...
            dt = dt.AsEnumerable().
               GroupJoin(lookup_IFMCountryDescriptionMapping.Where(x => x.IFM2or4digitOcc == RMSValue.TWO_DIGIT), x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
              (x, y) =>
              {
                  if (y?.Count() > 0 && x?.Field<string>(RMSColumn.OCC_SCHEME) != RMSValue.RMS_IND && x.Field<string>(RMSColumn.O_IFM_2_digit)?.Length > 0)
                  {
                      x.SetField(RMSColumn.OCC_SCHEME, RMSValue.RMS_IND);
                      x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.O_IFM_2_digit));
                  }
                  return x;
              }).CopyToDataTable();


            //'    'Update 4 digit to 2 where it's 4 and should be 2 - or to ATC if no 2 digit code exists

            dt = dt.AsEnumerable().
                GroupJoin(lookup_IFMCountryDescriptionMapping.Where(x => x.IFM2or4digitOcc == RMSValue.TWO_DIGIT), x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
               (x, y) =>
               {
                   if (y?.Count() > 0 && x?.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND && x.Field<string>(RMSColumn.O_IFM_2_digit)?.Length > 0 && x.Field<string>(RMSColumn.OCC_TYPE)?.Length > 3)
                   {
                       x.SetField(RMSColumn.OCC_TYPE, x.Field<string>((RMSColumn.O_IFM_2_digit)));
                   }
                   return x;
               }).CopyToDataTable();

            dt = dt.AsEnumerable().
               GroupJoin(lookup_IFMCountryDescriptionMapping.Where(x => x.IFM2or4digitOcc == RMSValue.TWO_DIGIT), x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
              (x, y) =>
              {
                  if (y?.Count() > 0 && x?.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND && x.Field<string>(RMSColumn.O_IFM_2_digit)?.Length == 0 && x.Field<string>(RMSColumn.OCC_TYPE)?.Length > 3)
                  {
                      x.SetField(RMSColumn.OCC_SCHEME, RMSValue.ATC);
                      x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.O_ATC));
                  }
                  return x;
              }).CopyToDataTable();

            //'    'Update 4 digit to 2 where it's 4 and should be 2 - or to ATC if no 2 digit code exists
            dt = dt.AsEnumerable().
                GroupJoin(lookup_IFMCountryDescriptionMapping.Where(x => x.IFM2or4digitOcc != RMSValue.TWO_DIGIT), x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
               (x, y) =>
               {
                   if (y?.Count() > 0 && x?.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND && x.Field<string>(RMSColumn.OCC_TYPE)?.Length < 4 && !string.IsNullOrEmpty(x.Field<string>(RMSColumn.O_IFM_4_digit)))
                       x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.O_IFM_4_digit));
                   return x;
               }).CopyToDataTable();


            //'    'Update Construction to ATC if RMS IND and IFM isn't available for that country
            dt = dt.AsEnumerable(). //.Where(x => x.Field<string>(RMSColumn.BLDG_SCHEME) == RMSValue.RMS_IND).
               GroupJoin(lookup_IFMCountryDescriptionMapping, x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
              (x, y) =>
              {
                  if ((y == null || y?.Count() == 0 || y.FirstOrDefault().IS02ACode == null) && x.Field<string>(RMSColumn.BLDG_SCHEME) == RMSValue.RMS_IND)
                  {
                      x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.ATC);
                      x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.C_ATC));
                  }
                  return x;
              }).CopyToDataTable();


            //'Update Occupancy to ATC if RMS IND and IFM isn't available in that country
            dt = dt.AsEnumerable().//Where(x => x.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND).
              GroupJoin(lookup_IFMCountryDescriptionMapping, x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
             (x, y) =>
             {
                 if ((y == null || y?.Count() == 0 || y.FirstOrDefault().IS02ACode == null) && x.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND)
                 {
                     x.SetField(RMSColumn.OCC_SCHEME, RMSValue.ATC);
                     x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.O_ATC));
                 }
                 return x;
             }).CopyToDataTable();

            dt.AsEnumerable().Where(x => x.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND && x.Field<string>(RMSColumn.BLDG_SCHEME) != RMSValue.RMS_IND).ToList()
                .ForEach(x =>
                {
                    x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.RMS_IND);
                    string bldgClassCode = string.Empty;
                    var bldgClassEnt = lookup_IFMCountryDescriptionMapping.Where(y => y.IS02ACode == x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) && y.IFMOccupancy == (x.Field<string>(RMSColumn.C_IFM_DESC) ?? RMSValue.UNKNOWN)).FirstOrDefault();
                    bldgClassCode = bldgClassEnt == null ? "0" : bldgClassEnt.Code.ToString();
                    x.SetField(RMSColumn.BLDG_CLASS, bldgClassCode);
                });
            dt = dt.AsEnumerable().
              GroupJoin(lookup_IFMCountryDescriptionMapping, x => x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), y => y.IS02ACode,
             (x, y) =>
             {
                 if (y?.Count() > 0 && x.Field<string>(RMSColumn.BLDG_SCHEME) != RMSValue.RMS_IND && x.Field<string>(RMSColumn.OCC_SCHEME) == RMSValue.RMS_IND)
                 {
                     x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.RMS_IND);
                     x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.C_ATC));
                 }
                 return x;
             }).CopyToDataTable();


            //'If the Construction is RMS IND at this stage and the Occupancy isn't, then update the Construction to ATC

            dt.AsEnumerable().Where(x => x.Field<string>(RMSColumn.OCC_SCHEME) != RMSValue.RMS_IND && x.Field<string>(RMSColumn.BLDG_SCHEME) == RMSValue.RMS_IND).ToList()
                .ForEach(x =>
                {
                    x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.ATC);
                    x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.C_ATC));
                });

            //--'Update RMS IND Construction code to RMS IND 0 if invalid for the selected country
            dt = dt.AsEnumerable().
             GroupJoin(occBldclasslk, x => new { cntrycode = x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE), blgscheme = x.Field<string>(RMSColumn.BLDG_SCHEME), bldclass = x.Field<string>(RMSColumn.BLDG_CLASS) },
             y => new { cntrycode = y.ISO2ACountryCode, blgscheme = y.EMPSchemeName, bldclass = y.Code },
            (x, y) =>
            {
                if (y?.Count() > 0 && y.FirstOrDefault().Code == null && x.Field<string>(RMSColumn.BLDG_SCHEME) == RMSValue.RMS_IND)
                {
                    x.SetField(RMSColumn.BLDG_SCHEME, "0");
                    x.SetField(RMSColumn.BLDG_CLASS, RMSValue.RMS_IND);
                }
                return x;
            }).CopyToDataTable();


            //            'Update all non US construction to RMS (where scheme is not FIRE, RMS, RMS BR, RMS OP, EURO, JPBLDG, JPBLDG2010, RMS IND, and RMSCGSPEC)
            // DoCmd.RunSQL "UPDATE SOVrms SET SOVrms.BLDGSCHEME = 'RMS', SOVrms.BLDGCLASS = [C_RMS] WHERE (((SOVrms.ISO2ACountryCode) Not In ('US')) AND ((SOVrms.BLDGSCHEME) Not In ('FIRE','RMS','EURO','JPBLDG','JPBLDG2010','RMS BR','RMS IND','RMS OP','RMSCGSPEC')));"
            dt = GetDataUpdatesFromXML(dt, RMSValue.RMSIND, new string[] { "1" });

            var limittos = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();

            var lookup_CountryCodes = empdac.GetCountryLookup<CountryLookupBE>();
            var bldcodes = new List<string> { "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            dt = dt.AsEnumerable().GroupJoin(lookup_CountryCodes, x => new { cntrycode = x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) },
            y => new { cntrycode = y.ISO2A },
           (x, y) =>
           {
               if (y?.Count() > 0 && y.FirstOrDefault().FIRE_construction_allowed == true && x.Field<string>(RMSColumn.BLDG_SCHEME) == "FIRE" && !bldcodes.Contains(x.Field<string>(RMSColumn.BLDG_CLASS)) && x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) != "US")
               {
                   x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.RMS);
                   x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.C_RMS));
               }
               return x;
           }).CopyToDataTable();
            dt = dt.AsEnumerable().GroupJoin(lookup_CountryCodes.Where(x => x.FIRE_construction_allowed == false), x => new { cntrycode = x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) },
           y => new { cntrycode = y.ISO2A },
          (x, y) =>
          {
              if (y?.Count() > 0 && y.FirstOrDefault().FIRE_construction_allowed == false && x.Field<string>(RMSColumn.BLDG_SCHEME) == "FIRE")
              {
                  x.SetField(RMSColumn.BLDG_SCHEME, RMSValue.RMS);
                  x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.C_RMS));
              }
              return x;
          }).CopyToDataTable();
            //'Update all occupancy to ATC (where scheme is not ATC, RMS BR, RMS OP, EURO, EURO_FR, JPOCC, RMS IND, RMSMARINE and WCOCC)
            dt = GetDataUpdatesFromXML(dt, RMSValue.RMSIND, new string[] { "2", "3", "4", "5", "6" });
            return dt;
        }

        /// <summary>
        ///  Other Conversions
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public DataTable OtherCleansing(DataTable dt, string mode)
        {

            if (dt.Columns.Contains(RMSColumn.LOC_NUM))
            {
                if (mode == "append")
                {
                    dt = this.UpdateLocationNumber(dt);
                }
                else
                {

                    //check if loc_num has any string values
                    int celldType = 0;
                    var stringLocNums = dt.AsEnumerable().ToList().Where(x => Int32.TryParse(x.Field<string>(RMSColumn.LOC_NUM), out celldType) == false);

                    // Check if loc _num column has duplicates. 
                    var duplicates = dt.AsEnumerable().GroupBy(x => x.Field<string>(RMSColumn.LOC_NUM)).Where(gr => gr.Count() > 1).ToList();

                    //If duplicate or string type loc_num exists set the default # from 1 in overwrite and new upload scenarios
                    if (duplicates.Any() || stringLocNums.Any())
                    {
                        int loc_num = 1;
                        dt.AsEnumerable().ToList().ForEach(x =>
                        {
                            x.SetField(RMSColumn.LOC_NUM, loc_num++);
                        });
                    }
                }
            }
            else
            {
                dt.Columns.Add(RMSColumn.LOC_NUM);
                if (mode == "append")
                {
                    dt = this.UpdateLocationNumber(dt);
                }
                else
                {
                    dt.AsEnumerable().ToList().ForEach(x =>
                    {
                        x.SetField(RMSColumn.LOC_NUM, x.Field<string>(RMSColumn.ID));
                    });
                }

            }
            dt.AsEnumerable().Where(x => (Convert.ToDouble(x[RMSColumn.CV1VAL]) < 0)).ToList().ForEach(x =>
            {
                x.SetField(RMSColumn.CV1VAL, "0");
            });
            dt.AsEnumerable().Where(x => (Convert.ToDouble(x[RMSColumn.CV2VAL]) < 0)).ToList().ForEach(x =>
            {
                x.SetField(RMSColumn.CV2VAL, "0");
                //return x;
            });
            dt.AsEnumerable().Where(x => (Convert.ToDouble(x[RMSColumn.CV3VAL]) < 0)).ToList().ForEach(x =>
            {
                x.SetField(RMSColumn.CV3VAL, "0");
                //return x;
            });


            var drow = dt.Columns.Contains(RMSColumn.CV9VAL);
            if (!drow)
            {
                DataColumn column = new DataColumn(RMSColumn.CV9VAL, System.Type.GetType("System.Double"));
                column.DefaultValue = 0;
                dt.Columns.Add(column);
            }
            if (dt.Columns.Contains(RMSColumn.CV9VAL))
            {
                dt.AsEnumerable().Where(x => (x[RMSColumn.CV9VAL] == null || Convert.ToDouble(x[RMSColumn.CV9VAL]) < 0)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.CV9VAL, "0");
                });
            }
            return dt;
        }


        /// <summary>
        /// Update Location Number
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable UpdateLocationNumber(DataTable dt)
        {

            int loc_num = this.GetMaxLoctionNumber(_programGuid.Value);
            if (loc_num > 0)
            {
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.LOC_NUM, loc_num++);
                });
            }
            return dt;
        }

        /// <summary>
        /// Total value Conversion
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DataTable TotalVal(DataTable dt)
        {
            //dt.Columns.Add(RMSColumn.TOTAL_VALUE);
            //System.dou
            DataColumn column = new DataColumn(RMSColumn.TOTAL_VALUE, System.Type.GetType("System.Double"));
            dt.Columns.Add(column);
            if (dt.Columns.Contains(RMSColumn.CV9VAL))
            {
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.TOTAL_VALUE, Convert.ToDouble(x[RMSColumn.CV1VAL]) + Convert.ToDouble(x[RMSColumn.CV2VAL]) + Convert.ToDouble(x[RMSColumn.CV3VAL]) + Convert.ToDouble(x[RMSColumn.CV9VAL]));
                    //return x;
                });
            }
            else
            {
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.TOTAL_VALUE, Convert.ToDouble(x[RMSColumn.CV1VAL]) + Convert.ToDouble(x[RMSColumn.CV2VAL]) + Convert.ToDouble(x[RMSColumn.CV3VAL]));
                    //return x;
                });
            }
            dt.AsEnumerable().Where(x => (x.Field<double>(RMSColumn.TOTAL_VALUE) == 0)).ToList().ForEach(x =>
            {
                x.SetField(RMSColumn.TOTAL_VALUE, 0.01);
                x.SetField(RMSColumn.CV1VAL, 0.01);
                //return x;
            });
            dt.AsEnumerable().ToList().ForEach(x =>
            {
                x.SetField(RMSColumn.OCC_TYPE, x.Field<string>(RMSColumn.OCC_TYPE) ?? "");
                x.SetField(RMSColumn.O_IFM_4_digit, x.Field<string>(RMSColumn.O_IFM_4_digit) ?? "");
                //return x;
            });
            return dt;
        }

        public static DataTable ReorderRMSData(DataTable dt)
        {
            //, List<SOVtoRMSFieldBE> rmsfields
            var l_SOVRMSMappingBE = new List<ISOVtoRMSFieldsBE>();
            l_SOVRMSMappingBE = (List<ISOVtoRMSFieldsBE>)Caches.GetCacheItem(CacheIdentifiers.C_SOV_TO_RMS_FIELDS);
            List<SOVtoRMSFieldBE> l_RMSFields = l_SOVRMSMappingBE.GroupBy(x =>
                   new
                   {
                       x.RMSFieldName,
                       x.IsLimitToList,
                       x.orderNum,
                       x.IsSecModByCntry,
                       x.RMSFieldType
                   }).Select(y => new SOVtoRMSFieldBE
                   {
                       RMSFieldName = y.Key.RMSFieldName,
                       IsLimitToList = y.Key.IsLimitToList,
                       orderNum = y.Key.orderNum,
                       IsSecModByCntry = y.Key.IsSecModByCntry,
                       RMSFieldType = y.Key.RMSFieldType
                   }).ToList();

            l_RMSFields.AddRange(new List<SOVtoRMSFieldBE>
            {
                new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.ID,
                    orderNum=1
                },
               new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.ISO2A_CNTRY_CODE,
                    orderNum=139
                },
                new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.C_ATC,
                    orderNum=331
                },
               new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.C_RMS,
                    orderNum=332
                },
                new SOVtoRMSFieldBE{
                    RMSFieldName= RMSColumn.C_IFM_DESC,
                    orderNum=333
                },
               new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.O_ATC,
                    orderNum=351
                },
                new SOVtoRMSFieldBE{
                    RMSFieldName= RMSColumn.O_IFM_2_digit,
                    orderNum=352
                },
               new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.O_IFM_4_digit,
                    orderNum=353
                },
                new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.USER_TXT3,
                    orderNum=521
                },
                 new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.USER_TXT4,
                    orderNum=522
                },
                  new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.USER_TXT5,
                    orderNum=523
                },
                   new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.USER_TXT6,
                    orderNum=524
                },
                    new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.TOTAL_VALUE,
                    orderNum=779
                },
                     new SOVtoRMSFieldBE{
                    RMSFieldName= RMSColumn.RMS_LATITUDE,
                    orderNum=171
                },
                      new SOVtoRMSFieldBE{
                    RMSFieldName= RMSColumn.RMS_LONGITUDE,
                    orderNum=172
                },
                    new SOVtoRMSFieldBE{
                    RMSFieldName=RMSColumn.RMS_GEOCODE_RES,
                    orderNum=173
                },
            });
            l_RMSFields = l_RMSFields.OrderBy(x => x.orderNum).ToList();
            dt.SetColumnsOrder(l_RMSFields.Select(x => x.RMSFieldName).ToArray());
            return dt;
        }

        /// <summary>
        /// Othere RMS Conversion
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable OtherConversions(DataTable dt, int fileProcessingTaskGuid)
        {
            //If YEARBUILT and YEARUPGRAD are mapped, then make the YEARUPGRAD unknown if < YEARBUILT
            if (dt.Columns.Contains(RMSColumn.YEAR_BUILT) && dt.Columns.Contains(RMSColumn.YEAR_UPGRAD))
            {
                dt.AsEnumerable().Where(x => (!string.IsNullOrEmpty(Convert.ToString(x[RMSColumn.YEAR_BUILT])) && !string.IsNullOrEmpty(Convert.ToString(x[RMSColumn.YEAR_UPGRAD])))).ToList().ForEach(x =>
                {
                    if (Convert.ToInt32(Convert.ToString(x[RMSColumn.YEAR_BUILT]).Substring(6, 4)) > Convert.ToInt32(Convert.ToString(x[RMSColumn.YEAR_UPGRAD]).Substring(6, 4)))
                    {
                        x.SetField(RMSColumn.YEAR_UPGRAD, "12/31/9999");
                    }

                });
            }
            //yb to 1/1/9999 if null and exists
            if (dt.Columns.Contains(RMSColumn.YEAR_BUILT))
            {
                dt.AsEnumerable().Where(x => (string.IsNullOrEmpty(Convert.ToString(x[RMSColumn.YEAR_BUILT])))).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.YEAR_BUILT, Convert.ToDateTime("12/31/9999"));
                });
            }

            //yb to 1/1/9999 if null and exists
            if (dt.Columns.Contains(RMSColumn.YEAR_UPGRAD))
            {
                dt.AsEnumerable().Where(x => (string.IsNullOrEmpty(Convert.ToString(x[RMSColumn.YEAR_UPGRAD])))).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.YEAR_UPGRAD, Convert.ToDateTime("12/31/9999"));
                });
            }
            //null stories if exists to 0
            if (dt.Columns.Contains(RMSColumn.NUM_STORIES))
            {
                dt.AsEnumerable().Where(x => (string.IsNullOrEmpty(Convert.ToString(x[RMSColumn.NUM_STORIES])))).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.NUM_STORIES, 0);
                });

                //Update Construction to Unknown if NUMSTORIES > 4 and Construction is Wood Frame
                string[] c_ATC = { "1", "71" };
                string[] c_RMS = { "1", "52", "52A", "52B" };
                dt.AsEnumerable().Where(x => ((x.Field<Int64?>(RMSColumn.NUM_STORIES) > 4 && c_ATC.Contains(x.Field<string>(RMSColumn.C_ATC))) || (x.Field<Int64?>(RMSColumn.NUM_STORIES) > 4 && c_RMS.Contains(x.Field<string>(RMSColumn.C_RMS))))).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.BLDG_CLASS, "0");
                    x.SetField(RMSColumn.C_ATC, "0");
                    x.SetField(RMSColumn.C_RMS, "0");
                });
            }

            //coordinates valid and within range ? -180 to 180 for LONG and -90 to 90 for LAT - set to 0, 0 or null(?) if not.Scrubbing Sheet has parameters by country...valid ?
            if (dt.Columns.Contains(RMSColumn.LATITUDE) && dt.Columns.Contains(RMSColumn.LONGITUDE))
            {
                dt.AsEnumerable().Where(x =>
                (x.Field<double?>(RMSColumn.LATITUDE) == null || x.Field<double?>(RMSColumn.LONGITUDE) == null || x.Field<double>(RMSColumn.LONGITUDE) < -180 || x.Field<double>(RMSColumn.LONGITUDE) > 180 || x.Field<double>(RMSColumn.LATITUDE) < -90 || x.Field<double>(RMSColumn.LATITUDE) > 90)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.LATITUDE, "0");
                    x.SetField(RMSColumn.LONGITUDE, "0");
                });
            }

            //include leading zeros for US postcodes if mapped & US locations exist 
            if (dt.Columns.Contains(RMSColumn.POSTAL_CODE))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.POSTAL_CODE) != null && x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) == "US")).ToList().ForEach(x =>
                {
                    string code = UsPostalCodeCleanse(x.Field<string>(RMSColumn.POSTAL_CODE));
                    x.SetField(RMSColumn.POSTAL_CODE, code);
                });
            }

            //if LOCNAME isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.LOC_NAME))
            {
                dt.Columns.Add(RMSColumn.LOC_NAME).DataType = System.Type.GetType("System.String");
            }
            //if STREETNAME isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.STREET_NAME))
            {
                dt.Columns.Add(RMSColumn.STREET_NAME).DataType = System.Type.GetType("System.String");
            }
            //if POSTALCODE isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.POSTAL_CODE))
            {
                dt.Columns.Add(RMSColumn.POSTAL_CODE).DataType = System.Type.GetType("System.String");
            }
            //if DISTRICT isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.DISTRICT))
            {
                dt.Columns.Add(RMSColumn.DISTRICT).DataType = System.Type.GetType("System.String");
            }
            //if CITY isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.CITY))
            {
                dt.Columns.Add(RMSColumn.CITY).DataType = System.Type.GetType("System.String");
            }
            //if COUNTY isn't present, then add it & update US locations with a COUNTY using a POSTCODE lookup where available...as needed for limit, ded application (filters)
            if (!dt.Columns.Contains(RMSColumn.COUNTY))
            {
                dt.Columns.Add(RMSColumn.COUNTY).DataType = System.Type.GetType("System.String");
            }

            //getting county based on postal and statecode  
            EMPDAC empDAC = new EMPDAC();
            var usPostCodes = empDAC.GetCountyByStateandPostalCode<UsPostalCodeBE>();
            if (dt.Columns.Contains(RMSColumn.POSTAL_CODE))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) == RMSValue.US && (x.Field<string>(RMSColumn.STATE_CODE)?.Length > 0)
                && (x.Field<string>(RMSColumn.POSTAL_CODE)?.Length > 0))).ToList().ForEach(x =>
                {
                    string county = string.Empty;
                    if (usPostCodes != null)
                    {
                        string postalCode = x.Field<string>(RMSColumn.POSTAL_CODE);
                        if (!string.IsNullOrWhiteSpace(postalCode) && postalCode.Length > 5)
                        {
                            postalCode = postalCode.Substring(0, 5);
                        }
                        county = usPostCodes.ToList().Where(l => (l.StateCode == x.Field<string>(RMSColumn.STATE_CODE) && l.ZipCode == postalCode)).Select(l => l.County).FirstOrDefault();
                    }
                    x.SetField(RMSColumn.COUNTY, county);
                });
            }

            //if CRESTA isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.CRESTA))
            {
                dt.Columns.Add(RMSColumn.CRESTA).DataType = System.Type.GetType("System.String");
            }
            //if USERID1 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_ID1))
            {
                dt.Columns.Add(RMSColumn.USER_ID1).DataType = System.Type.GetType("System.String");
            }
            //if USERID2 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_ID2))
            {
                dt.Columns.Add(RMSColumn.USER_ID2).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT1 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT1))
            {
                dt.Columns.Add(RMSColumn.USER_TXT1).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT2 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT2))
            {
                dt.Columns.Add(RMSColumn.USER_TXT2).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT3 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT3))
            {
                dt.Columns.Add(RMSColumn.USER_TXT3).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT4 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT4))
            {
                dt.Columns.Add(RMSColumn.USER_TXT4).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT5 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT5))
            {
                dt.Columns.Add(RMSColumn.USER_TXT5).DataType = System.Type.GetType("System.String");
            }
            //if USERTXT6 isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.USER_TXT6))
            {
                dt.Columns.Add(RMSColumn.USER_TXT6).DataType = System.Type.GetType("System.String");
            }
            //if LATITUDE isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.LATITUDE))
            {
                DataColumn column = new DataColumn(RMSColumn.LATITUDE, System.Type.GetType("System.Int16"));
                column.DefaultValue = 0;
                dt.Columns.Add(column);
            }
            //if LONGITUDE isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.LONGITUDE))
            {
                DataColumn column = new DataColumn(RMSColumn.LONGITUDE, System.Type.GetType("System.Int16"));
                column.DefaultValue = 0;
                dt.Columns.Add(column);
            }
            //if STATE isn't present, then add it
            if (!dt.Columns.Contains(RMSColumn.STATE))
            {
                dt.Columns.Add(RMSColumn.STATE).DataType = System.Type.GetType("System.String");
            }
            //add RMS Geocoding Resolution,RMS LATITUDE,RMS LONGITUDE columns
            DataColumn geoCol = new DataColumn(RMSColumn.RMS_GEOCODE_RES, System.Type.GetType("System.String"));
            geoCol.DefaultValue = "Not Performed";
            dt.Columns.Add(geoCol);

            DataColumn rmsLatCol = new DataColumn(RMSColumn.RMS_LATITUDE, System.Type.GetType("System.Int16"));
            rmsLatCol.DefaultValue = 0;
            dt.Columns.Add(rmsLatCol);

            DataColumn rmsLongCol = new DataColumn(RMSColumn.RMS_LONGITUDE, System.Type.GetType("System.Int16"));
            rmsLongCol.DefaultValue = 0;
            dt.Columns.Add(rmsLongCol);

            if (dt.Columns.Contains(RMSColumn.PCNTCOMPLT))
            {
                dt.AsEnumerable().Where(x => (x.Field<double>(RMSColumn.PCNTCOMPLT) > 100 || x.Field<double>(RMSColumn.PCNTCOMPLT) < 0)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.PCNTCOMPLT, 100);
                });
            }

            //ALTER TABLE SOVrms ADD CV2CVM number NULL; 'set to default of 3 where null
            if (!dt.Columns.Contains(RMSColumn.CV2CVM))
            {
                DataColumn cV2CVMCol = new DataColumn(RMSColumn.CV2CVM, System.Type.GetType("System.Int64"));
                cV2CVMCol.DefaultValue = null;
                dt.Columns.Add(cV2CVMCol);
            }
            if (dt.Columns.Contains(RMSColumn.CV2CVM))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.CV2CVM) == null)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.CV2CVM, 3);
                });
            }

            //ALTER TABLE SOVrms ADD EQCV2EQSLG number NULL; 'set to default of 0
            if (!dt.Columns.Contains(RMSColumn.EQCV2EQSLG))
            {
                DataColumn cV2CVMCol = new DataColumn(RMSColumn.EQCV2EQSLG, System.Type.GetType("System.Int64"));
                cV2CVMCol.DefaultValue = null;
                dt.Columns.Add(cV2CVMCol);
            }
            if (dt.Columns.Contains(RMSColumn.EQCV2EQSLG))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.EQCV2EQSLG) == null)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.EQCV2EQSLG, 0);
                });
            }

            //ALTER TABLE SOVrms ADD CV9CVM number NULL; 'set to default of 3 where null
            if (!dt.Columns.Contains(RMSColumn.CV9CVM))
            {
                DataColumn cV2CVMCol = new DataColumn(RMSColumn.CV9CVM, System.Type.GetType("System.Int64"));
                cV2CVMCol.DefaultValue = null;
                dt.Columns.Add(cV2CVMCol);
            }
            if (dt.Columns.Contains(RMSColumn.CV9CVM))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.CV9CVM) == null)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.CV9CVM, 3);
                });
            }

            //ALTER TABLE SOVrms ADD EQCV9EQSLG number NULL; 'set to default of 0
            if (!dt.Columns.Contains(RMSColumn.EQCV9EQSLG))
            {
                DataColumn cV2CVMCol = new DataColumn(RMSColumn.EQCV9EQSLG, System.Type.GetType("System.Int64"));
                cV2CVMCol.DefaultValue = null;
                dt.Columns.Add(cV2CVMCol);
            }
            if (dt.Columns.Contains(RMSColumn.EQCV9EQSLG))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.EQCV9EQSLG) == null)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.EQCV9EQSLG, 0);
                });

            }

            //Cleanse the PRIMARYBLDG & SITENAME is pending

            //Call CleansePrimaryBldg
            dt = CleansePrimaryBldg(dt);

            if (dt.Columns.Contains(RMSColumn.YEAR_BUILT))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.STATE_CODE) == "CA" && x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) == "US"
                && Convert.ToInt32(Convert.ToString(x[RMSColumn.YEAR_BUILT]).Substring(6, 4)) > 1935 && Convert.ToInt32(Convert.ToString(x[RMSColumn.YEAR_BUILT]).Substring(6, 4)) < 9998
                 && (((x.Field<string>(RMSColumn.C_ATC) == "4" || x.Field<string>(RMSColumn.C_ATC) == "3") && x.Field<string>(RMSColumn.BLDG_SCHEME) != "RMS IND")
                    || ((x.Field<string>(RMSColumn.BLDG_CLASS) == "2") && x.Field<string>(RMSColumn.BLDG_SCHEME) == "RMS IND"))))
                    .ToList().ForEach(x =>
                    {
                        x.SetField(RMSColumn.BLDG_SCHEME, x.Field<string>(RMSColumn.BLDG_SCHEME) == "RMS IND" ? "RMS IND" : "ATC");
                        x.SetField(RMSColumn.BLDG_CLASS, x.Field<string>(RMSColumn.BLDG_SCHEME) == "RMS IND" ? "5" : x.Field<string>(RMSColumn.C_ATC) == "3" ? "7" : "8");
                    });
            }
            //Update number of Stories greater than 163 (Burj Khalifa) to 0
            if (dt.Columns.Contains(RMSColumn.NUM_STORIES))
            {
                dt.AsEnumerable().Where(x => (x.Field<Int64?>(RMSColumn.NUM_STORIES) > 163) || Convert.ToDouble(x[RMSColumn.NUM_STORIES]) < 0).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.NUM_STORIES, 0);
                });
            }

            //Update Floor Occupancy
            if (dt.Columns.Contains(RMSColumn.NUM_STORIES) && dt.Columns.Contains(RMSColumn.FLOOR_OCCUPANCY))
            {
                dt.AsEnumerable().Where(x => x.Field<string>(RMSColumn.FLOOR_OCCUPANCY)?.Length > 0).ToList().ForEach(x =>
                {
                    string floorOccupied = string.Empty;
                    floorOccupied = GetFloorOccupancy(x.Field<string>(RMSColumn.FLOOR_OCCUPANCY), x.Field<Int64?>(RMSColumn.NUM_STORIES));
                    x.SetField(RMSColumn.FLOOR_OCCUPANCY, floorOccupied);
                });
            }
            else if (dt.Columns.Contains(RMSColumn.FLOOR_OCCUPANCY))
            {
                dt.AsEnumerable().Where(x => x.Field<string>(RMSColumn.FLOOR_OCCUPANCY)?.Length > 0).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.FLOOR_OCCUPANCY, string.Empty);
                });
            }


            // EXTRA for Geo: pending
            // 'FOR CB COUNTRIES:          
            var cbCountries = this.GetCBcountries(fileProcessingTaskGuid);
            DataTable dtu = new DataTable();
            var query = dt.AsEnumerable().Where(x => !string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)))
                                    .Select(item => new
                                    {
                                        CountryCode = item.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)
                                    }).ToList();
            var cntryCodes = cbCountries.Join(query, x => x.CountryCode, y => y.CountryCode, (x, y) => new
            {
                x.CountryCode
            });
            string[] c = cntryCodes.Select(d => d.CountryCode).ToArray();

            //'If STATE is empty, then update STATE with COUNTY
            dt.AsEnumerable().Where(x => (c.Contains(x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)) && string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.STATE)))).ToList().
            ForEach(x =>
            {
                x.SetField(RMSColumn.STATE, x.Field<string>(RMSColumn.COUNTY));
            });

            //Then if COUNTY = STATE and DISTRICT isn't empty, then update COUNTY with the DISTRICT
            dt.AsEnumerable().Where(x => (c.Contains(x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)) && !string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.STATE)) && !string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.DISTRICT)) && (x.Field<string>(RMSColumn.STATE) == x.Field<string>(RMSColumn.COUNTY)))).ToList().
            ForEach(x =>
            {
                x.SetField(RMSColumn.COUNTY, x.Field<string>(RMSColumn.DISTRICT));
            });

            //Then if COUNTY is empty and DISTRICT isn't, then update COUNTY with the DISTRICT
            dt.AsEnumerable().Where(x => (c.Contains(x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)) && string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.COUNTY)) && !string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.DISTRICT)))).ToList().
            ForEach(x =>
            {
                x.SetField(RMSColumn.COUNTY, x.Field<string>(RMSColumn.DISTRICT));
            });

            //IF COUNTRY IS GU then UDPATE ADMIN1NAME TO GUAM
            if (dt.Columns.Contains(RMSColumn.STATE))
            {
                dt.AsEnumerable().Where(x => (x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE) == RMSValue.GU)).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.STATE, RMSValue.GUAM);
                });

            }
            //IF COUNTRY in ( IL JP IE AD ) then UPDATE STATE (if empty) with the ADMIN2NAME (if present)         
            string[] codes = { "JP", "IL", "IE", "AD" };

            if (dt.Columns.Contains(RMSColumn.STATE))
            {

                dt.AsEnumerable().Where(x => (string.IsNullOrWhiteSpace(x.Field<string>(RMSColumn.STATE)) && codes.Contains(x.Field<string>(RMSColumn.ISO2A_CNTRY_CODE)))).ToList().ForEach(x =>
                {
                    x.SetField(RMSColumn.STATE, x.Field<string>(RMSColumn.COUNTY));
                });

            }
            return dt;
        }

        /// <summary>
        /// Cleaning of Primary Building SOV Field
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DataTable CleansePrimaryBldg(DataTable dt)
        {
            if (dt.Columns.Contains(RMSColumn.SITE_NAME))
            {
                //dt.Columns[RMSColumn.PRIMARY_BLDG].DataType = typeof(double);
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    if (string.IsNullOrEmpty(x.Field<string>(RMSColumn.SITE_NAME)))
                    {
                        x.SetField(RMSColumn.SITE_NAME, x.Field<string>(RMSColumn.LOC_NUM));
                        x.SetField(RMSColumn.PRIMARY_BLDG, 1);
                    }
                });
            }
            else if (dt.Columns.Contains(RMSColumn.PRIMARY_BLDG))
            {
                if (!dt.Columns.Contains(RMSColumn.SITE_NAME))
                    dt.Columns.Add(RMSColumn.SITE_NAME);
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    if (string.IsNullOrEmpty(x.Field<string>(RMSColumn.SITE_NAME)))
                        x.SetField(RMSColumn.SITE_NAME, x.Field<string>(RMSColumn.LOC_NUM));
                    x.SetField(RMSColumn.PRIMARY_BLDG, 1);
                });
            }
            else
            {
                if (!dt.Columns.Contains(RMSColumn.SITE_NAME))
                    dt.Columns.Add(RMSColumn.SITE_NAME);
                if (!dt.Columns.Contains(RMSColumn.PRIMARY_BLDG))
                    dt.Columns.Add(RMSColumn.PRIMARY_BLDG, Type.GetType("System.Int32"));
                dt.AsEnumerable().ToList().ForEach(x =>
                {
                    if (string.IsNullOrEmpty(x.Field<string>(RMSColumn.SITE_NAME)))
                        x.SetField(RMSColumn.SITE_NAME, x.Field<string>(RMSColumn.LOC_NUM));
                    x.SetField(RMSColumn.PRIMARY_BLDG, 1);
                });
            }
            return dt;
        }


        /// <summary>
        /// Convert Latitude and Longitude
        /// </summary>
        /// <param name="latlong"></param>
        /// <returns></returns>
        public static double ConvertLatLong(string latlong)
        {
            double convertedlatlog = 0;
            try
            {
                DateTime dt = new DateTime();
                if (DateTime.TryParse(latlong, out dt))
                {
                    return 0;
                }
                // TODO: On Error GoTo Warning!!!: The statement is not translatable 
                // Latitude conversion
                if (((((latlong.IndexOf("°") + 1)
                            > 0)
                            && ((latlong.IndexOf("\'") + 1)
                            > 0))
                            || (((latlong.IndexOf(":") + 1)
                            > 0)
                            || ((latlong.IndexOf("-") + 1)
                            > 0))))
                {
                    latlong = latlong.Replace(" ", "");
                    latlong = latlong.Replace("n", "");
                    latlong = latlong.Replace("N", "");
                    latlong = latlong.Replace("e", "");
                    latlong = latlong.Replace("E", "");
                    latlong = latlong.Replace(":", "!");
                    latlong = latlong.Replace("-", "!");
                    latlong = latlong.Replace("°", "!");
                    latlong = latlong.Replace("\'", "!");
                    latlong = latlong.Replace("\"", "");

                    var multiplier = (latlong.Contains("S") || latlong.Contains("s") || latlong.Contains("w") || latlong.Contains("W")) ? -1 : 1; //handle south and west
                    latlong = Regex.Replace(latlong, "[^0-9!.]", ""); //remove the characters
                    var pointArray = latlong.Split('!'); //split the string.

                    //Decimal degrees = 
                    //   whole number of degrees, 
                    //   plus minutes divided by 60, 
                    //   plus seconds divided by 3600
                    if (pointArray.Length >= 3)
                    {
                        var degrees = Double.Parse(pointArray[0]);
                        if (degrees == 0)
                        {
                            return 0;
                        }
                        var minutes = Double.Parse(pointArray[1]) / 60;
                        var seconds = Double.Parse(pointArray[2]) / 3600;
                        convertedlatlog = (degrees + minutes + seconds) * multiplier;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
            catch (Exception ex)
            {
                XLTrace.Write("Converted Latitude Longitude Details Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "Latitude,Longitude Convertion Error ", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            return convertedlatlog;
        }

        /// <summary>
        /// Cleansing US Postal Codes
        /// </summary>
        /// <param name="postalCode"></param>
        /// <returns></returns>
        public static string UsPostalCodeCleanse(string postalCode)
        {
            string code;
            int y = postalCode.IndexOf("-");
            if (y > 0)
            {
                if (y > 5)
                {
                    code = postalCode;
                }
                else
                {
                    switch (y)
                    {
                        case 1:
                            code = "0000" + postalCode;
                            break;
                        case 2:
                            code = "000" + postalCode;
                            break;
                        case 3:
                            code = "00" + postalCode;
                            break;
                        case 4:
                            code = "0" + postalCode;
                            break;
                        case 5:
                            code = postalCode;
                            break;
                        default:
                            code = postalCode;
                            break;
                    }
                }
            }
            else
            {
                int codeLength = postalCode.Length;
                switch (codeLength)
                {
                    case 1:
                        code = "0000" + postalCode;
                        break;
                    case 2:
                        code = "000" + postalCode;
                        break;
                    case 3:
                        code = "00" + postalCode;
                        break;
                    case 4:
                        code = "0" + postalCode;
                        break;
                    case 5:
                        code = postalCode;
                        break;
                    case 6:
                        code = "000" + postalCode.Substring(0, 2) + "-" + postalCode.Substring(postalCode.Length - 4, 4);
                        break;
                    case 7:
                        code = "00" + postalCode.Substring(0, 3) + "-" + postalCode.Substring(postalCode.Length - 4, 4);
                        break;
                    case 8:
                        code = "0" + postalCode.Substring(0, 4) + "-" + postalCode.Substring(postalCode.Length - 4, 4);
                        break;
                    case 9:
                        code = postalCode.Substring(0, 5) + "-" + postalCode.Substring(postalCode.Length - 4, 4);
                        break;
                    default:
                        code = postalCode;
                        break;
                }
            }

            return code;
        }

        public static Double Val(string value)
        {
            String result = String.Empty;
            if (!string.IsNullOrEmpty(value))
            {
                foreach (char c in value)
                {
                    if (Char.IsNumber(c) || (c.Equals('.') && result.Count(x => x.Equals('.')) == 0))
                        result += c;
                    else if (!c.Equals(' '))
                        return String.IsNullOrEmpty(result) ? 0 : Convert.ToDouble(result);
                }
            }
            return String.IsNullOrEmpty(result) ? 0 : Convert.ToDouble(result);
        }

        public static DataTable GetDataUpdatesFromXML(DataTable dt, string category, string[] exeOrder)
        {
            string path = HttpContext.Current.Server.MapPath("~/Config/BLdngOccUpdateLogic.xml");
            XmlSerializer serializer = new XmlSerializer(typeof(BldOccUpdates));
            BldOccUpdates list = new BldOccUpdates();
            DataTable result = dt.Copy();
            using (StreamReader reader = new StreamReader(path))
            {
                list = (BldOccUpdates)serializer.Deserialize(reader);
            }
            if (list.UpdateLogic.Count() > 0)
            {
                List<OccBldClassLookupBE> occbldlist = new List<OccBldClassLookupBE>();

                foreach (UpdateLogic up in list.UpdateLogic.Where(x => x.Category == category && exeOrder.Contains(x.Order)))
                {
                    string strFilter = string.Empty;
                    DataView dv = new DataView(dt);
                    foreach (var filterItem in up.FilterExpression)
                    {
                        strFilter += $"( ";
                        foreach (var f in filterItem.Filters.Filter)
                        {
                            strFilter += $" (IsNull({f.Column},'') {f.Operator} {f.Value}) {f.JoiningOperator}";
                        }

                        strFilter += $") {filterItem.JoiningExpression} ";
                    }

                    dv.RowFilter = strFilter;

                    foreach (DataRowView dvItem in dv)
                    {
                        foreach (var targetItem in up.Target)
                        {
                            dvItem[targetItem.Column] = !string.IsNullOrEmpty(targetItem.SourceColumn) ? dvItem[targetItem.SourceColumn] : targetItem.Value;
                        }
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// Update Location Details
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="programguid"></param>       
        public void UpdateLocationDetails(int programguid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                FileProcessingTasksBE fileProcessingTasksBE = this.GetFileProcessingTaskByProgramGuid(programguid);
                _empDAC.UpdateLocationDetails(fileProcessingTasksBE.FileProcessingTaskGuid.Value);
                XLTrace.Write("Updated Location Details Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, programguid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Updating Location Details Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, programguid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }



        /// <summary>
        /// Get Location Details by Porgram Guid
        /// </summary>
        /// <param name = "programguid" ></ param >
        /// < returns ></ returns >
        public dynamic GetLocationDetails(int programguid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var rmsExcelResult = this.GetSOVRMSMappedColumns(programguid);
                string[] excelColumns = rmsExcelResult.Select(x => x.RMSFieldName).Distinct().ToArray();
                var filterResult = _empDAC.GetLocationDetails(programguid, excelColumns);
                XLTrace.Write("Retrieved Location Details Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, programguid);
                return filterResult;
            }
            catch (Exception ex)
            {

                XLTrace.Write("Retrieving Location Details Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, TraceEventType.Error, programguid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }


        /// <summary>
        /// Save RMS Converted Data
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="fileprocessingtask"></param>
        /// <returns></returns>
        public bool SaveRMSConvertedData(DataTable dt, int fileprocessingtask, string aLoginUserId)
        {
            var filedata = GetFileProcessingTaskByOwnerGuid(fileprocessingtask);
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                List<RMSConvertedDataBE> rmsConvertedDataBE = ConvertDataTableToList<RMSConvertedDataBE>(dt);
                rmsConvertedDataBE.ForEach(x =>
                {
                    x.ChangedStatus = EntityStatus.StatusInsert;
                    if (filedata.ProgramFileGuid != null)
                    {
                        x.PROGRAMGUID = filedata.ProgramGuid;
                        x.Emp_fileprocessingtask_guid = filedata.FileProcessingTaskGuid;
                        x.Deleted_Ind = false;
                        x.Version = 1;
                    }
                });

                if (filedata.ProgramFileGuid == null)
                {
                    RMSConvertedDataBE rmsdata = new RMSConvertedDataBE();
                    rmsdata.Emp_fileprocessingtask_guid = fileprocessingtask;
                    _empDAC.DeleteSOVRMSData(fileprocessingtask);
                }
                else
                {
                    int programfileGuid = int.Parse(filedata.ProgramFileGuid.ToString());
                    RMSConvertedDataBE rmsdata = new RMSConvertedDataBE();
                    rmsdata.Emp_fileprocessingtask_guid = fileprocessingtask;
                    _empDAC.DeleteSOVRMSData(fileprocessingtask);
                }
                var xa = rmsConvertedDataBE.Any(x => x.Emp_fileprocessingtask_guid == null);
                XLTrace.Write("Deleted RMS Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, filedata.ProgramGuid, filedata.ProgramFileGuid);
                _empDAC.BulkInsertConvertedRMS(rmsConvertedDataBE, aLoginUserId);
                _empDAC.UpdateMarinedata(fileprocessingtask);
                XLTrace.Write("Saved RMS Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, filedata.ProgramGuid, filedata.ProgramFileGuid);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving RMS Converted Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, filedata.ProgramGuid, filedata.ProgramFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }


        public static List<RMSConvertedDataBE> ConvertDataTableToList<T>(DataTable dt)
        {
            List<RMSConvertedDataBE> data = new List<RMSConvertedDataBE>();
            foreach (DataRow row in dt.Rows)
            {
                RMSConvertedDataBE item = GetItem<RMSConvertedDataBE>(row);
                data.Add(item);
            }
            return data;
        }
        public static List<T> ConvertDataTableToListGeneric<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItemGeneric<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItemGeneric<T>(DataRow dr)
        {
            Type temp = typeof(T);
            var propInfos = temp.GetProperties();
            PropertyInfo property;
            T obj = Activator.CreateInstance<T>();
            string colName = string.Empty;
            foreach (DataColumn column in dr.Table.Columns)
            {
                colName = column.ColumnName.Replace("-", "_").Replace(" ", "");
                property = propInfos.Where(a => a.Name == colName).FirstOrDefault();
                if (property != null && dr[column.ColumnName] != DBNull.Value)
                {
                    Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                    object safeValue;
                    if (dr[column.ColumnName] == null || dr[column.ColumnName] as string == "")
                    {
                        safeValue = null;
                    }
                    else if (t.Name == DateTime.Now.GetType().Name && Convert.ToDateTime(dr[column.ColumnName]) == DateTime.MinValue)
                    {
                        safeValue = null;
                    }
                    else
                    {
                        safeValue = Convert.ChangeType(dr[column.ColumnName], t);
                    }
                    property.SetValue(obj, safeValue, null);
                }
            }
            return obj;
        }
        private static RMSConvertedDataBE GetItem<RMSConvertedDataBE>(DataRow dr)
        {
            Type temp = typeof(RMSConvertedDataBE);
            var propInfos = temp.GetProperties();
            PropertyInfo property;
            RMSConvertedDataBE obj = Activator.CreateInstance<RMSConvertedDataBE>();
            string colName = string.Empty;
            foreach (DataColumn column in dr.Table.Columns)
            {
                colName = column.ColumnName.Replace("-", "_").Replace(" ", "");
                property = propInfos.Where(a => a.Name == colName).FirstOrDefault();
                if (property != null && dr[column.ColumnName] != DBNull.Value)
                {
                    Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                    object safeValue;
                    if (dr[column.ColumnName] == null || dr[column.ColumnName] as string == "")
                    {
                        safeValue = null;
                    }
                    else if (t.Name == DateTime.Now.GetType().Name && Convert.ToDateTime(dr[column.ColumnName]) == DateTime.MinValue)
                    {
                        safeValue = null;
                    }
                    else
                    {
                        safeValue = Convert.ChangeType(dr[column.ColumnName], t);
                    }
                    property.SetValue(obj, safeValue, null);
                }
            }
            return obj;
        }
        public static bool IsEmpty(DataRow row)
        {
            return row == null || row.ItemArray.All(i => i is DBNull);
        }
        public static dynamic GetConvertedValues(string datatype, dynamic rowvalue)
        {
            double resultVal = 0.00;
            int resultnum = 0;
            dynamic result = 0.00;
            if (datatype.Contains("num"))
            {
                if (rowvalue != null)
                    double.TryParse(rowvalue.ToString(), out resultVal);
                result = resultVal;
            }
            else if (datatype.Contains("int"))
            {
                if (rowvalue != null && Int32.TryParse(rowvalue.ToString(), out resultnum))
                {
                    result = resultnum;
                }
                else if (rowvalue != null && double.TryParse(rowvalue.ToString(), NumberStyles.Float | NumberStyles.AllowDecimalPoint, new CultureInfo("en-GB"), out resultVal))
                {
                    result = Convert.ToInt32(resultVal);
                }
            }
            else
            {
                if (rowvalue != null)
                    result = rowvalue.ToString().Trim();
                else
                    result = string.Empty;
            }
            return result;
        }

        /// <summary>
        /// Save Locatio Details
        /// </summary>
        /// <param name="programguid"></param>
        public void SaveLocationDetails(int programguid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                _empDAC.SaveLocationDetails(programguid);
                this.GetFileDetailByProgramguid(programguid);
                XLTrace.Write("Saved Location Details Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, programguid, _programFileGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Location Details Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, programguid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        public int PerformAutomatch(int fileProcessingTaskGuid, string aLoginUserId)
        {
            int status = -1;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                status = _empDAC.PerformAutomatch(fileProcessingTaskGuid, aLoginUserId, true);
                DataTable dtLocations = _empDAC.GetAllUnmatchedCountries(fileProcessingTaskGuid);
                List<CountryMatchBE> lstMatchedNames = new List<CountryMatchBE>();
                if (dtLocations != null && dtLocations.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dtLocations.Rows)
                    {
                        string location = dataRow["Location"].ToString().Trim();
                        if (string.IsNullOrWhiteSpace(location))
                        {
                            continue;
                        }
                        if (location.Length > 4)
                        {
                            location = Regex.Replace(location, @"[\d]", string.Empty);
                        }
                        string companyResult = GetGoogleApiResult(location + " Country Code", string.Empty);
                        if (!string.IsNullOrEmpty(companyResult))
                        {
                            var matchedName = ProcessApiCountryResult(companyResult);
                            if (matchedName.Count > 0)
                            {
                                lstMatchedNames.Add(new CountryMatchBE
                                {
                                    OriginalName = dataRow["Location"].ToString(),
                                    Title = matchedName.ElementAt(0).Key,
                                    SubTitle = CleanSubTitle(matchedName.ElementAt(0).Value)// Get subtitle from api
                                });
                            }
                        }
                    }

                }
                if (lstMatchedNames != null && lstMatchedNames.Any())
                {
                    _empDAC.UpdateCountryFromApi(lstMatchedNames, fileProcessingTaskGuid, true);
                }
                status = _empDAC.PerformAutomatch(fileProcessingTaskGuid, aLoginUserId, false);
                //Subtitle update
                var subTitles = lstMatchedNames.Where(x => !string.IsNullOrEmpty(x.SubTitle)).ToList();
                if (subTitles.Count > 0)
                {
                    _empDAC.UpdateCountryFromApi(subTitles, fileProcessingTaskGuid, false);
                    status = _empDAC.PerformAutomatch(fileProcessingTaskGuid, aLoginUserId, false);
                }
                status = _empDAC.GetNameMatchStatus(fileProcessingTaskGuid);
                XLTrace.Write("Automatch is completed successfully", "Automatch", System.Diagnostics.TraceEventType.Information, fileProcessingTaskGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Automatch is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "Automatch Error", System.Diagnostics.TraceEventType.Error, fileProcessingTaskGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return status;
        }

        public int PerformMarineAutomatch(int fileProcessingTaskGuid, string aLoginUserId)
        {
            int status = -1;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                status = _empDAC.PerformMarineAutomatch(fileProcessingTaskGuid, aLoginUserId);
                status = _empDAC.GetNameMatchStatus(fileProcessingTaskGuid);
                XLTrace.Write("Automatch is completed successfully", "Automatch", System.Diagnostics.TraceEventType.Information, fileProcessingTaskGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Automatch is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "Automatch Error", System.Diagnostics.TraceEventType.Error, fileProcessingTaskGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return status;
        }
        private static string CleanSubTitle(string subTitle)
        {
            subTitle = subTitle.ToLower().Trim();
            List<string> lstSubTitleKeys = new List<string>() { "country", "territory", "region" };
            if (lstSubTitleKeys.Any(x => subTitle.Contains(x)))
            {
                string[] words = subTitle.Split(' ');
                List<string> lstStates = new List<string>() { "state", "province", "territory" };
                if (words.Length == 2 && lstStates.Any(x => words[1] == x))
                {
                    return words[0];
                }
            }
            else
            {
                List<string> lstKeys = new List<string>() { "in", "of", "on", "at" };
                if (lstKeys.Any(x => subTitle.Contains(x)))
                {
                    var key = lstKeys.Where(x => lstKeys.Contains(x)).ToList().FirstOrDefault();
                    if (key != null)
                    {
                        int index = subTitle.LastIndexOf(key);
                        return subTitle.Substring(index + key.Length);
                    }
                }
            }
            return string.Empty;
        }


        public int PerformAPIMatch(ApiMatchDto apiMatch, string aLoginUserId)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var namematchData = apiMatch.MatchData.Select(x => new NameMatchStageBE
                {
                    FileprocessingtaskGuid = apiMatch.FileProcessingTaskGuid,
                    InsuranceGuid = x.InsuranceGuid,
                    OriginalName = x.NamedInsured,
                    MatchedName = x.ConformedName,
                    OriginalLocation = x.Location,
                    MatchedLocation = x.ConformedCountry,
                    OriginalIndustry = string.Empty,
                    MatchedIndustry = x.ConformedIndustry
                });
                DataTable dtMatch = ToDataTable(namematchData);
                _empDAC.BulkCopyNameMatchData(dtMatch);
                return _empDAC.PerformAPIMatch(apiMatch.FileProcessingTaskGuid, aLoginUserId);

            }
            catch (Exception ex)
            {
                XLTrace.Write("API Match data update failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                XLTrace.EndMethodTrace();
            }
        }
        public static DataTable ToDataTable<T>(IEnumerable<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public byte[] GetMappingExcelBytes(int fileProcessingTaskGuid)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(GetRMSData(fileProcessingTaskGuid));
            return ExportDSToExcel(ds, "", "");

        }
        public DataTable GetRMSData(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var colResult = this.GetSOVRMSMappedColumns(this._programGuid.Value);
                var cols = colResult.Select(x => x.RMSFieldName).Distinct().ToArray();
                var finalCols = "[" + string.Join("],[", cols) + "]";
                var dtFinal = _empDAC.GetRMSData(_programGuid.Value, finalCols);
                dtFinal = FormatColumnValue(dtFinal);
                XLTrace.Write("Retrieved Converted RMS Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                return dtFinal;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving Converted RMS Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        public DataTable GetFinalPreviewData(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var colResult = this.GetSOVRMSMappedColumns(this._programGuid.Value);
                var cols = colResult.Select(x => x.RMSFieldName).Distinct().ToArray();
                var finalCols = "[" + string.Join("],[", cols) + "]";
                var dtFinal = _empDAC.GetFinalPreviewData(_programGuid.Value, finalCols);
                dtFinal = FormatColumnValue(dtFinal);
                XLTrace.Write("Retrieved Converted RMS Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                return dtFinal;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving Converted RMS Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }
        /// <summary>
        /// Get Matched data
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="mode"></param>
        /// <returns></returns>        
        public byte[] GetMatchedMappingData(int fileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                string type = GetDocumentByOwnerGuid(fileProcessingTaskGuid).Type;
                var colResult = this.GetSOVRMSMappedColumns(this._programGuid.Value);
                var cols = colResult.Select(x => x.RMSFieldName).Distinct().ToArray();

                var removedCols = type == "1" ? cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "REVENUE", "EMPLOYEECOUNT", "ORIGINALCOVERAGE" }) : type == "3" ? cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "COVERAGE", "LIMIT", "ATTACHMENTPOINT", "SHARE", "PREMIUM", "LOCATION1", "LOCATION2", "INDUSTRY1", "INDUSTRY2" }) : cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "ASSETTYPE", "OBJECT_ID", "COMPLEX", "AREA", "PLATFORM", "FIELD" });
                var finalCols = "[" + string.Join("],[", removedCols) + "]";
                string marineAssetNamecol = type == "2" ? "[NAMEDINSURED] AS [ASSET NAME]" : "[NAMEDINSURED] AS [ORIGINAL NAME]";
                string priorityCols = marineAssetNamecol + ",[saved_name] AS [SAVED NAME],[LOCATION] AS [ORIGINAL_COUNTRY],[conformed_country] AS [CONFORMED_COUNTRY],[INDUSTRY] AS [ORIGINAL INDUSTRY],[conformed_industry] AS [CONFORMED INDUSTRY],";
                finalCols = priorityCols + finalCols + GetAdditionalColumnByLOB(fileProcessingTaskGuid);

                var dtFinal = _empDAC.GetMatchedData(_programGuid.Value, finalCols);
                dtFinal = FormatColumnValue(dtFinal);
                XLTrace.Write("Retrieved Converted RMS Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);

                DataSet ds = new DataSet();
                ds.Tables.Add(dtFinal);
                return ExportDSToExcel(ds, "", "");
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving Converted RMS Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Get All NameMatched data
        /// </summary>
        /// <param name="fileProcessingTaskGuids"></param>
        /// <returns></returns>        
        public List<NameMatchFileData> GetAllMatchedMappingData(string fileProcessingTaskGuids)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                List<NameMatchFileData> namematchData = new List<NameMatchFileData>();

                var fileProcessingIds = fileProcessingTaskGuids.Split('@');
                foreach (var id in fileProcessingIds)
                { 
                    this.GetFileDetailByTaskGuid(Convert.ToInt32(id));
                    string type = GetDocumentByOwnerGuid(Convert.ToInt32(id)).Type;
                    var colResult = this.GetSOVRMSMappedColumns(this._programGuid.Value);
                    var cols = colResult.Select(x => x.RMSFieldName).Distinct().ToArray();

                    var removedCols = type == "1" ? cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "REVENUE", "EMPLOYEECOUNT", "ORIGINALCOVERAGE" })
                        : type == "3" ? cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "COVERAGE", "LIMIT", "ATTACHMENTPOINT", "SHARE", "PREMIUM", "LOCATION1", "LOCATION2", "INDUSTRY1", "INDUSTRY2" })
                        : cols.Except(new List<string>() { "NAMEDINSURED", "LOCATION", "INDUSTRY", "ASSETTYPE", "OBJECT_ID", "COMPLEX", "AREA", "PLATFORM", "FIELD" });
                    var finalCols = "[" + string.Join("],[", removedCols) + "]";
                    string marineAssetNamecol = type == "2" ? "[NAMEDINSURED] AS [ASSET NAME]" : "[NAMEDINSURED] AS [ORIGINAL NAME]";
                    string priorityCols = type == "4" ? marineAssetNamecol + "," : marineAssetNamecol + ",[saved_name] AS [SAVED NAME],[LOCATION] AS [ORIGINAL_COUNTRY],[conformed_country] AS [CONFORMED_COUNTRY],[INDUSTRY] AS [ORIGINAL INDUSTRY],[conformed_industry] AS [CONFORMED INDUSTRY],";
                    finalCols = priorityCols + finalCols + GetAdditionalColumnByLOB(Convert.ToInt32(id));

                    var dtFinal = _empDAC.GetMatchedData(_programGuid.Value, finalCols);
                    dtFinal = FormatColumnValue(dtFinal);
                    XLTrace.Write("Retrieved Converted RMS Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                    DataSet ds = new DataSet();
                    ds.Tables.Add(dtFinal);
                    byte[] byteArrayData = ExportDSToExcel(ds, "", "");

                    NameMatchFileData data = new NameMatchFileData();
                    data.FileProcessingGuid = Convert.ToInt32(id);
                    data.NameMatchDownloadData = byteArrayData;
                    namematchData.Add(data);
                }
                return namematchData;

            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving Converted RMS Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

        }


        private string GetAdditionalColumnByLOB(int fileProcessingTaskGuid)
        {
            string columns = string.Empty;
            string type = this.GetDocumentByOwnerGuid(fileProcessingTaskGuid).Type;
            switch (type)
            {
                case "1":
                    columns = ",[ORIGINALCOVERAGE] AS [ORIGINAL COVERAGE],ciq AS [CIQ ID],conformed_region AS [CONFORMED REGION],conformed_industry_sector AS [CONFORMED INDUSTRY SECTOR],conformed_industry_group AS [CONFORMED INDUSTRY GROUP],tower_id AS [TOWER ID],REVENUE,EMPLOYEECOUNT, namematch_type  'NameMatchType',countrymatch_type 'CountryMatchType',industrymatch_type 'IndustryMatchType'";
                    break;
                case "2":
                    columns = ",object_id AS [OBJECT ID],data_source AS [DATA SOURCE],group_installation AS [GROUP INSTALLATION],ASSETTYPE,asset_subtype AS [ASSET SUB-TYPE]," +
                        "EPM_type AS [EPM TYPE],asset_installation_date AS [ASSET INSTALLATION DATE],asset_water_depth AS [ASSET WATER DEPTH],platform AS [PLATFORM],complex AS [COMPLEX],field AS [FIELD], area AS [AREA],IMOnumber AS [IMONUMBER],MMSInumber AS [MMSINUMBER]";
                    break;
                case "3":
                    columns = ",ciq AS [CIQ ID],conformed_region AS [CONFORMED REGION],conformed_industry_sector AS [CONFORMED INDUSTRY SECTOR],conformed_industry_group AS [CONFORMED INDUSTRY GROUP],namematch_type  'NameMatchType',countrymatch_type 'CountryMatchType',industrymatch_type 'IndustryMatchType'";
                    break;
            }
            return columns;
        }
        private static EnumValue<CellValues> ResolveCellDataTypeOnValue(string text)
        {
            int intVal;
            double doubleVal;
            if (int.TryParse(text, out intVal) || double.TryParse(text, out doubleVal))
            {
                return CellValues.Number;
            }
            else
            {
                return CellValues.String;
            }
        }

        private static byte[] ExportDSToExcel(DataSet ds, string destination, string sheetname)
        {
            using (MemoryStream mem = new MemoryStream())
            {
                SpreadsheetDocument workbook = SpreadsheetDocument.
                Create(mem, SpreadsheetDocumentType.Workbook);

                var workbookPart = workbook.AddWorkbookPart();
                workbook.WorkbookPart.Workbook = new DocumentFormat.OpenXml.Spreadsheet.Workbook();
                workbook.WorkbookPart.Workbook.Sheets = new DocumentFormat.OpenXml.Spreadsheet.Sheets();

                uint sheetId = 1;

                foreach (DataTable table in ds.Tables)
                {
                    var sheetPart = workbook.WorkbookPart.AddNewPart<WorksheetPart>();
                    var sheetData = new DocumentFormat.OpenXml.Spreadsheet.SheetData();
                    sheetPart.Worksheet = new DocumentFormat.OpenXml.Spreadsheet.Worksheet(sheetData);

                    DocumentFormat.OpenXml.Spreadsheet.Sheets sheets = workbook.WorkbookPart.Workbook.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.Sheets>();
                    string relationshipId = workbook.WorkbookPart.GetIdOfPart(sheetPart);

                    if (sheets.Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Count() > 0)
                    {
                        sheetId =
                            sheets.Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Select(s => s.SheetId.Value).Max() + 1;
                    }

                    DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = new DocumentFormat.OpenXml.Spreadsheet.Sheet() { Id = relationshipId, SheetId = sheetId, Name = sheetname != "" ? sheetname : "Destination Data" };
                    sheets.Append(sheet);

                    DocumentFormat.OpenXml.Spreadsheet.Row headerRow = new DocumentFormat.OpenXml.Spreadsheet.Row();

                    List<String> columns = new List<string>();
                    foreach (DataColumn column in table.Columns)
                    {
                        columns.Add(column.ColumnName);

                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();

                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(column.ColumnName);
                        headerRow.AppendChild(cell);
                    }

                    sheetData.AppendChild(headerRow);

                    foreach (DataRow dsrow in table.Rows)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Row newRow = new DocumentFormat.OpenXml.Spreadsheet.Row();
                        foreach (String col in columns)
                        {
                            DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                            string columnValue = ReplaceHexadecimalSymbols(dsrow[col].ToString());
                            cell.DataType = ResolveCellDataTypeOnValue(columnValue);
                            cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(columnValue);
                            newRow.AppendChild(cell);
                        }
                        sheetData.AppendChild(newRow);
                    }
                }
                workbook.Save();
                workbook.Close();
                return mem.ToArray();
            }
        }
        private static string ReplaceHexadecimalSymbols(string txt)
        {
            string pattern = "[\x00-\x08\x0B\x0C\x0E-\x1F]";//\x1A
            return Regex.Replace(txt, pattern, string.Empty, RegexOptions.Compiled);
        }
        /// <summary>
        /// Format DateTime Column
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static DataTable FormatColumnValue(DataTable dt)
        {
            DataTable dtCln = dt.Clone();
            if (dtCln.Columns.Contains(RMSColumn.YEAR_BUILT))
            {
                dtCln.Columns[RMSColumn.YEAR_BUILT].DataType = typeof(string);
            }
            if (dtCln.Columns.Contains(RMSColumn.YEAR_UPGRAD))
            {
                dtCln.Columns[RMSColumn.YEAR_UPGRAD].DataType = typeof(string);
            }

            if (dtCln.Columns.Contains(RMSColumn.CV1VAL))
            {
                dtCln.Columns[RMSColumn.CV1VAL].DataType = typeof(string);
            }
            if (dtCln.Columns.Contains(RMSColumn.CV2VAL))
            {
                dtCln.Columns[RMSColumn.CV2VAL].DataType = typeof(string);
            }
            if (dtCln.Columns.Contains(RMSColumn.CV3VAL))
            {
                dtCln.Columns[RMSColumn.CV3VAL].DataType = typeof(string);
            }
            if (dtCln.Columns.Contains(RMSColumn.TOTAL_VALUE))
            {
                dtCln.Columns[RMSColumn.TOTAL_VALUE].DataType = typeof(string);
            }
            if (dtCln.Columns.Contains(RMSColumn.CV9VAL))
            {
                dtCln.Columns[RMSColumn.CV9VAL].DataType = typeof(string);
            }
            foreach (DataRow row in dt.Rows)
            {
                dtCln.ImportRow(row);
            }

            var valCellFormat = "#,0.00;(#,0.00)";
            dtCln.AsEnumerable().ToList<DataRow>().ForEach(r =>
            {
                if (dtCln.Columns.Contains(RMSColumn.YEAR_BUILT))
                {
                    r[RMSColumn.YEAR_BUILT] = !string.IsNullOrEmpty(Convert.ToString(r[RMSColumn.YEAR_BUILT])) ? Convert.ToDateTime(r[RMSColumn.YEAR_BUILT]).ToString("MM/dd/yyyy") : r[RMSColumn.YEAR_BUILT];
                }
                if (dtCln.Columns.Contains(RMSColumn.YEAR_UPGRAD))
                {
                    r[RMSColumn.YEAR_UPGRAD] = !string.IsNullOrEmpty(Convert.ToString(r[RMSColumn.YEAR_UPGRAD])) ? Convert.ToDateTime(r[RMSColumn.YEAR_UPGRAD]).ToString("MM/dd/yyyy") : r[RMSColumn.YEAR_UPGRAD];
                }

                // Value col Related Formats
                if (dtCln.Columns.Contains(RMSColumn.CV1VAL))
                {
                    double dCV1VAL = Convert.ToDouble(r[RMSColumn.CV1VAL]);
                    r[RMSColumn.CV1VAL] = dCV1VAL.ToString(valCellFormat);
                }
                if (dtCln.Columns.Contains(RMSColumn.CV2VAL))
                {
                    double dCV3VAL = Convert.ToDouble(r[RMSColumn.CV2VAL]);
                    r[RMSColumn.CV2VAL] = dCV3VAL.ToString(valCellFormat);
                }
                if (dtCln.Columns.Contains(RMSColumn.CV3VAL))
                {
                    double dCV3VAL = Convert.ToDouble(r[RMSColumn.CV3VAL]);
                    r[RMSColumn.CV3VAL] = dCV3VAL.ToString(valCellFormat);
                }
                if (dtCln.Columns.Contains(RMSColumn.TOTAL_VALUE))
                {
                    double dTOTVAL = Convert.ToDouble(r[RMSColumn.TOTAL_VALUE]);
                    r[RMSColumn.TOTAL_VALUE] = dTOTVAL.ToString(valCellFormat);
                }
                if (dtCln.Columns.Contains(RMSColumn.CV9VAL))
                {
                    double dCV9VAL = Convert.ToDouble(r[RMSColumn.CV9VAL]);
                    r[RMSColumn.CV9VAL] = dCV9VAL.ToString(valCellFormat);
                }

            });
            return dtCln;
        }


        public bool SaveOccupancySearchList(List<OccKeyWordSearchBE> occKeyWordSearchBE, int FileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(FileProcessingTaskGuid);
                _empDAC.DeleteOccKeySearch(_programFileGuid.Value);
                occKeyWordSearchBE.ForEach(x =>
                {
                    x.ProgramFileGuid = _programFileGuid;
                    x.ChangedStatus = EntityStatus.StatusInsert;

                });
                base.Persist<OccKeyWordSearchBE>(occKeyWordSearchBE, "EMP");
                XLTrace.Write("Stage - 2 : Saved Occupancy KeyWord Search List Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
            }

            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Saving Occupancy KeyWord Search List Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        public List<OccKeyWordSearchBE> GetOccupancySearchList(int FileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(FileProcessingTaskGuid);
                var occKeyWordSearchList = _empDAC.GetOccupancySearchList<OccKeyWordSearchBE>(_programFileGuid.Value);
                XLTrace.Write("Stage - 2 : Retrieved Occupancy KeyWord Search List Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                return occKeyWordSearchList;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Retrieving Occupancy KeyWord Search List Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }


        /// <summary>
        /// Get Value Type RMS Fields
        /// </summary>
        /// <param name="FileProcessingTaskGuid"></param>
        /// <returns></returns>
        public List<SOVtoRMSFieldBE> GetValueRMSFields(int FileProcessingTaskGuid)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(FileProcessingTaskGuid);
                var occKeyWordSearchList = _empDAC.GetValueRMSFields<SOVtoRMSFieldBE>();
                XLTrace.Write("Stage - 2 : Retrieved Value Type RMS Fields List Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                return occKeyWordSearchList;
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 2 : Retrieving Value Type RMS Fields List Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }


        #region SOVMappedColumns
        /// <summary>
        /// Get All RMS Columns
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>
        public List<SOVRMSMappedColumnsBE> GetSOVRMSMappedColumns(int programGuid)
        {
            DocumentBE docBE = this.GetDocumentByProgramGuid(programGuid);
            List<SOVRMSMappedColumnsBE> mappedColumns = _empDAC.GetSOVRMSMappedColumns<SOVRMSMappedColumnsBE>(programGuid, docBE.Type);
            return mappedColumns;
        }

        /// <summary>
        /// Get rms converted data for the given ProgramGuid
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>
        public bool GetConvertedRMS(int programGuid)
        {
            bool rmsData = _empDAC.GetConvertedRMS<RMSConvertedDataBE>(programGuid);
            return rmsData;
        }

        #endregion

        #region Floor Occupancy
        /// <summary>
        /// Get Value For Floor Occupancy
        /// </summary>
        /// <param name="aFloorOccupancy"></param>
        /// <param name="aStories"></param>
        /// <returns></returns>
        private static string GetFloorOccupancy(string aFloorOccupancy, Int64? aStories)
        {
            string floorOccupied = string.Empty;

            if (string.IsNullOrEmpty(aFloorOccupancy) || aStories == null || (aStories != null && aStories == 0))
            {
                return string.Empty;
            }
            else if (!string.IsNullOrEmpty(aFloorOccupancy) && aStories > 0)
            {
                floorOccupied = CheckFloorsOccupied(aFloorOccupancy, aStories);
            }
            return floorOccupied;
        }
        /// <summary>
        /// Check Floors Occupied
        /// </summary>
        /// <param name="aFloorOccupancy"></param>
        /// <param name="aStories"></param>
        /// <returns></returns>
        private static string CheckFloorsOccupied(string aFloorOccupancy, Int64? aStories)
        {
            string floorOccupancy = string.Empty;
            string[] vArray;
            string arrayVal, LRng, URng, tempRng;

            //Remove extra space and special characters
            aFloorOccupancy = FormatFloorOccupancy(aFloorOccupancy);
            vArray = aFloorOccupancy.Split(',');

            for (int index = 0; index < vArray.Length; index++)
            {
                arrayVal = Convert.ToString(vArray.GetValue(index));

                if (arrayVal.All(Char.IsDigit))
                {
                    if (Int32.Parse(arrayVal) == aStories)
                    {
                        arrayVal = Convert.ToString(aStories - 1);
                    }
                    else if (Int32.Parse(arrayVal) > aStories)
                    {
                        arrayVal = string.Empty;
                    }
                }

                else if (arrayVal.Contains("-"))
                {
                    int flooroccType = 0;

                    if (Int32.TryParse(arrayVal, out flooroccType))
                    {
                        //check for negative values
                        if (Convert.ToInt32(arrayVal) < 0)
                        {
                            if (Convert.ToInt32(arrayVal) < -5)
                            {
                                arrayVal = "-5";
                            }
                            else
                            {
                                string negValue = Convert.ToString(arrayVal);
                                arrayVal = negValue;
                            }
                        }
                        else
                        {
                            string[] tempValArray = arrayVal.Split('-');
                            LRng = tempValArray[0];
                            URng = tempValArray[1];
                            if (LRng.All(Char.IsDigit) && URng.All(Char.IsDigit))
                            {
                                //Swap if upper value is less than the lower value
                                if (Int32.Parse(URng) < Int32.Parse(LRng))
                                {
                                    tempRng = URng;
                                    URng = LRng;
                                    LRng = tempRng;
                                }
                                if (Int32.Parse(URng) == aStories)
                                {
                                    URng = Convert.ToString(aStories - 1);
                                }
                                if (Int32.Parse(URng) > aStories || Int32.Parse(LRng) > aStories)
                                {
                                    arrayVal = string.Empty;
                                }
                                else if (Int32.Parse(URng) == Int32.Parse(LRng) || Int32.Parse(URng) < Int32.Parse(LRng))
                                {
                                    arrayVal = URng;
                                }
                                else
                                {
                                    arrayVal = LRng + "-" + URng;
                                }
                            }
                            else
                            {
                                arrayVal = string.Empty;
                            }

                        }

                    }
                }
                if (floorOccupancy == string.Empty && !string.IsNullOrEmpty(arrayVal))
                {
                    floorOccupancy = arrayVal;
                }
                else if (!string.IsNullOrEmpty(arrayVal))
                {
                    floorOccupancy = floorOccupancy + "," + arrayVal;
                }
            }

            //get distinct values
            if (!string.IsNullOrEmpty(floorOccupancy))
            {
                var farray = floorOccupancy.Split(',');
                var output = farray.Distinct().ToArray();
                floorOccupancy = string.Join(",", output);
            }

            return floorOccupancy;
        }
        /// <summary>
        /// Format Floor Occupancy Value
        /// </summary>
        /// <param name="aFloorOccupancy"></param>        
        /// <returns></returns>
        private static string FormatFloorOccupancy(string aFloorOccupancy)
        {
            aFloorOccupancy = aFloorOccupancy.ToLower();
            aFloorOccupancy = aFloorOccupancy.Replace(" ", "");
            aFloorOccupancy = aFloorOccupancy.Replace("to", "-");
            aFloorOccupancy = aFloorOccupancy.Replace("through", "-");
            aFloorOccupancy = aFloorOccupancy.Replace(";", ",");
            aFloorOccupancy = aFloorOccupancy.Replace("/", ",");
            aFloorOccupancy = aFloorOccupancy.Replace(@"\", ",");
            aFloorOccupancy = aFloorOccupancy.Replace("|", ",");
            aFloorOccupancy = aFloorOccupancy.Replace(",,", ",");
            aFloorOccupancy = aFloorOccupancy.Replace("first", "1");
            aFloorOccupancy = aFloorOccupancy.Replace("second", "2");
            aFloorOccupancy = aFloorOccupancy.Replace("third", "3");
            aFloorOccupancy = aFloorOccupancy.Replace("fourth", "4");
            aFloorOccupancy = aFloorOccupancy.Replace("fifth", "5");
            aFloorOccupancy = aFloorOccupancy.Replace("sixth", "6");
            aFloorOccupancy = aFloorOccupancy.Replace("seventh", "7");
            aFloorOccupancy = aFloorOccupancy.Replace("eighth", "8");
            aFloorOccupancy = aFloorOccupancy.Replace("ninth", "9");
            aFloorOccupancy = aFloorOccupancy.Replace("tenth", "10");
            aFloorOccupancy = aFloorOccupancy.Replace("eleventh", "11");
            aFloorOccupancy = aFloorOccupancy.Replace("twelth", "12");
            aFloorOccupancy = aFloorOccupancy.Replace("thirteenth", "13");
            aFloorOccupancy = aFloorOccupancy.Replace("fourteenth", "14");
            aFloorOccupancy = aFloorOccupancy.Replace("fifteenth", "15");
            aFloorOccupancy = aFloorOccupancy.Replace("sixteenth", "16");
            aFloorOccupancy = aFloorOccupancy.Replace("seventeenth", "17");
            aFloorOccupancy = aFloorOccupancy.Replace("eighteenth", "18");
            aFloorOccupancy = aFloorOccupancy.Replace("nineteenth", "19");
            aFloorOccupancy = aFloorOccupancy.Replace("floors", "");
            aFloorOccupancy = aFloorOccupancy.Replace("floor", "");
            aFloorOccupancy = aFloorOccupancy.Replace("st", "");
            aFloorOccupancy = aFloorOccupancy.Replace("nd", "");
            aFloorOccupancy = aFloorOccupancy.Replace("rd", "");
            aFloorOccupancy = aFloorOccupancy.Replace("th", "");
            return aFloorOccupancy;
        }
        #endregion

        #region Update Mapping Issues

        /// <summary>
        /// Get default mapped issues if present already and map it accordingly
        /// </summary>
        /// <param name="mappingDataIssuesList"></param>
        /// <param name="loginId"></param>
        /// <returns></returns>
        private List<MappingDataIssuesDto> UpdateMappingIssues(List<MappingDataIssuesDto> mappingDataIssuesList, string loginId)
        {
            List<MappingIssuesDefBE> lstAllMappingIssues = new List<MappingIssuesDefBE>();
            List<MappingDataIssuesDto> lstUpdatedMappingIssues = new List<MappingDataIssuesDto>();
            List<MappingIssuesDefBE> lstExistingMappingIssues = new List<MappingIssuesDefBE>();
            MappingIssuesDefBE mappingIssuesDef = new MappingIssuesDefBE();
            lstAllMappingIssues = base.MaterializeCollection<MappingIssuesDefBE>(mappingIssuesDef, null);
            var secModsList = this.GetSecModLookups(mappingDataIssuesList.Select(x => x.OwnerGuid).FirstOrDefault());
            if (lstAllMappingIssues != null && lstAllMappingIssues.Count() > 0)
            {
                lstExistingMappingIssues = lstAllMappingIssues.Where(x => x.AddedBy == loginId && x.IsActive == true).ToList();
            }
            foreach (MappingDataIssuesDto mappingIssues in mappingDataIssuesList)
            {
                MappingIssuesDefBE allMappingIssues = new MappingIssuesDefBE();
                if (mappingIssues.SOVSourceData == null)
                {
                    mappingIssues.SOVSourceData = string.Empty;
                }
                if (lstExistingMappingIssues != null && lstExistingMappingIssues.Count > 0)
                {
                    allMappingIssues = lstExistingMappingIssues.Where(x => x.RMSFieldName == mappingIssues.RMSFieldName && x.SOVSourceData == mappingIssues.SOVSourceData && x.CountryCode == mappingIssues.CountryCode).OrderByDescending(x => x.ModifyDt).FirstOrDefault();
                }
                if (allMappingIssues != null && allMappingIssues.Count > 0)
                {
                    BulkCodeItem selectedValue = JsonConvert.DeserializeObject<BulkCodeItem>(allMappingIssues.RMSSelectedValue);
                    if (selectedValue != null)
                    {
                        mappingIssues.RMSSelectedValue = selectedValue;
                    }
                    else if (mappingIssues.ISSecondCharact == true && mappingIssues.SOVSourceData == string.Empty && mappingIssues.RMSSelectedValue == null)
                    {
                        var secMods = secModsList.Where(x => x.RMSFieldGUID == mappingIssues.RMSFieldGUID);
                        mappingIssues.RMSSelectedValue = secMods.Where(a => a.SchemeName == mappingIssues.Scheme && a.BulkOption == 1).OrderBy(xc => xc.OrderNum).Select(b => new { b.LookUp, b.SchemeName, b.Description }).Distinct()
                                            .Select(y => new BulkCodeItem() { Code = y.LookUp, Description = y.Description, Schema = y.SchemeName }).Distinct().OrderBy(b => b.Schema).ThenBy(c => c.Code).Where(d => d.Code == "0").ToList().FirstOrDefault();
                    }
                }
                else
                {
                    if ((mappingIssues.RMSFieldName == RMSColumn.BLDG_CLASS || mappingIssues.RMSFieldName == RMSColumn.OCC_TYPE) && mappingIssues.SOVSourceData == string.Empty)
                    {
                        BulkCodeItem bulkCode = new BulkCodeItem() { Code = "0", Description = "Unknown", Lookup = "ATC: 0", Schema = "ATC", BulkOption = 1 };
                        mappingIssues.RMSSelectedValue = bulkCode;
                    }
                    else if (mappingIssues.RMSFieldName == RMSColumn.SITE_CURRENCY && mappingIssues.SOVSourceData == string.Empty)
                    {
                        BulkCodeItem bulkCode = new BulkCodeItem() { Code = "USD", Description = "US Dollar", Lookup = "USD", Schema = null, BulkOption = 1 };
                        mappingIssues.RMSSelectedValue = bulkCode;
                    }
                    else if (mappingIssues.ISSecondCharact == true && mappingIssues.SOVSourceData == string.Empty)
                    {
                        var secMods = secModsList.Where(x => x.RMSFieldGUID == mappingIssues.RMSFieldGUID);
                        mappingIssues.RMSSelectedValue = secMods.Where(a => a.SchemeName == mappingIssues.Scheme && a.BulkOption == 1).OrderBy(xc => xc.OrderNum).Select(b => new { b.LookUp, b.SchemeName, b.Description }).Distinct()
                                            .Select(y => new BulkCodeItem() { Code = y.LookUp, Description = y.Description, Schema = y.SchemeName }).Distinct().OrderBy(b => b.Schema).ThenBy(c => c.Code).Where(d => d.Code == "0").ToList().FirstOrDefault();
                    }
                }
                lstUpdatedMappingIssues.Add(mappingIssues);
            }
            return lstUpdatedMappingIssues;

        }

        #endregion

        #region Upload RMS Locations
        /// <summary>
        /// Upload RMS Locations
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ProgramGuid"></param>
        /// <param name="LoginUserId"></param>
        /// <returns></returns>
        public UploadResponseDto UploadData(DataTable uploadData, int programGuid, string loginUserId)
        {

            UploadResponseDto uploadResponseVM = new UploadResponseDto();
            List<RMSConvertedDataBE> rmsConvertedDataBE = new List<RMSConvertedDataBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByProgramguid(programGuid);
                uploadResponseVM = this.ValidateUploadedData(uploadData);

                if (uploadResponseVM.IsSuccess)
                {
                    //get duplicate location number records
                    var duplicates = uploadData.AsEnumerable().GroupBy(x => x.Field<string>(RMSColumn.LOC_NUM)).Where(gr => gr.Count() > 1).ToList();

                    //get empty location number records
                    var emptyRecords = uploadData.AsEnumerable().Where(x => (string.IsNullOrEmpty(x.Field<string>(RMSColumn.LOC_NUM)) || string.IsNullOrEmpty(x.Field<string>(RMSColumn.ID)))).ToList();

                    //check if loc_num has any string values
                    int celldType = 0;
                    var stringLocNumsRecords = uploadData.AsEnumerable().ToList().Where(x => Int32.TryParse(x.Field<string>(RMSColumn.LOC_NUM), out celldType) == false);

                    //update location number
                    if (duplicates.Any() || emptyRecords.Any() || stringLocNumsRecords.Any())
                    {
                        int loc_num = 1;
                        uploadData.AsEnumerable().ToList().ForEach(x =>
                        {
                            x.SetField(RMSColumn.LOC_NUM, loc_num++);
                            x.SetField(RMSColumn.ID, x.Field<string>(RMSColumn.LOC_NUM));
                        });
                    }


                    //validations for sitename duplication

                    var duplicateSiteNames = uploadData.AsEnumerable().GroupBy(x => x.Field<string>(RMSColumn.SITE_NAME)).Where(gr => gr.Count() > 1).ToList();

                    if (duplicateSiteNames.Any())
                    {
                        uploadData.AsEnumerable().ToList().ForEach(x =>
                        {

                            x.SetField(RMSColumn.SITE_NAME, x.Field<string>(RMSColumn.LOC_NUM));
                        });
                    }

                    //get recent uploaded sov fileprocessing guid
                    FileProcessingTasksBE fileProcessingTasksBE = new FileProcessingTasksBE();
                    fileProcessingTasksBE = this.GetFileProcessingTaskByProgramGuid(programGuid);


                    rmsConvertedDataBE = ConvertDataTableToList<RMSConvertedDataBE>(uploadData);
                    rmsConvertedDataBE.ForEach(x =>
                    {
                        x.ChangedStatus = EntityStatus.StatusInsert;
                        x.Emp_fileprocessingtask_guid = fileProcessingTasksBE.FileProcessingTaskGuid;
                        x.PROGRAMGUID = programGuid;
                    });

                    _empDAC.SaveUploadedLocations(programGuid, rmsConvertedDataBE, loginUserId);
                    XLTrace.Write("Uploaded RMS Location(s) Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, _programGuid, _programFileGuid);
                }
            }

            catch (Exception ex)
            {
                XLTrace.Write("Upload RMS Location(s) Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }

            return uploadResponseVM;
        }


        /// <summary>
        /// Validate Uploaded Data
        /// </summary>
        /// <param name="uploadData"></param>
        /// <returns></returns>
        public UploadResponseDto ValidateUploadedData(DataTable uploadData)
        {

            UploadResponseDto uploadResponseVM = new UploadResponseDto();
            var limitToList = (IEnumerable<ILimitToListBE>)this.GetLimitToListValues();
            var occBldclasslk = (IEnumerable<IOccBldClassLookupBE>)this.GetOccBldClassValues();

            List<string> mismatchedColumns = new List<string>();

            foreach (DataColumn dc in uploadData.Columns)
            {
                if ((dc.ColumnName.Equals(RMSColumn.SITE_CURRENCY, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.CNTRY_CODE, StringComparison.OrdinalIgnoreCase) ||
                   dc.ColumnName.Equals(RMSColumn.OCC_TYPE, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.BLDG_CLASS, StringComparison.OrdinalIgnoreCase) ||
                   dc.ColumnName.Equals(RMSColumn.C_ATC, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.C_RMS, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.C_IFM_DESC, StringComparison.OrdinalIgnoreCase)) ||
                   dc.ColumnName.Equals(RMSColumn.O_ATC, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.OCC_SCHEME, StringComparison.OrdinalIgnoreCase) ||
                   dc.ColumnName.Equals(RMSColumn.O_IFM_2_digit, StringComparison.OrdinalIgnoreCase) || dc.ColumnName.Equals(RMSColumn.O_IFM_4_digit, StringComparison.OrdinalIgnoreCase) ||
                   dc.ColumnName.Equals(RMSColumn.BLDG_SCHEME, StringComparison.OrdinalIgnoreCase))
                {
                    //CURRENCY VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.SITE_CURRENCY, StringComparison.OrdinalIgnoreCase))
                    {
                        var query = uploadData.AsEnumerable().
                                          Select(item => new
                                          {
                                              currencyValues = item.Field<string>(RMSColumn.SITE_CURRENCY)
                                          }).ToList();

                        var mismatched = query.Where(p => !limitToList.Where(x => x.RMSFieldName == RMSColumn.SITE_CURRENCY).Select(x => x.Code).Contains(p.currencyValues)).ToList();
                        if (mismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }
                    //CNTRYCODE VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.CNTRY_CODE, StringComparison.OrdinalIgnoreCase))
                    {
                        var query = uploadData.AsEnumerable().
                                          Select(item => new
                                          {
                                              cntryCodeValues = item.Field<string>(RMSColumn.CNTRY_CODE)
                                          }).ToList();

                        var mismatched = query.Where(p => !limitToList.Where(x => x.RMSFieldName == RMSColumn.CNTRY_CODE).Select(x => x.Code).Contains(p.cntryCodeValues)).ToList();
                        if (mismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //OCCUPANCYTYPE VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.OCC_TYPE, StringComparison.OrdinalIgnoreCase))
                    {
                        var occTypeColValues = uploadData.AsEnumerable().
                                           Select(item => new
                                           {
                                               OccValues = item.Field<string>(RMSColumn.OCC_TYPE)
                                           }).ToList();

                        var occTypeValMismatched = occTypeColValues.Where(p => !limitToList.Where(x => (x.RMSFieldName == RMSColumn.OCC_TYPE)).Select(x => x.Code).Contains(p.OccValues)).ToList();
                        if (occTypeValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //O_ATC VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.O_ATC, StringComparison.OrdinalIgnoreCase))
                    {
                        var o_ATCColValues = uploadData.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>(RMSColumn.O_ATC))).
                                           Select(item => new
                                           {
                                               OATCValues = item.Field<string>(RMSColumn.O_ATC)
                                           }).ToList();

                        var o_ATCValMismatched = o_ATCColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.OCC_TYPE)).Select(x => x.O_ATC).Contains(p.OATCValues)).ToList();
                        if (o_ATCValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //O_IFM_2_DIGIT VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.O_IFM_2_digit, StringComparison.OrdinalIgnoreCase))
                    {
                        var o_IFM2DigitColValues = uploadData.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>(RMSColumn.O_IFM_2_digit))).
                                           Select(item => new
                                           {
                                               O_IFM_2_DIGITValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.O_IFM_2_digit)) ? null : item.Field<string>(RMSColumn.O_IFM_2_digit)
                                           }).ToList();

                        var o_IFM2DigitValMismatched = o_IFM2DigitColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.OCC_TYPE)).Select(x => x.O_IFM_2digit).Contains(p.O_IFM_2_DIGITValues)).ToList();
                        if (o_IFM2DigitValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //O_IFM_4_DIGIT VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.O_IFM_4_digit, StringComparison.OrdinalIgnoreCase))
                    {
                        var o_IFM4DigitColValues = uploadData.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>(RMSColumn.O_IFM_4_digit))).
                                           Select(item => new
                                           {
                                               O_IFM_4_DIGITValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.O_IFM_4_digit)) ? null : item.Field<string>(RMSColumn.O_IFM_4_digit)

                                           }).ToList();

                        var o_IFM4igitValMismatched = o_IFM4DigitColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.OCC_TYPE)).Select(x => x.O_IFM_4digit).Contains(p.O_IFM_4_DIGITValues)).ToList();
                        if (o_IFM4igitValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //OCC_SCHEME VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.OCC_SCHEME, StringComparison.OrdinalIgnoreCase))
                    {
                        var occSchemeColValues = uploadData.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>(RMSColumn.OCC_SCHEME))).
                                           Select(item => new
                                           {
                                               OccSchemeValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.OCC_SCHEME)) ? null : item.Field<string>(RMSColumn.OCC_SCHEME)

                                           }).ToList();

                        var occSchemeValMismatched = occSchemeColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.OCC_TYPE)).Select(x => x.EMPSchemeName).Contains(p.OccSchemeValues)).ToList();
                        if (occSchemeValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //BLDG_CLASS VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.BLDG_CLASS, StringComparison.OrdinalIgnoreCase))
                    {
                        var bldgClassColValues = uploadData.AsEnumerable().
                                           Select(item => new
                                           {
                                               BldgClassValues = item.Field<string>(RMSColumn.BLDG_CLASS)
                                           }).ToList();

                        var bldgClassValMismatched = bldgClassColValues.Where(p => !occBldclasslk.Where(x => x.RMSFieldName == RMSColumn.BLDG_CLASS).Select(x => x.Code).Contains(p.BldgClassValues)).ToList();
                        if (bldgClassValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //C_IFM_DESC VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.C_IFM_DESC, StringComparison.OrdinalIgnoreCase))
                    {
                        var c_IFMDESColValues = uploadData.AsEnumerable().
                                           Select(item => new
                                           {
                                               C_IFM_DESCValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.C_IFM_DESC)) ? null : item.Field<string>(RMSColumn.C_IFM_DESC)
                                           }).ToList();

                        var c_IFMDescValMismatched = c_IFMDESColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.BLDG_CLASS)).Select(x => x.C_IFMDescription).Contains(p.C_IFM_DESCValues)).ToList();
                        if (c_IFMDescValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //C_ATC VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.C_ATC, StringComparison.OrdinalIgnoreCase))
                    {
                        var c_ATCColValues = uploadData.AsEnumerable().
                                           Select(item => new
                                           {
                                               CATCValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.C_ATC)) ? null : item.Field<string>(RMSColumn.C_ATC),
                                               C_IFM_DESCValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.C_IFM_DESC)) ? null : item.Field<string>(RMSColumn.C_IFM_DESC),
                                           }).ToList();

                        var c_ATCValMismatched = c_ATCColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.BLDG_CLASS && x.C_IFMDescription == p.C_IFM_DESCValues)).Select(x => x.C_ATC).Contains(p.CATCValues)).ToList();
                        if (c_ATCValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //C_RMS VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.C_RMS, StringComparison.OrdinalIgnoreCase))
                    {
                        var c_RMSColValues = uploadData.AsEnumerable().
                                           Select(item => new
                                           {
                                               C_RMSValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.C_RMS)) ? null : item.Field<string>(RMSColumn.C_RMS),
                                               C_IFM_DESCValues = string.IsNullOrEmpty(item.Field<string>(RMSColumn.C_IFM_DESC)) ? null : item.Field<string>(RMSColumn.C_IFM_DESC),
                                           }).ToList();

                        var c_RMSValMismatched = c_RMSColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.BLDG_CLASS && x.C_IFMDescription == p.C_IFM_DESCValues)).Select(x => x.C_RMS).Contains(p.C_RMSValues)).ToList();
                        if (c_RMSValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }

                    //BLDG_SCHEME VALIDATION
                    if (dc.ColumnName.Equals(RMSColumn.BLDG_SCHEME, StringComparison.OrdinalIgnoreCase))
                    {
                        var bldgschemeColValues = uploadData.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>(RMSColumn.BLDG_SCHEME))).
                                           Select(item => new
                                           {
                                               BLDG_SCHEME_Values = item.Field<string>(RMSColumn.BLDG_SCHEME),

                                           }).ToList();

                        var bldgschemeValMismatched = bldgschemeColValues.Where(p => !occBldclasslk.Where(x => (x.RMSFieldName == RMSColumn.BLDG_CLASS)).Select(x => x.EMPSchemeName).Contains(p.BLDG_SCHEME_Values)).ToList();
                        if (bldgschemeValMismatched.Count() > 0)
                        {
                            mismatchedColumns.Add(dc.ColumnName);
                        }
                    }
                }
            }
            if (mismatchedColumns.Count() > 0)
            {
                uploadResponseVM.IsSuccess = false;
                string invalidCols = string.Join(", ", mismatchedColumns.ToArray());
                uploadResponseVM.ErrorMessage = "Incorrect Values in " + invalidCols + " Column(s)." + " Please check and upload it again.";
            }
            else
            {
                uploadResponseVM.IsSuccess = true;
            }
            return uploadResponseVM;
        }

        #endregion
        #endregion

        #region NameMatch

        /// <summary>
        /// Get all file data for namematch
        /// </summary>
        /// <param name="statusId"></param>
        /// <returns></returns>

        public List<DocumentBE> GetNameMatchDocuments(int statusId)
        {
            List<DocumentBE> documentBEList = new List<DocumentBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                documentBEList = _empDAC.GetNameMatchFiles<DocumentBE>(statusId);
                XLTrace.Write("Retrieved all document detail pending for name match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all document detail pending for name match Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return documentBEList;
        }

        /// <summary>
        /// Get NameMatch Data
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public List<NameMatchFieldBE> GetNameMatchData(int fileProcessingTaskGuid)
        {
            List<NameMatchFieldBE> nameMatchList = new List<NameMatchFieldBE>();
            try
            {

                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                this.GetFileDetailByTaskGuid(fileProcessingTaskGuid);
                var finalCols = "[emt_insurance_guid],[NAMEDINSURED] ,[LOCATION]";
                var dtFinal = _empDAC.GetRMSData(_programGuid.Value, finalCols);
                dtFinal = dtFinal.DefaultView.ToTable(true, "emt_insurance_guid", "NAMEDINSURED", "LOCATION");
                nameMatchList = dtFinal.AsEnumerable().Select(x => new NameMatchFieldBE
                {
                    Location = x.Field<string>("Location").ToString(),
                    NamedInsured = x.Field<string>("NamedInsured").ToString(),
                    InsuranceGuid = x.Field<int>("emt_insurance_guid")
                }).ToList();
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                XLTrace.Write("Retrieved all document detail pending for name match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all document detail pending for name match Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return nameMatchList;
        }
        /// <summary>
        /// get all unmatched companies for aan imported file
        /// </summary>
        /// <param name="programGuid"></param>
        /// <returns></returns>
        public List<UnmatchedCompaniesBE> GetUnmatchedCompanies(int programGuid)
        {
            List<UnmatchedCompaniesBE> unMatchedCompanies = new List<UnmatchedCompaniesBE>();
            try
            {

                XLTrace.StartMethodTrace();
                unMatchedCompanies = _empDAC.GetUnmatchedCompanies(programGuid);
                XLTrace.Write("Get unmatched companies is completed successfully", "ApiMatch", System.Diagnostics.TraceEventType.Information, programGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Get unmatched companies is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error, programGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return unMatchedCompanies;
        }

        /// <summary>
        /// Get matches from google api
        /// </summary>
        /// <param name="company"></param>
        /// <param name="country"></param>
        /// <returns></returns>
        public List<GoogleApiResultBE> GetCompanyFromGoogleAPI(string company, string country)
        {
            List<GoogleApiResultBE> apiResults = new List<GoogleApiResultBE>();
            try
            {
                XLTrace.StartMethodTrace();
                string result = GetGoogleApiResult(company + " " + country, "United States");
                apiResults = ProcessCompanyResult(result);
                XLTrace.Write("Get  companies from Google api completed successfully", "ApiMatch", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Get ucompanies from Google api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return apiResults;
        }
        /// <summary>
        /// Update company with sellected match
        /// </summary>
        /// <param name="match"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int UpdateCompanyByMatch(ApiMatchBE match, string userId)
        {
            int result = 0;
            try
            {
                XLTrace.StartMethodTrace();
                result = _empDAC.UpdateCompanayByGoogleMatch(match, userId);
                XLTrace.Write("Get  companies from Google api completed successfully", "ApiMatch", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Get ucompanies from Google api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return result;
        }

        /// <summary>
        /// Call google api and get company matches
        /// </summary>
        /// <param name="company"></param>
        /// <param name="country"></param>
        /// <returns></returns>
        private static string GetGoogleApiResult(string company, string location)
        {
            TextInfo myTI = new CultureInfo("en-US", false).TextInfo;
            company = myTI.ToTitleCase(company);
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(ConfigurationManager.AppSettings["GoogleApiUrl"]);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", ConfigurationManager.AppSettings["SubscriptionKey"]);
            string urlParameters = "?q=" + company.Replace("&", "and") + "&location=" + location + "&search_engine=google.com&hl=en&gl=us&num=20";//"+company+"&location="+country+"
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;
            string dataObjects = string.Empty;
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                dataObjects = response.Content.ReadAsStringAsync().Result;
            }
            // Dispose once all HttpClient calls are complete.
            client.Dispose();
            return dataObjects;
        }

        /// <summary>
        /// Processing Company Result
        /// </summary>
        /// <param name="apiMsg"></param>
        /// <returns></returns>
        private static List<GoogleApiResultBE> ProcessCompanyResult(string apiMsg)
        {
            var result = JObject.Parse(apiMsg);
            List<GoogleApiResultBE> apiResults = new List<GoogleApiResultBE>();
            if (result != null && result.Count > 0)
            {
                if (result["knowledge_graph"] != null)
                {
                    var knowledgeGraph = result["knowledge_graph"].First;
                    apiResults.Add(new GoogleApiResultBE
                    {
                        Title = knowledgeGraph["title"].ToString(),
                        Description = knowledgeGraph["description"] != null ? knowledgeGraph["description"].ToString()
                        : knowledgeGraph["one_line_summary"] != null ? knowledgeGraph["one_line_summary"].ToString() : string.Empty,
                        Website = knowledgeGraph["visit_official_site"] != null ? knowledgeGraph["visit_official_site"].ToString() :
                        knowledgeGraph["website"] != null ? knowledgeGraph["website"].ToString() : string.Empty,
                        Address = knowledgeGraph["address"] != null ? knowledgeGraph["address"].ToString() : string.Empty
                    });
                }
                if (result["organic"] != null)
                {
                    var organicNodes = result["organic"];
                    foreach (var item in organicNodes)
                    {
                        if (item["title"] == null)
                        {
                            continue;
                        }
                        apiResults.Add(new GoogleApiResultBE
                        {
                            Title = item["title"] != null ? item["title"].ToString() : string.Empty,
                            Description = item["description"] != null ? item["description"].ToString() : string.Empty,
                            Website = item["url"] != null ? item["url"].ToString() : string.Empty,
                            Address = string.Empty
                        });
                    }
                }
            }
            return apiResults;
        }


        public string GetRefreshExtractCon()
        {
            string refreshExtractCoquery = "";
            try
            {
                XLTrace.StartMethodTrace();
                List<RefreshExtractBE> Rextract= _empDAC.GetRefreshExtractCon(Constants.C_SYS_CONTSANTS_EXCEL_CONN_STRING);
                refreshExtractCoquery = Rextract[0].description;
                XLTrace.Write("Get  GetRefreshExtractCon from  api completed successfully", "RefreshExtract", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Get ucompanies from Google api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "RefreshExtract Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return refreshExtractCoquery;
        }
        public string GetFilePath()
        {
            string refreshExtractCoquery = "";
            try
            {
                XLTrace.StartMethodTrace();
                List<RefreshExtractBE> Rextract = _empDAC.GetFilePath();
                refreshExtractCoquery = Rextract[0].description;
                XLTrace.Write("Get  GetFilePath from  api completed successfully", "GetFilePath", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("GetFilePath api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "GetFilePath Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return refreshExtractCoquery;
        }
        public string GetUserProfile(string loginName)
        {
            string refreshExtractCoquery = "";
            try
            {
                XLTrace.StartMethodTrace();
                List<RefreshExtractBE> Rextract = _empDAC.GetUserProfile(loginName);
                refreshExtractCoquery = Rextract[0].description;
                XLTrace.Write("Get  GetFilePath from  api completed successfully", "GetFilePath", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("GetFilePath api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "GetFilePath Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return refreshExtractCoquery;
        }
        public string GetConnectionString()
        {
            string refreshExtractCoquery = "";
            try
            {
                XLTrace.StartMethodTrace();
                refreshExtractCoquery = _empDAC.GetConnectionString();
                XLTrace.Write("Get  GetFilePath from  api completed successfully", "GetFilePath", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("GetFilePath api is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "GetFilePath Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return refreshExtractCoquery;
        }
        /// <summary>
        /// Processing Country Result
        /// </summary>
        /// <param name="countryResult"></param>
        /// <returns></returns>
        private static Dictionary<string, string> ProcessApiCountryResult(string countryResult)
        {
            Dictionary<string, string> dicTitles = new Dictionary<string, string>();
            var result = JObject.Parse(countryResult);
            if (result != null && result.Count > 0)
            {
                if (result["knowledge_graph"] != null)
                {
                    var knowledgeGraph = result["knowledge_graph"].First;
                    string subtitle;
                    //matchedCompany = knowledgeGraph["title"].ToString();
                    if (knowledgeGraph["title"] != null)
                    {
                        if (knowledgeGraph["subtitle"] != null)
                        {
                            subtitle = knowledgeGraph["subtitle"].ToString();
                        }
                        else
                        {
                            subtitle = knowledgeGraph["title"].ToString();
                        }
                        dicTitles.Add(knowledgeGraph["title"].ToString(), subtitle);



                    }
                }
            }
            return dicTitles;
        }
        #endregion

        #region Upload File

        /// <summary>
        /// Get Duplicate File
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="filetype"></param>
        /// <returns></returns>
        public List<DocumentBE> GetDuplicateDocuments(string filename, int filetype)
        {
            List<DocumentBE> lstFiles = new List<DocumentBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                lstFiles = _empDAC.GetDuplicateFiles<DocumentBE>(filename, filetype);
                XLTrace.Write("Retrieved all duplicate documents", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieved all duplicate documents Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return lstFiles;
        }
        #endregion

        #region ReferenceTableMaintenance

        /// <summary>
        /// Save Country Lookup Data
        /// </summary>
        /// <param name="countrylookupData"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>
        public bool SaveCountryLookupTableData(DataTable countrylookupData, string aLoginUserId)
        {
            try
            {
                XLTrace.StartMethodTrace();
                int refVersion = _empDAC.GetCountryLokkupVersionNumber();
                List<XPOCountryLookupBE> rmsConvertedDataBE = (from DataRow dr in countrylookupData.Rows
                                                               select new XPOCountryLookupBE()
                                                               {
                                                                   AddedApp = "XPO",
                                                                   AddedBy = aLoginUserId,
                                                                   AddedDt = DateTime.Now,
                                                                   location = Convert.ToString(dr["Location"]).Trim().ToUpper(),
                                                                   mapped_country = Convert.ToString(dr["MappedCountry"]).Trim().ToUpper(),
                                                                   ModifyApp = "XPO",
                                                                   ModifyBy = aLoginUserId,
                                                                   ModifyDt = DateTime.Now,
                                                                   ref_version = refVersion,
                                                                   validated_date = Convert.ToDateTime(dr["ValidatedDate"], CultureInfo.InvariantCulture),
                                                                   Version = 1

                                                               }).ToList();
                _empDAC.BulkInsertConvertedReference(rmsConvertedDataBE);
                _empDAC.ClearManualEntries("country");
                XLTrace.Write("Saved Reference Table  Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Reference Table Converted Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        /// <summary>
        /// Save Casualty Comapny Lookup Data
        /// </summary>
        /// <param name="companyLookupData"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>
        public bool SaveCasualtyCompanyLookupTableData(DataTable companyLookupData, string aLoginUserId)
        {

            try
            {
                XLTrace.StartMethodTrace();
                int refVersion = _empDAC.GetInsCompVersionNumber();
                List<XPOCasultyCompanyLookupBE> rmsConvertedDataBE = (from DataRow dr in companyLookupData.Rows
                                                                          //where !string.IsNullOrWhiteSpace(Convert.ToString(dr["Country"]))
                                                                      select new XPOCasultyCompanyLookupBE()
                                                                      {
                                                                          AddedApp = "XPO",
                                                                          AddedBy = aLoginUserId,
                                                                          AddedDt = DateTime.Now,
                                                                          original_name = Convert.ToString(dr["Insured"]).Trim().ToUpper(),
                                                                          original_country = Convert.ToString(dr["Country"]).Trim().ToUpper(),
                                                                          ModifyApp = "XPO",
                                                                          ModifyBy = aLoginUserId,
                                                                          ModifyDt = DateTime.Now,
                                                                          ref_version = refVersion,
                                                                          validation_date = Convert.ToDateTime(dr["ValidationDate"], CultureInfo.InvariantCulture),
                                                                          Version = 1,
                                                                          conformed_country = Convert.ToString(dr["ConformCountry"]).Trim().ToUpper(),
                                                                          conformed_industry = Convert.ToString(dr["ConformIndustry"]).Trim().ToUpper(),
                                                                          employee_count = Convert.ToInt32(dr["EmployeeCount"]),
                                                                          original_industry = Convert.ToString(dr["Industry"]).Trim().ToUpper(),
                                                                          reference_id = Convert.ToString(dr["ReferenceID"]),
                                                                          revenue = Convert.ToDouble(dr["Revenue"]),
                                                                          saved_name = Convert.ToString(dr["SavedName"]).Trim().ToUpper()
                                                                      }).ToList();
                _empDAC.BulkInsertCasualtyCompanyRef(rmsConvertedDataBE);
                _empDAC.ClearManualEntries("name");
                XLTrace.Write("Saved Reference Table  Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Reference Table Converted Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        /// <summary>
        /// Save Marine Comapny Lookup Data
        /// </summary>
        /// <param name="marineLookupData"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>
        public bool SaveMarineLookupTableData(DataTable marineLookupData, string aLoginUserId)
        {

            try
            {
                XLTrace.StartMethodTrace();
                int refVersion = _empDAC.GetMarineVersionNumber();
                List<XPOMarineLookupBE> rmsConvertedDataBE = (from DataRow dr in marineLookupData.Rows
                                                              select new XPOMarineLookupBE()
                                                              {
                                                                  AddedApp = "XPO",
                                                                  AddedBy = aLoginUserId,
                                                                  AddedDt = DateTime.Now,
                                                                  ModifyApp = "XPO",
                                                                  ModifyBy = aLoginUserId,
                                                                  ModifyDt = DateTime.Now,
                                                                  Version = 1,
                                                                  Area = Convert.ToString(dr["Area"]).Trim().ToUpper(),
                                                                  AssetInstallationYear = Convert.ToString(dr["InstalationYear"]),
                                                                  AssetSubtype = Convert.ToString(dr["SubType"]).Trim().ToUpper(),
                                                                  AssetType = Convert.ToString(dr["Type"]).Trim().ToUpper(),
                                                                  ClarksonId = Convert.ToString(dr["ClarksonId"]),
                                                                  Complex = Convert.ToString(dr["Complex"]).Trim().ToUpper(),
                                                                  Field = Convert.ToString(dr["Field"]).Trim().ToUpper(),
                                                                  GroupInstallation = Convert.ToString(dr["GroupInstallation"]).Trim().ToUpper(),
                                                                  IdSource = Convert.ToString(dr["Source"]).Trim().ToUpper(),
                                                                  ImoNumber = GetLongValue(dr["Imo"]),
                                                                  Latitude = Convert.ToString(dr["Latitude"]),
                                                                  Longitude = Convert.ToString(dr["Longitude"]),
                                                                  MatchName = Convert.ToString(dr["MatchName"]).Trim().ToUpper(),
                                                                  MmsiNumber = GetLongValue(dr["Mmsi"]),
                                                                  ObjectId = GetLongValue(dr["ObjectId"]),
                                                                  Platform = Convert.ToString(dr["Platform"]).Trim().ToUpper(),
                                                                  RefVersion = refVersion,
                                                                  WaterDepth = GetDoubleValue(dr["WaterDepth"]),
                                                                  EpmType = Convert.ToString(dr["EpmType"])
                                                              }).ToList();
                _empDAC.BulkInsertMarineRef(rmsConvertedDataBE);
                XLTrace.Write("Saved Reference Table  Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Reference Table Converted Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        /// <summary>
        /// Save Industry Lookup Data
        /// </summary>
        /// <param name="industryLookupData"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>
        public bool SaveIndustryLookupTableData(DataTable industryLookupData, string aLoginUserId)
        {

            try
            {
                XLTrace.StartMethodTrace();
                int refVersion = _empDAC.GetIndustryLookupVersionNumber();
                List<XPOIndustryLookupBE> rmsConvertedDataBE = (from DataRow dr in industryLookupData.Rows
                                                                select new XPOIndustryLookupBE()
                                                                {
                                                                    AddedApp = "XPO",
                                                                    AddedBy = aLoginUserId,
                                                                    AddedDt = DateTime.Now,
                                                                    industry = Convert.ToString(dr["Industry"]).Trim().ToUpper(),
                                                                    mapped_industry = Convert.ToString(dr["MappedIndustry"]).Trim().ToUpper(),
                                                                    ModifyApp = "XPO",
                                                                    ModifyBy = aLoginUserId,
                                                                    ModifyDt = DateTime.Now,
                                                                    ref_version = refVersion,
                                                                    validated_date = Convert.ToDateTime(dr["ValidatedDate"], CultureInfo.InvariantCulture),
                                                                    Version = 1
                                                                }).ToList();
                _empDAC.BulkInsertIndustryRef(rmsConvertedDataBE);
                _empDAC.ClearManualEntries("industry");
                XLTrace.Write("Saved Reference Table  Converted Column Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);

            }
            catch (Exception ex)
            {
                XLTrace.Write("Saving Reference Table Converted Column Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return true;
        }

        /// <summary>
        /// Get Excel Files
        /// </summary>
        /// <param name="filetype"></param>
        /// <returns></returns>
        public List<DocumentBE> GetexcelFilesbyLOB(int filetype)
        {
            List<DocumentBE> lstFiles = new List<DocumentBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                lstFiles = _empDAC.GetexcelFilesbyLOB<DocumentBE>(filetype);
                XLTrace.Write("Retrieved all duplicate documents", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieved all duplicate documents Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return lstFiles;
        }

        /// <summary>
        /// Perform Reference Data AutoMatch
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>

        public int PerformRefAutomatch(int fileProcessingTaskGuid, string aLoginUserId)
        {
            int status = -1;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                status = _empDAC.PerformRefAutomatch(fileProcessingTaskGuid, aLoginUserId);
                status = _empDAC.GetNameMatchStatus(fileProcessingTaskGuid);
                XLTrace.Write("Update is completed successfully", "RefAutomatch", System.Diagnostics.TraceEventType.Information, fileProcessingTaskGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Update is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "Update Error", System.Diagnostics.TraceEventType.Error, fileProcessingTaskGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return status;
        }

        #region private methods

        private double? GetDoubleValue(object val)
        {
            double resturnVal;
            if (val == DBNull.Value || Convert.ToString(val).Equals("NA", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }
            else if (double.TryParse(Convert.ToString(val), out resturnVal))
            {
                return Convert.ToDouble(val);
            }
            else
            {
                return null;
            }
        }

        private static long? GetLongValue(object val)
        {
            long resturnVal;
            if (val == DBNull.Value || Convert.ToString(val).Equals("NA", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }
            else if (long.TryParse(Convert.ToString(val), out resturnVal))
            {
                return Convert.ToInt64(val);
            }
            else
            {
                return null;
            }
        }
        #endregion

        /// <summary>
        /// Saving Referencedocument Data
        /// </summary>
        /// <param name="docBE"></param>
        /// <returns></returns>

        public void SaveReferenceDoc(ReferenceDocBE docBE)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                docBE.ChangedStatus = EntityStatus.StatusInsert;
                docBE = SaveBusinessEntity((ReferenceDocBE)docBE);
                XLTrace.Write("Stage-1 : Reference File Uploaded Successfully", Constants.C_LOGGING_USER_ACTIVITY);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage-1 : Reference File Upload Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Saving VoiceContent Data
        /// </summary>
        /// <param name="vContent"></param>
        /// <param name="aLoginUserId"></param>
        /// <returns></returns>
        public int SaveVoiceContentReport(string vContent, string aLoginUserId)
        {
            int status = -1;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                //status = _empDAC.SaveVoiceContentReport(vContent, aLoginUserId);
                XLTrace.Write("Update is completed successfully", "RefAutomatch", System.Diagnostics.TraceEventType.Information, vContent);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Update is failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "Update Error", System.Diagnostics.TraceEventType.Error, vContent);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return status;
        }
        #endregion

        /// <summary>
        /// Saving LookupTables Data
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="LoginUserId"></param>
        /// <param name="dtExcelContent"></param>
        /// <returns></returns>

        public void SaveLookupTableData(string tableName, string LoginUserId, DataTable dtExcelContent)
        {
            switch (tableName)
            {
                case Constants.Country_Lookup:
                    this.SaveCountryLookupTableData(dtExcelContent, LoginUserId);
                    break;
                case Constants.Casualty_Company_Lookup:
                    this.SaveCasualtyCompanyLookupTableData(dtExcelContent, LoginUserId);
                    break;
                case Constants.Industry_Lookup:
                    this.SaveIndustryLookupTableData(dtExcelContent, LoginUserId);
                    break;
                default:
                    this.SaveMarineLookupTableData(dtExcelContent, LoginUserId);
                    break;
            }
        }


        /// <summary>
        /// Get UnMatching Data For Inprogress screen
        /// </summary>
        /// <param name="mastertype"></param>
        /// <param name="assetName"></param>
        /// <param name="ExcludeSpecialCharsChecked"></param>
        /// <returns></returns>
        public List<UnMatchDataBE> GetUnMatchData(string mastertype, string assetName, string ExcludeSpecialCharsChecked)
        {
            List<UnMatchDataBE> unMatchData = new List<UnMatchDataBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                if (mastertype == "name" && !string.IsNullOrWhiteSpace(assetName) && ExcludeSpecialCharsChecked == "1")
                {
                    assetName = RemoveSpecialChars(assetName);
                }
                unMatchData = _empDAC.GetUnMatchData(mastertype, assetName);
                XLTrace.Write("Retrieved all document detail pending for name match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all document detail pending for name match Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return unMatchData;
        }

        /// <summary>
        /// Get Matching Data For Inprogress screen
        /// </summary>
        /// <param name="mastertype"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public List<MatchDataBE> GetMatchData(string mastertype, string name, int isFindmatchesVisible)
        {
            List<MatchDataBE> matchData = new List<MatchDataBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                var matchDataList = _empDAC.GetMatchData(mastertype);
                if (!string.IsNullOrWhiteSpace(name))
                {
                    matchData = (from item in matchDataList
                                 select new MatchDataBE()
                                 {
                                     Original = item.Original,
                                     Mapped = item.Mapped,
                                     original_country = item.original_country,
                                     original_industry = item.original_industry,
                                     drillcountry = item.drillcountry,
                                     conformed_country = item.conformed_country,
                                     Distance = Distance(name.ToString().ToUpper(), item.Original.ToString().ToUpper()),
                                     MatchId = item.MatchId
                                 }).OrderBy(y => y.Distance).Distinct().ToList();
                    matchData = matchData.GroupBy(x => x.Mapped).Select(x => x.FirstOrDefault()).ToList();
                    if (isFindmatchesVisible == 0)
                        matchData = matchData.Take(10).ToList();
                }
                XLTrace.Write("Retrieved all document detail pending for name match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all document detail pending for name match Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return matchData;
        }
        /// <summary>
        /// Update Insurance Stage with selected match
        /// </summary>
        /// <param name="match"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int UpdateMatchData(RefDataMatchBE match, string userId)
        {
            int updateMatchDataresult = 0;
            try
            {
                XLTrace.StartMethodTrace();
                updateMatchDataresult = _empDAC.UpdateMatchData(match, userId);
                XLTrace.Write("Saved successfully", "RefDataMatch", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Mapping failed. Please check and retry. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return updateMatchDataresult;
        }

        /// <summary>
        /// Override Files Data in RefdataUpload
        /// </summary>
        /// <param name="fileProcessingTaskGuid"></param>
        /// <returns></returns>

        public bool OverrideFilesData(int fileProcessingTaskGuid)
        {
            bool IsOverride = false;
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                IsOverride = _empDAC.OverrideFilesData(fileProcessingTaskGuid);

                XLTrace.Write("Stage - 4 : Override file Data Successfully", Constants.C_LOGGING_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information, fileProcessingTaskGuid);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Stage - 4 : Override file Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_SOV_ERROR, System.Diagnostics.TraceEventType.Error, _programGuid, _programFileGuid);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return IsOverride;
        }

        /// <summary>
        /// Get Refdata data
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>        
        public byte[] GetRefData(string tableName)
        {
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                string sheetName = string.Empty;
                var dtFinal = _empDAC.GetRefData(tableName);
                DataSet ds = new DataSet();
                ds.Tables.Add(dtFinal);
                switch (tableName)
                {
                    case Constants.Casualty_Company_Lookup:
                        sheetName = Constants.Company_Master;
                        break;
                    case Constants.Marine_Lookup:
                        sheetName = Constants.Marine_Company_Master;
                        break;
                    case Constants.Country_Lookup:
                        sheetName = Constants.Country_Master;
                        break;
                    case Constants.Industry_Lookup:
                        sheetName = Constants.Industry_Master;
                        break;

                }
                return ExportDSToExcel(ds, "", sheetName);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving Ref Data Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
        }

        /// <summary>
        /// Get Distnace Of Two Strings
        /// </summary>
        /// <param name="argItem1"></param>
        /// <param name="argItem2"></param>
        /// <returns></returns>   

        public static int Distance<T>(IEnumerable<T> argItem1, IEnumerable<T> argItem2)
            where T : IEquatable<T>
        {
            if (argItem1 == null) throw new ArgumentNullException("x");
            if (argItem2 == null) throw new ArgumentNullException("y");

            IList<T> m_FirstList = argItem1 as IList<T> ?? new List<T>(argItem1);
            IList<T> m_SecondList = argItem2 as IList<T> ?? new List<T>(argItem2);

            int m_FirstCount = m_FirstList.Count, m_SecondCount = m_SecondList.Count;
            if (m_FirstCount == 0) return m_SecondCount;
            if (m_SecondCount == 0) return m_FirstCount;

            int m_curentRow = 0, m_NextRow = 1;
            int[][] rows = new int[][] { new int[m_SecondCount + 1], new int[m_SecondCount + 1] };
            for (int j = 0; j <= m_SecondCount; ++j) rows[m_curentRow][j] = j;

            for (int i = 1; i <= m_FirstCount; ++i)
            {
                rows[m_NextRow][0] = i;
                for (int j = 1; j <= m_SecondCount; ++j)
                {
                    int dist1 = rows[m_curentRow][j] + 1;
                    int dist2 = rows[m_NextRow][j - 1] + 1;
                    int dist3 = rows[m_curentRow][j - 1] + (m_FirstList[i - 1].Equals(m_SecondList[j - 1]) ? 0 : 1);

                    rows[m_NextRow][j] = Math.Min(dist1, Math.Min(dist2, dist3));
                }
                if (m_curentRow == 0)
                {
                    m_curentRow = 1;
                    m_NextRow = 0;
                }
                else
                {
                    m_curentRow = 0;
                    m_NextRow = 1;
                }
            }
            return rows[m_curentRow][m_SecondCount];
        }


        /// <summary>
        /// Get TowerMatch Data 
        /// </summary>
        /// <param name="filetype"></param>
        /// <param name="coverage"></param>
        /// <param name="assetname"></param>
        /// <param name="savedName"></param>
        /// <param name="ExcludeSpecialCharsChecked"></param>
        /// <returns></returns>   

        public List<TowerMatchBE> GetTowerUnMatchData(string filetype, string coverage, string assetname, string savedName, string ExcludeSpecialCharsChecked)
        {
            List<TowerMatchBE> towerMatchList = new List<TowerMatchBE>();
            try
            {
                XLTrace.StartMethodTrace();
                if (filetype == "1" && !string.IsNullOrWhiteSpace(assetname) && ExcludeSpecialCharsChecked == "1")
                {
                    assetname = RemoveSpecialChars(assetname);
                }
                towerMatchList = _empDAC.GetTowerUnMatchData(filetype, coverage, assetname, savedName);
                XLTrace.Write("Retrieved all Tower Match Data", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Mapping failed. Please check and retry. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return towerMatchList;
        }

        /// <summary>
        /// UpdateTowerMatch Data
        /// </summary>
        /// <param name="fpGuids"></param>
        /// <param name="userid"></param>
        /// <returns></returns>

        public bool UpdateTowerMatchData(string fpGuids, string userid)
        {
            bool utowerMatchstatus = false;
            try
            {
                XLTrace.StartMethodTrace();
                utowerMatchstatus = _empDAC.UpdateTowerMatchData(fpGuids, userid);
                XLTrace.Write("Retrieved all Tower Match Data", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Mapping failed. Please check and retry. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return utowerMatchstatus;
        }

        /// <summary>
        /// Get TowerMatch Asset Names
        /// </summary>
        /// <returns></returns>

        public List<AssetNamesBE> GetTowerMatchAssetNames()
        {
            List<AssetNamesBE> assetNames = new List<AssetNamesBE>();
            try
            {
                XLTrace.StartMethodTrace();
                assetNames = _empDAC.GetTowerMatchAssetNames();
                XLTrace.Write("Retrieved all Distinct Asset Names", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Getting Asset Names failed. Please check and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "Getting AssetNames Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return assetNames;
        }

        /// <summary>
        /// Get Coverage
        /// </summary>
        /// <returns></returns>

        public List<CoverageBE> GetCoverage()
        {
            List<CoverageBE> coverages = new List<CoverageBE>();
            try
            {
                XLTrace.StartMethodTrace();
                coverages = _empDAC.GetCoverage();
                XLTrace.Write("Retrieved all Distinct coverages", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Getting coverages failed. Please check and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "Getting AssetNames Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return coverages;
        }

        /// <summary>
        /// UpdateTowerMatch
        /// </summary>
        /// <param name="savedName"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>
        /// 
        public bool UpdateTowerMatch(string savedName, string UserId)
        {
            
            //Array.Find(TowerMatchUsers,
            //           element => element.Equals(UserId,
            //           StringComparison.Ordinal));
            List<CoverageBE> coverages = new List<CoverageBE>();
            bool tProcess = false;
            coverages = _empDAC.GetTCoverage();
            foreach (var cov in coverages)
            {
                tProcess = TowerMatchProcByCov(cov.Coverage.ToString());

            }
            return tProcess;
        }
        //UpdateTowerMatch11(string savedName,string UserId)
        //TowerMatchProcByCov
        public bool TowerMatchProcByCov(string Cov)
        {
            bool utowerMatchstatus = false;
            try
            {
                XLTrace.StartMethodTrace();


                /// Start TowerMatch code ///
                /// 
                List<MainStage> t_xpo_tm_interim = new List<MainStage>();
                List<MainStage> t_xpo_tm_final = new List<MainStage>();
                List<MainStage> tmm2 = new List<MainStage>();
                int runcycle = 0;
                int rowstoprocess = 0;
                int rowcount = 0;
                int nextrowid;

                while (runcycle == 0 || rowstoprocess > 0)
                {

                    List<SubStage> tm4 = new List<SubStage>();
                    List<PrevTable> prevtable = new List<PrevTable>();
                    List<SubStage> tm5 = new List<SubStage>();
                    List<SubStage> tm6 = new List<SubStage>();
                    List<PrevTable> BatchPrevTable = new List<PrevTable>();
                    if (runcycle == 0)
                    {
                        tm4 = _empDAC.GetdatabyCoverage(Cov);
                        prevtable = _empDAC.spu_GetPrevTable();

                    }
                    else
                    {
                        //  If run Cycle =1 or increament  //

                        tm4 = _empDAC.GetNexcycleData(runcycle);
                        prevtable = _empDAC.spu_GetPrevTable();


                    }



                    //  need to apply order by savename and riskcount?//
                    int Crowcount = tm4.Count();
                    int loopsize = 6000;
                    int currentloop = 1;
                    int loopCount = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(Crowcount) / loopsize));
                    int Crowid = 0;

                    string p_saved_name = "";
                    double plimit = 0;
                    double pat = 0;
                    string p_filename = "";
                    double prevsum = 0;

                    while (currentloop <= loopCount)
                    {
                        int srowid = Crowid + 1;
                        int Erowid = Crowid + loopsize;


                        // Create current loop table  

                        tm5 = (from c in tm4
                               where c.id >= srowid && c.id <= Erowid
                               select new SubStage()
                               {
                                   id = c.id,
                                   emt_insurance_guid = c.emt_insurance_guid,
                                   NAMEDINSURED = c.NAMEDINSURED,
                                   saved_name = c.saved_name,
                                   COVERAGE = c.COVERAGE,
                                   LIMIT = c.LIMIT,
                                   ATTACHMENTPOINT = c.ATTACHMENTPOINT,
                                   limit_USD = c.limit_USD,
                                   AT_USD = c.AT_USD,
                                   SHARE = c.SHARE,
                                   CURRENCY = c.CURRENCY,
                                   tower_id = "0",
                                   file_name = c.file_name,
                                   risk_count = c.risk_count,
                                   primary_ind = c.primary_ind,
                                   primary_TM = c.primary_TM,
                                   nonprimary_TM = c.nonprimary_TM,
                                   final_TM = c.final_TM
                               }).ToList();
                        BatchPrevTable = (from c in prevtable
                                          where c.id >= srowid-1 && c.id <= Erowid
                                          select new PrevTable()
                                          {
                                              id = c.id,
                                              prev_at = c.prev_at,
                                              prev_filename = c.prev_filename,
                                              prev_limit = c.prev_limit,
                                              prev_savedname = c.prev_savedname,
                                              next_id = c.next_id,
                                              prev_sum = c.prev_sum


                                          }).ToList();



                        //core logic//
                        int rowid = Crowid + 1;
                        int J = Crowid + 1;

                        rowstoprocess = 0;
                        //List<LoopTable> loopTable = new List<LoopTable>();
                        rowcount = Crowid + tm5.Count();

                        //foreach( var b in tm4 )
                        while (J <= rowcount)
                        {
                            var getprevtable = BatchPrevTable.FirstOrDefault(x => x.id == rowid);

                            p_saved_name = getprevtable.prev_savedname;
                            plimit = getprevtable.prev_limit;
                            pat = getprevtable.prev_at;
                            p_filename = getprevtable.prev_filename;
                            prevsum = getprevtable.prev_sum;

                            var oneRowTable = tm5.Where(c => c.id == rowid)
                                .Select(c => new
                                {
                                    c.id,
                                    c.emt_insurance_guid,
                                    c.NAMEDINSURED,
                                    c.saved_name,
                                    c.COVERAGE,
                                    c.LIMIT,
                                    c.ATTACHMENTPOINT,
                                    c.limit_USD,
                                    c.AT_USD,
                                    c.SHARE,
                                    c.CURRENCY,
                                    c.tower_id,
                                    c.file_name,
                                    c.risk_count,
                                    c.primary_ind,
                                    c.primary_TM,
                                    c.nonprimary_TM,
                                    c.final_TM


                                }).ToList();

                            oneRowTable = oneRowTable
                                .Select(c => new
                                {
                                    c.id,
                                    c.emt_insurance_guid,
                                    c.NAMEDINSURED,
                                    c.saved_name,
                                    c.COVERAGE,
                                    c.LIMIT,
                                    c.ATTACHMENTPOINT,
                                    c.limit_USD,
                                    c.AT_USD,
                                    c.SHARE,
                                    c.CURRENCY,
                                    c.tower_id,
                                    c.file_name,
                                    c.risk_count,
                                    c.primary_ind,
                                    primary_TM = c.risk_count == 0 ? "0" : (c.AT_USD == 0 && c.saved_name == p_saved_name && c.AT_USD == pat && c.limit_USD == plimit && c.file_name != p_filename) ? "0" : "next cycle",
                                    nonprimary_TM = c.risk_count == 0 ? "0" : (c.AT_USD >= prevsum) ? "0" : (c.AT_USD == pat && c.limit_USD == plimit) ? "0" : "next cycle",
                                    c.final_TM


                                }).ToList();

                            oneRowTable = oneRowTable
                                .Select(c => new
                                {
                                    c.id,
                                    c.emt_insurance_guid,
                                    c.NAMEDINSURED,
                                    c.saved_name,
                                    c.COVERAGE,
                                    c.LIMIT,
                                    c.ATTACHMENTPOINT,
                                    c.limit_USD,
                                    c.AT_USD,
                                    c.SHARE,
                                    c.CURRENCY,
                                    c.tower_id,
                                    c.file_name,
                                    c.risk_count,
                                    c.primary_ind,
                                    c.primary_TM,
                                    c.nonprimary_TM,
                                    final_TM = c.primary_ind == "primary" ? c.primary_TM : c.nonprimary_TM,


                                }).ToList();


                            //tm4.First(c => c.id == rowid).primary_TM = (tm4.First(c => c.id == rowid).risk_count == 0) ? "0" : (tm4.First(c => c.id == rowid).AT_USD == 0 && tm4.First(c => c.id == rowid).saved_name == p_saved_name && tm4.First(c => c.id == rowid).AT_USD == pat && tm4.First(c => c.id == rowid).limit_USD == plimit && tm4.First(c => c.id == rowid).file_name != p_filename) ? "0" : "next cycle";
                            //tm4.First(c => c.id == rowid).nonprimary_TM = (tm4.First(c => c.id == rowid).risk_count == 0) ? "0" : (tm4.First(c => c.id == rowid).AT_USD >= prevsum) ? "0" : (tm4.First(c => c.id == rowid).AT_USD == pat && tm4.First(c => c.id == rowid).limit_USD == plimit) ? "0" : "next cycle";

                            //tm4.First(c => c.id == rowid).final_TM = (tm4.First(c => c.id == rowid).primary_ind == "primary") ? tm4.First(c => c.id == rowid).primary_TM : tm4.First(c => c.id == rowid).nonprimary_TM;


                            int next = 0;

                            var counttable = oneRowTable.Where(i => i.final_TM == "next cycle" && i.id == rowid)
                                .Select(c => new
                                {

                                    c.id,
                                    c.emt_insurance_guid,
                                    c.NAMEDINSURED,
                                    c.saved_name,
                                    c.COVERAGE,
                                    c.LIMIT,
                                    c.ATTACHMENTPOINT,
                                    c.limit_USD,
                                    c.AT_USD,
                                    c.SHARE,
                                    c.CURRENCY,
                                    c.tower_id,
                                    c.file_name,
                                    c.risk_count,
                                    c.primary_ind,
                                    c.primary_TM,
                                    c.nonprimary_TM,
                                    c.final_TM

                                }).ToList();

                            next = counttable.Count();

                            if (next == 1)
                            {


                                try
                                {
                                    nextrowid = getprevtable.next_id;

                                    if (rowid ==Erowid)
                                    {
                                        // we need update maintable with c.id
                                        prevtable.First(c => c.id == nextrowid).prev_at = pat;
                                        prevtable.First(c => c.id == nextrowid).prev_filename = p_filename;
                                        prevtable.First(c => c.id == nextrowid).prev_limit = plimit;
                                        prevtable.First(c => c.id == nextrowid).prev_savedname = p_saved_name;
                                        prevtable.First(c => c.id == nextrowid).prev_sum = prevsum;
                                    }
                                    else
                                    {

                                        BatchPrevTable.First(c => c.id == nextrowid).prev_at = pat;
                                        BatchPrevTable.First(c => c.id == nextrowid).prev_filename = p_filename;
                                        BatchPrevTable.First(c => c.id == nextrowid).prev_limit = plimit;
                                        BatchPrevTable.First(c => c.id == nextrowid).prev_savedname = p_saved_name;
                                        BatchPrevTable.First(c => c.id == nextrowid).prev_sum = prevsum;
                                    }
                                    //nextrowid = getprevtable.next_id;
                                    // Update prev Table ///
                                    //prevtable.First(c => c.id == nextrowid).prev_at = (prevtable.First(c => c.id == nextrowid).id == nextrowid) ? pat : prevtable.First(c => c.id == nextrowid).prev_at;
                                    //prevtable.First(c => c.id == nextrowid).prev_filename = (prevtable.First(c => c.id == nextrowid).id == nextrowid) ? p_filename : prevtable.First(c => c.id == nextrowid).prev_filename;
                                    //prevtable.First(c => c.id == nextrowid).prev_limit = (prevtable.First(c => c.id == nextrowid).id == nextrowid) ? plimit : prevtable.First(c => c.id == nextrowid).prev_limit;
                                    //prevtable.First(c => c.id == nextrowid).prev_savedname = (prevtable.First(c => c.id == nextrowid).id == nextrowid) ? p_saved_name : prevtable.First(c => c.id == nextrowid).prev_savedname;
                                    //prevtable.First(c => c.id == nextrowid).prev_sum = (prevtable.First(c => c.id == nextrowid).id == nextrowid) ? prevsum : prevtable.First(c => c.id == nextrowid).prev_sum;


                                    //prevtable.First(c => c.id == nextrowid).next_id = nextrowid;


                                }
                                catch (Exception ex)
                                {

                                }



                            }

                            var getTM = oneRowTable.FirstOrDefault(x => x.id == rowid);

                            string primary_TM = getTM.primary_TM;
                            string nonprimary_TM = getTM.nonprimary_TM;
                            string final_TM = getTM.final_TM;
                            SubStage newrow = new SubStage();
                            newrow.id = getTM.id;
                            newrow.emt_insurance_guid = getTM.emt_insurance_guid;
                            newrow.NAMEDINSURED = getTM.NAMEDINSURED;
                            newrow.saved_name = getTM.saved_name;
                            newrow.COVERAGE = getTM.COVERAGE;
                            newrow.LIMIT = getTM.LIMIT;
                            newrow.ATTACHMENTPOINT = getTM.ATTACHMENTPOINT;
                            newrow.limit_USD = getTM.limit_USD;
                            newrow.AT_USD = getTM.AT_USD;
                            newrow.SHARE = getTM.SHARE;
                            newrow.CURRENCY = getTM.CURRENCY;
                            newrow.tower_id = getTM.tower_id;
                            newrow.file_name = getTM.file_name;
                            newrow.risk_count = getTM.risk_count;
                            newrow.primary_ind = getTM.primary_ind;
                            newrow.primary_TM = getTM.primary_TM;
                            newrow.nonprimary_TM = getTM.nonprimary_TM;
                            newrow.final_TM = getTM.final_TM;

                            tm6.Add(newrow);

                            //tm4.First(c => c.id == rowid).primary_TM = primary_TM;
                            //tm4.First(c => c.id == rowid).nonprimary_TM = nonprimary_TM;

                            //tm4.First(c => c.id == rowid).final_TM = final_TM;



                            J++;
                            rowid++;

                        }


                        currentloop++;
                        Crowid = rowid - 1;


                    }




                    t_xpo_tm_interim = (from item in tm6
                                        where item.final_TM == "next cycle"
                                        select new MainStage()
                                        {
                                            id = item.id,
                                            emt_insurance_guid = item.emt_insurance_guid,
                                            NAMEDINSURED = item.NAMEDINSURED,
                                            saved_name = item.saved_name,
                                            COVERAGE = item.COVERAGE,
                                            LIMIT = item.LIMIT,
                                            ATTACHMENTPOINT = item.ATTACHMENTPOINT,
                                            limit_USD = item.limit_USD,
                                            AT_USD = item.AT_USD,
                                            SHARE = item.SHARE,
                                            CURRENCY = item.CURRENCY,
                                            tower_id = item.tower_id,
                                            file_name = item.file_name,
                                            risk_count = item.risk_count,
                                            primary_ind = item.primary_ind,
                                            p_saved_name = p_saved_name,
                                            plimit = plimit,
                                            pat = pat,
                                            p_filename = p_filename,
                                            prevsum = prevsum,
                                            primary_TM = item.primary_TM,
                                            nonprimary_TM = item.nonprimary_TM,
                                            final_TM = item.final_TM,
                                        }).ToList();


                    _empDAC.BulkInsertTowerMatchNexcycle(t_xpo_tm_interim);
                    // Preparing next cycle 
                    // update run cycle for final_TM in tm4//
                    tm6 = (from c in tm6
                           where c.final_TM != "next cycle"
                           select new SubStage()
                           {
                               id = c.id,
                               emt_insurance_guid = c.emt_insurance_guid,
                               NAMEDINSURED = c.NAMEDINSURED,
                               saved_name = c.saved_name,
                               COVERAGE = c.COVERAGE,
                               LIMIT = c.LIMIT,
                               ATTACHMENTPOINT = c.ATTACHMENTPOINT,
                               limit_USD = c.limit_USD,
                               AT_USD = c.AT_USD,
                               SHARE = c.SHARE,
                               CURRENCY = c.CURRENCY,
                               tower_id = "0",
                               file_name = c.file_name,
                               risk_count = c.risk_count,
                               primary_ind = c.primary_ind,
                               primary_TM = c.primary_TM,
                               nonprimary_TM = c.nonprimary_TM,
                               final_TM = c.final_TM
                           }).ToList();


                    tm6 = (from c in tm6
                           select new SubStage()
                           {
                               id = c.id,
                               emt_insurance_guid = c.emt_insurance_guid,
                               NAMEDINSURED = c.NAMEDINSURED,
                               saved_name = c.saved_name,
                               COVERAGE = c.COVERAGE,
                               LIMIT = c.LIMIT,
                               ATTACHMENTPOINT = c.ATTACHMENTPOINT,
                               limit_USD = c.limit_USD,
                               AT_USD = c.AT_USD,
                               SHARE = c.SHARE,
                               CURRENCY = c.CURRENCY,
                               tower_id = c.tower_id,
                               file_name = c.file_name,
                               risk_count = c.risk_count,
                               primary_ind = c.primary_ind,
                               primary_TM = c.primary_TM,
                               nonprimary_TM = c.nonprimary_TM,
                               final_TM = runcycle.ToString()
                           }).ToList();


                    // Insert into final table from tm4 //

                    t_xpo_tm_final = (from item in tm6
                                      select new MainStage()
                                      {
                                          id = item.id,
                                          emt_insurance_guid = item.emt_insurance_guid,
                                          NAMEDINSURED = item.NAMEDINSURED,
                                          saved_name = item.saved_name,
                                          COVERAGE = item.COVERAGE,
                                          LIMIT = item.LIMIT,
                                          ATTACHMENTPOINT = item.ATTACHMENTPOINT,
                                          limit_USD = item.limit_USD,
                                          AT_USD = item.AT_USD,
                                          SHARE = item.SHARE,
                                          CURRENCY = item.CURRENCY,
                                          tower_id = item.tower_id,
                                          file_name = item.file_name,
                                          risk_count = item.risk_count,
                                          primary_ind = item.primary_ind,
                                          p_saved_name = p_saved_name,
                                          plimit = plimit,
                                          pat = pat,
                                          p_filename = p_filename,
                                          prevsum = prevsum,
                                          primary_TM = item.primary_TM,
                                          nonprimary_TM = item.nonprimary_TM,
                                          final_TM = item.final_TM,
                                      }).ToList();


                    _empDAC.BulkInsertTowerMatchoutPut(t_xpo_tm_final);
                    _empDAC.InsertdateTime(runcycle, t_xpo_tm_final.Count(),Cov);

                    tm6 = new List<SubStage>();
                    tm4 = new List<SubStage>();
                    runcycle++;
                    rowstoprocess = t_xpo_tm_interim.Count();

                }

                _empDAC.FinalTowerMatch(Cov);



                /// End ///




                XLTrace.Write("Processing Tower Match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Processing Tower Match and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return utowerMatchstatus;
        }

        /// <summary>
        /// Get All Matching Data For Inprogress screen
        /// </summary>
        /// <param name="mastertype"></param>
        /// <param name="assetName"></param
        /// <returns></returns>
        public List<AllMatchDataBE> GetAllMatchData(string mastertype, string assetName)
        {
            List<AllMatchDataBE> allMatchData = new List<AllMatchDataBE>();
            try
            {
                //Calling StartTrace() method
                XLTrace.StartMethodTrace();
                allMatchData = _empDAC.GetAllMatchData(mastertype, assetName);
                XLTrace.Write("Retrieved all document detail pending for name match", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Retrieving all document detail pending for name match Failed. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, Constants.EMP_NM_ERROR, System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return allMatchData;
        }

        /// <summary>
        /// Compresses the string.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns></returns>
        public static string CompressString(string text)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(text);
            var memoryStream = new MemoryStream();
            using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                gZipStream.Write(buffer, 0, buffer.Length);
            }

            memoryStream.Position = 0;

            var compressedData = new byte[memoryStream.Length];
            memoryStream.Read(compressedData, 0, compressedData.Length);

            var gZipBuffer = new byte[compressedData.Length + 4];
            Buffer.BlockCopy(compressedData, 0, gZipBuffer, 4, compressedData.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gZipBuffer, 0, 4);
            return Convert.ToBase64String(gZipBuffer);
        }

        /// <summary>
        /// Decompresses the string.
        /// </summary>
        /// <param name="compressedText">The compressed text.</param>
        /// <returns></returns>
        public static string DecompressString(string compressedText)
        {
            byte[] gZipBuffer = Convert.FromBase64String(compressedText);
            using (var memoryStream = new MemoryStream())
            {
                int dataLength = BitConverter.ToInt32(gZipBuffer, 0);
                memoryStream.Write(gZipBuffer, 4, gZipBuffer.Length - 4);

                var buffer = new byte[dataLength];

                memoryStream.Position = 0;
                using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    gZipStream.Read(buffer, 0, buffer.Length);
                }

                return Encoding.UTF8.GetString(buffer);
            }
        }

        /// <summary>
        /// Get Inprogress Asset Names
        /// </summary>
        /// <returns></returns>

        public List<AssetNamesBE> GetInProgressAssetNames()
        {
            List<AssetNamesBE> assetNames = new List<AssetNamesBE>();
            try
            {
                XLTrace.StartMethodTrace();
                assetNames = _empDAC.GetInProgressAssetNames();
                XLTrace.Write("Retrieved all Distinct Asset Names", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Getting Asset Names failed. Please check and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "Getting AssetNames Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return assetNames;
        }

        /// <summary>
        /// Remove Special Characters
        /// </summary>
        /// <param name="input">Remove special Characters.</param>
        /// <returns></returns>
        public static string RemoveSpecialChars(string input)
        {
            return Regex.Replace(input, @"[^0-9a-zA-Z\._]", string.Empty);
        }


        /// <summary>
        /// Save multi Mapped names
        /// </summary>
        /// <param name="match"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int SaveMatchData(string masterType, string data, string userId)
        {
            int updateMatchDataresult = 0;
            try
            {
                XLTrace.StartMethodTrace();
                updateMatchDataresult = _empDAC.SaveMatchData(masterType, data, userId);
                XLTrace.Write("Saved successfully", "RefDataMatch", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Mapping failed. Please check and retry. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return updateMatchDataresult;
        }

        public int SavingMatchData(List<RefDataMatchBE> mappedData, string userId)
        {
            int updateMatchDataresult = 0;
            try
            {
                XLTrace.StartMethodTrace();
                updateMatchDataresult = _empDAC.SavingMatchData(mappedData, userId);
                XLTrace.Write("Saved successfully", "RefDataMatch", System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write("Mapping failed. Please check and retry. Error :  " + ex.Message + "StackTrace : " + ex.StackTrace, "ApiMatch Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return updateMatchDataresult;
        }



        /// <summary>
        /// Tower Match API
        /// </summary>
        /// <returns></returns>

        public bool TowerMatchProcess()
        {
            bool tProcess = false;
            try
            {
                XLTrace.StartMethodTrace();
                List<CoverageBE> coverages = new List<CoverageBE>();
                coverages = _empDAC.GetTCoverage();
                foreach (var cov in coverages)
                {
                    tProcess = _empDAC.TowerMatchProcess(cov.Coverage.ToString(), 0);

                }

                /// Main logic ///
                /// get all data ///


                //Create datatable for rates table//
                //create


                /// End of logic///

                XLTrace.Write("TowerMatch Process successfully completed", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write(" TowerMatch Process failed. Please check and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "TowerMatch Process Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return tProcess;
        }


        public List<TowerMatchUsersBE> GetTowerMatchAccessUsers()
        {
            List<TowerMatchUsersBE> users = new List<TowerMatchUsersBE>();
            try
            {
                XLTrace.StartMethodTrace();
               users = _empDAC.GetTowerMatchAccessUsers();
                //users = _empDAC.GetTowerMatchAccessUsers();
                
                XLTrace.Write("TowerMatch Process successfully completed", Constants.C_USER_ACTIVITY, System.Diagnostics.TraceEventType.Information);
            }
            catch (Exception ex)
            {
                XLTrace.Write(" TowerMatch Process failed. Please check and retry. Error : " + ex.Message + "StackTrace : " + ex.StackTrace, "TowerMatch Process Error", System.Diagnostics.TraceEventType.Error);
                throw new Exception(ex.Message);
            }
            finally
            {
                //Calling EndTrace() method
                XLTrace.EndMethodTrace();
            }
            return users;
        }



        public List<ResultSearchResult> LoadResults()
        {
            List<ResultSearchResult> m_reuslt = new List<ResultSearchResult>();

            try
            {
                m_reuslt = _empDAC.LoadResults();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return m_reuslt;
        }

        public DataTable LoadResults1(string EntityName)
        {
            DataTable m_reuslt1 = new DataTable();
            m_reuslt1 = _empDAC.LoadResults1(EntityName);
            return m_reuslt1;
        }
        public DataTable LoadAviExpResult(bool isHeader)
        {
            DataTable dt = new DataTable();
            dt = _empDAC.LoadAviExpResult(isHeader);
            return dt;
        }
        
    }

}


