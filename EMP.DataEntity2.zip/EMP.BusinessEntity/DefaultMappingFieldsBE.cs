﻿using System.Collections.Generic;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Table("t_emp_default_mapping_fields")]
    public class DefaultMappingFieldsBE : BaseEMPAuditableBusinessEntity<DefaultMappingFieldsBE>
    {
        [Column("emp_default_mapping_fields_guid")]
        public int? DefaultMappingFieldGuid { get; set; }
        [Column("rms_field_guid", true)]
        public int RMSFieldGuid { get; set; }
        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("FieldOrder")]
        public int FieldOrder { get; set; }
        [Column("data_type")]
        public string DataType { get; set; }
        [Column("default_value")]
        public string DefaultValue { get; set; }
        [Column("active_ind")]
        public int ActiveInd { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.DefaultMappingFieldGuid;
            }
            set
            {
                this.DefaultMappingFieldGuid = value;
            }
        }
      
    }
}
