﻿using EMP.Interfaces.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_us_postcodes")]
    public class UsPostalCodeBE : BaseEMPBusinessEntity<UsPostalCodeBE>, IUsPostalCodeBE
    {
        [Column("t_emp_us_postcodes_guid")]
        public int ? PostCodeGuid { get; set; }
        [Column("StateCode")]
        public string StateCode { get; set; }
        [Column("ZipCode")]
        public string ZipCode { get; set; }
        [Column("County")]
        public string County { get; set; }



        public override int? PrimaryKey
        {
            get
            {

                return this.PostCodeGuid;
            }
            set
            {
                this.PostCodeGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }
    }
}
