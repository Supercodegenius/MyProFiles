﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class XPOMarineLookupBE
    {
        public long? InsuranceKey { get; set; }
        public long? ObjectId { get; set; }
        public string ClarksonId { get; set; }
        public string IdSource { get; set; }
        public string GroupInstallation { get; set; }
        public string MatchName { get; set; }
        public string AssetType { get; set; }
        public string AssetSubtype { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string AssetInstallationYear { get; set; }
        public double? WaterDepth { get; set; }
        public string Platform { get; set; }
        public string Complex { get; set; }
        public string Field { get; set; }
        public string Area { get; set; }
        public long? ImoNumber { get; set; }
        public long? MmsiNumber { get; set; }
        public Nullable<DateTime> ModifyDt { get; set; }
        public String ModifyBy { get; set; }
        public String ModifyApp { get; set; }
        public Nullable<DateTime> AddedDt { get; set; }
        public String AddedBy { get; set; }
        public String AddedApp { get; set; }
        public int? Version { get; set; }
        public int? RefVersion { get; set; }
        public string EpmType { get; set; }
    }
}
