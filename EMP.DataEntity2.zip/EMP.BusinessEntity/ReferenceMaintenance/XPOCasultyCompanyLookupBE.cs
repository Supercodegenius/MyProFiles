﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class XPOCasultyCompanyLookupBE 
    {
        public long xpo_insurance_company_guid { get; set; }
        public string original_name { get; set; }
        public string original_country { get; set; }
        public string original_industry { get; set; }
        public string saved_name { get; set; }
        public string conformed_country { get; set; }
        public string conformed_industry { get; set; }
        public string reference_id { get; set; }
        public DateTime? validation_date { get; set; }
        //public DateTime? expire { get; set; }
        public double? revenue { get; set; }
        public int? employee_count { get; set; }

        public Nullable<DateTime> ModifyDt { get; set; }
        public String ModifyBy { get; set; }
        public String ModifyApp { get; set; }
        public Nullable<DateTime> AddedDt { get; set; }
        public String AddedBy { get; set; }
        public String AddedApp { get; set; }


        public int? Version { get; set; }
        public int? ref_version { get; set; }
    }
}
