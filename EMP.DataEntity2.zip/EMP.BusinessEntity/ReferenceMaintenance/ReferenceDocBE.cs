﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_ref_doc")]
    public class ReferenceDocBE : BaseEMPAuditableBusinessEntity<ReferenceDocBE>
    {
        [Column("[ref_doc_guid]", IsPrimaryKey = true, IsIdentifer = true)]
        public int? DocGuid { get; set; }
        [Column("lookup_type")]
        public string Type { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("file_name")]
        public string FileName { get; set; }
        [Column("record_count")]
        public int? RecordCount { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public override int? PrimaryKey
        {
            get
            {

                return this.DocGuid;
            }
            set
            {
                this.DocGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 19;
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        [Serializable]
        public class DocumentBECollection : List<DocumentBE>
        {
        }
    }
}
