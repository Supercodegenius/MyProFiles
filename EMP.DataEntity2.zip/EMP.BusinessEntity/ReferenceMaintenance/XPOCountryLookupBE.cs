﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    //[Table("[t_xpo_country_lookup]")]
    public class XPOCountryLookupBE// : BaseEMPAuditableBusinessEntity<XPOCountryLookupBE>
    {
        //[Column("[xpo_country_lookup_guid]")]
        public long xpo_country_lookup_guid { get; set; }
        //[Column("[location]")]
        public string location { get; set; }
        //[Column("[mapped_country]")]
        public string mapped_country { get; set; }
        //[Column("[validated_date]")]
        public DateTime validated_date { get; set; }
        // [Column("[ref_version]")]

        public Nullable<DateTime> ModifyDt { get; set; }
        public String ModifyBy { get; set; }
        public String ModifyApp { get; set; }
        public Nullable<DateTime> AddedDt { get; set; }
        public String AddedBy { get; set; }
        public String AddedApp { get; set; }
       
       
        public int? Version { get; set; }
        public int? ref_version { get; set; }
        //public override int? PrimaryKey
        //{
        //    get
        //    {

        //        return this.xpo_country_lookup_guid;
        //    }
        //    set
        //    {
        //        this.xpo_country_lookup_guid = (int)value;
        //    }
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public override int GetPrimaryKeyID()
        //{
        //    return 16;
        //}


        ///// <summary>
        ///// Returns the DAC object for the ReportHeader business Entity.
        ///// This method returns instance of the BaseDataAccessComponent.
        ///// </summary>
        ///// <returns></returns>
        //public override BaseDataAccessComponent GetDAC()
        //{
        //    return base.GetDAC();
        //}
    }
}
