﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    public abstract class BaseEMPAuditableBusinessEntity<T> : BaseEMPBusinessEntity<T>, IBaseDataEntity
         where T : BaseBusinessEntity
    {

        #region Implementation of IBaseDataEntity
        /// <summary>
        /// Audit attribute - date this record is created.
        /// </summary>
        [Column("added_dt")]
        public Nullable<DateTime> AddedDt { get; set; }
        /// <summary>
        /// Audit attribute - user id of user that created this record.
        /// </summary>
        [Column("added_by")]
        public String AddedBy { get; set; }
        /// <summary>
        /// Audit attribute - application that create this record.
        /// </summary>
        [Column("added_app")]
        public String AddedApp { get; set; }
        /// <summary>
        /// Audit attribute - date that this record is updated.
        /// </summary>
        [Column("modify_dt")]
        /// <summary>
        /// Audit attribute - date that this record is updated.
        /// </summary>
        public Nullable<DateTime> ModifyDt { get; set; }
        /// <summary>
        /// Audit attribute - user id of the user that updates this record
        /// </summary>
        [Column("modify_by")]
        public String ModifyBy { get; set; }
        /// <summary>
        /// Audit attribute - application that updates this record.
        /// </summary>
        [Column("modify_app")]
        public String ModifyApp { get; set; }
        /// <summary>
        /// version used in optimistic record locking.
        /// </summary>
        [Column("version")]
        public new int? Version { get; set; }

        #endregion

    }
}
