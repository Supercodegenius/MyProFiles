﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    public class CountryLookupBE
    {
        [Column("emp_cntry_lookup_guid")]
        public int? CountryLookupguid { get; set; }

        [Column("Country")]
        public string CountryDesc { get; set; }

        [Column("ISO2A")]
        public string ISO2A { get; set; }
        [Column("ISO3A")]
        public string ISO3A { get; set; }
        [Column("ISO3N")]
        public int ISO3N { get; set; }
        [Column("FIPS")]
        public string FIPS { get; set; }
        [Column("RMS_Code")]
        public string RMS_Code { get; set; }
        [Column("FIRE_construction_allowed")]
        public bool FIRE_construction_allowed { get; set; }
    }
}
