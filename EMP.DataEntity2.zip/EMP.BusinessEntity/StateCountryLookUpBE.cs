﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    public class StateCountryLookUpBE
    {
        [Column("cntrycode")]
        public string CountryCode { get; set; }
        [Column("statecode")]
        public string StateCode { get; set; }
        [Column("state")]
        public string State { get; set; }
    }
}
