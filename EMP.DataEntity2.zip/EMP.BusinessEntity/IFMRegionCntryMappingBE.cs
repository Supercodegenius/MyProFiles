﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
    public class IFMRegionCntryMappingBE
    {
        [Column("ISO2ACountryCode")]
        public string IS02ACode { get; set; }
        [Column("ifm_occdesc")]
        public string IFMOccupancy { get; set; }
        [Column("ifm_2or4digit")]
        public string IFM2or4digitOcc { get; set; }
        [Column("code")]
        public int Code { get; set; }
       
    }

    [Serializable]
    public class ResultSearchResult
    {

        /// <summary>
        /// read / write the data for EmtResultsGuid variable.
        /// </summary>	
        [Column("emt_results_guid")]
        public long? EmtResultsGuid { get; set; }
        [Column("obu")]
        public string Obu { get; set; }
        /// <summary>
        /// read / write the data for Program variable.
        /// </summary>	
        [Column("program")]
        public string Program { get; set; }
        /// <summary>
        /// read / write the data for UwYear variable.
        /// </summary>	
        [Column("uw_year")]
        public Nullable<int> UwYear { get; set; }
        /// <summary>
        /// read / write the data for Class variable.
        /// </summary>	
        [Column("class")]
        public string Class { get; set; }
        /// <summary>
        /// read / write the data for EmtProgramGuid variable.
        /// </summary>	
        [Column("emt_program_guid")]
        public Nullable<int> EmtProgramGuid { get; set; }
        /// <summary>
        /// read / write the data for EmtInsuranceGuid variable.
        /// </summary>	
        [Column("emt_insurance_guid")]
        public Nullable<int> EmtInsuranceGuid { get; set; }
        /// <summary>
        /// read / write the data for SavedName variable.
        /// </summary>	
        [Column("saved_name")]
        public string SavedName { get; set; }
        /// <summary>
        /// read / write the data for SavedName variable.
        /// </summary>	
        [Column("industry_desc")]
        public string IndustryDesc { get; set; }
        /// <summary>
        /// read / write the data for Exposure variable.
        /// </summary>	
        [Column("exposure")]
        public double Exposure { get; set; }
        [Column("minattach")]
        public double MinAttach { get; set; }
        [Column("iLimit_amt")]
        public double ILimitAmt { get; set; }
        [Column("iExcess_amt")]
        public double IExcessAmt { get; set; }
        [Column("eff_dt")]
        public DateTime EffDt { get; set; }
        [Column("exp_dt")]
        public DateTime ExpDt { get; set; }



        /// <summary>
        /// read / write the data for CurrGuid variable.
        /// </summary>	
        [Column("curr_guid")]
        public string CurrGuid { get; set; }
        /// <summary>
        /// read / write the data for EmtReinsuranceLayerGuid variable.
        /// </summary>	
        [Column("emt_reinsurance_layer_guid")]
        public Nullable<int> EmtReinsuranceLayerGuid { get; set; }
        /// <summary>
        /// read / write the data for PolicyRef variable.
        /// </summary>	
        [Column("policy_ref")]
        public string PolicyRef { get; set; }
        /// <summary>
        /// read / write the data for Currency variable.
        /// </summary>	
        [Column("currency")]
        public string Currency { get; set; }
        /// <summary>
        /// read / write the data for MasterCcy variable.
        /// </summary>	
        [Column("master_ccy")]
        public Nullable<bool> MasterCcy { get; set; }
        /// <summary>
        /// read / write the data for LimitAmt variable.
        /// </summary>	
        [Column("limit_amt")]
        public double LimitAmt { get; set; }
        /// <summary>
        /// read / write the data for ExcessAmt variable.
        /// </summary>	
        [Column("excess_amt")]
        public double ExcessAmt { get; set; }
        /// <summary>
        /// read / write the data for SharePct variable.
        /// </summary>	
        [Column("share_pct")]
        public double SharePct { get; set; }
        /// <summary>
        /// read / write the data for Usethis variable.
        /// </summary>	
        [Column("usethis")]
        public Nullable<int> Usethis { get; set; }
        /// <summary>
        /// read / write the data for Losstolayerccy variable.
        /// </summary>	
        [Column("losstolayerCCY")]
        public double Losstolayerccy { get; set; }
        /// <summary>
        /// read / write the data for Losstolayermasterccy variable.
        /// </summary>	
        [Column("losstolayerMasterCCY")]
        public double Losstolayermasterccy { get; set; }
        /// <summary>
        /// read / write the data for Losstolayerusdfrommaster variable.
        /// </summary>	
        [Column("losstolayerUSDFromMaster")]
        public double Losstolayerusdfrommaster { get; set; }
        /// <summary>
        /// read / write the data for Losstolayerusdfromccy variable.
        /// </summary>	
        [Column("losstolayerUSDFromCCY")]
        public double Losstolayerusdfromccy { get; set; }
        /// <summary>
        /// read / write the data for Lossusd variable.
        /// </summary>	
        [Column("lossUSD")]
        public double Lossusd { get; set; }
        [Column("netlossUSD")]
        public double NetLossusd { get; set; }
        [Column("minattach")]
        public double? minAttach { get; set; }
        [Column("rsPrem")]
        public double? rsPrem { get; set; }
        [Column("emt_loss_scenario_group_guid")]
        public int? EmtLossScenarioGroupGuid { get; set; }
        [Column("premium_amt")]
        public double? PremiumAmt { get; set; }
        [Column("sort_index")]
        public int? SortIndex { get; set; }
        //[Column("premium_year")]
        //public string PremiumYear { get; set; }
        //[Column("industry_loss")]
        //public double IndustryLoss { get; set; }
        [Column("industry_minor_desc")]
        public string IndustryMinorDesc { get; set; }


        //public override void PopulateProperties(DataSet argResultRow)
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        /// <summary>
        /// This public method populates the PropertyInfo class and then gets the 
        /// custom attributes for each of the properties and calls the SetPropertyValue
        /// to set the value of the object to the value of the reader.
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// <code>
        /// Called By      :- 
        /// This method calls 
        ///     SetPropertyValue
        /// </code> 
        /// <code>
        /// The outline of the method is given below
        ///   This methods gets the property values and the attributes associated with
        ///   them and sets the value.
        /// </code>
        /// <code>
        /// The Details of the method are
        ///   It first gets all the properties in a Property info array
        ///   then for each property in the array it gets the custom 
        ///   attributes associated with each property.Here we are assuming 
        ///   that each property has only one custom attribute associated 
        ///   with it.o we only get the first custom attribute for each property.
        ///   Then we call the SetPropertyValue function to set the value of
        ///   object to the value of the reader.
        /// </code>
        /// </remarks>
        //public void PopulateProperties(DataRow argResultRow)
        //{
        //    PropertyInfo[] l_ColPropertyInfo = this.GetType().GetProperties();

        //    foreach (PropertyInfo l_ResultEntityProperty in l_ColPropertyInfo)
        //    {
        //        //Get all the Custom Attributes associated with the Property
        //        ColumnAttribute[] l_ColColumnAttribute = (ColumnAttribute[])l_ResultEntityProperty.GetCustomAttributes(typeof(ColumnAttribute), true);
        //        //The assumption here is that there is only one ColumnAttribute defined for a property
        //        //hence get the first ColumnAttribute from the collection
        //        // Setting the value of the object to the values of reader
        //        this.SetPropertyValue(this, l_ResultEntityProperty, argResultRow[l_ColColumnAttribute[0].ColumnName]);
        //    }
        //    //throw new Exception("The method or operation is not implemented.");

        //}

        /// <summary>
        /// This private method sets the type of the custom attribute of a property
        /// </summary>
        /// <remarks>
        /// <code>
        /// Called By      :- PopulateProperties
        /// This method calls :-
        /// </code>
        /// <code>
        /// The method takes the current object,the property whose custom attribute
        /// has to be set and the custom attribute whose type has to be set as the input.
        /// it first checks whether there is any custom attribute to be set.if not
        /// it returns back.it then checks for the type of the custom attribute as it 
        /// is set in the database and depending on the type the value of custom attribute
        /// is changed to that type.if the type does not match to the standard data types
        /// then the type is set as null.
        /// </code>
        /// </remarks>
        /// <param name="argObjectToChange"></param>
        /// <param name="argPropertyInfo">The propety whose custom attribute is set.</param>
        /// <param name="argValue">The custom attribute whose type is changed</param>
        //private void SetPropertyValue(object argObjectToChange, PropertyInfo argPropertyInfo, object argValue)
        //{

        //    //if DB field value is null, don't set the value
        //    if (argValue is DBNull)
        //    {
        //        return;
        //    }

        //    //check if the DB field value is of Value type
        //    if (argValue.GetType().IsValueType)
        //    {

        //        switch (argValue.GetType().ToString())
        //        {

        //            case "System.Int32":
        //                Nullable<int> l_IntValue = (int)argValue;
        //                argPropertyInfo.SetValue(argObjectToChange, l_IntValue, null);
        //                break;

        //            case "System.DateTime":
        //                Nullable<DateTime> l_DateValue = (DateTime)argValue;
        //                argPropertyInfo.SetValue(argObjectToChange, l_DateValue, null);
        //                break;

        //            case "System.Boolean":
        //                Nullable<bool> l_BoolValue = (Boolean)argValue;
        //                argPropertyInfo.SetValue(argObjectToChange, l_BoolValue, null);
        //                break;

        //            case "System.Double":
        //                Nullable<double> l_DblValue = (double)argValue;
        //                argPropertyInfo.SetValue(argObjectToChange, l_DblValue, null);
        //                break;

        //            case "System.double":
        //                Nullable<double> l_DecValue = Convert.ToDouble(argValue);
        //                argPropertyInfo.SetValue(argObjectToChange, l_DecValue, null);
        //                break;
        //        }
        //    }

        //    else
        //    {
        //        argPropertyInfo.SetValue(argObjectToChange, argValue, null);
        //    }
        //}

    }

    [Serializable]
    public class ResultSearchTSIReports
    {
        /// read / write the data for Class variable.
        /// </summary>	
        [Column("class_desc")]
        public string Class { get; set; }

        [Column("country")]
        public string Country { get; set; }
        /// <summary>
        /// read / write the data for Program variable.
        /// </summary>	
        [Column("loss")]
        public double Loss { get; set; }
    }

    [Serializable]

    public class ResultSearchBandedReports
    {
        /// read / write the data for Class variable.

        /// </summary>	

        [Column("band")]
        public string Band { get; set; }

        /// <summary>

        /// read / write the data for Program variable.

        /// </summary>	

        [Column("loss")]
        public double Loss { get; set; }
        /// <summary>

        /// read / write the data for Program variable.

        /// </summary>	

        [Column("coverage")]
        public string Coverage { get; set; }
        [Column("program_desc")]
        public string ProgramDesc { get; set; }
        /// <summary>
        /// read / write the data for UwYear variable.
        /// </summary>	
        [Column("uw_year")]
        public Nullable<int> UwYear { get; set; }
        /// <summary>

        /// read / write the data for SavedName variable.

        /// </summary>	

        [Column("saved_name")]
        public string SavedName { get; set; } //KK
    }

    public class PremiumComparisonReportdBE
    {
        /// read / write the data for Class variable.

        /// </summary>	

        [Column("class")]
        public string Class { get; set; }

        /// <summary>

        /// read / write the data for Program variable.

        /// </summary>	

        [Column("premium_amt")]
        public double PremiumAmt { get; set; }
        /// <summary>



        /// <summary>
        /// read / write the data for UwYear variable.
        /// </summary>	
        [Column("sort_index")]
        public int? SortIndex { get; set; }
        [Column("premium_year")]
        public string PremiumYear { get; set; }
        /// <summary>

        /// read / write the data for SavedName variable.

        /// </summary>	

        [Column("saved_name")]
        public string SavedName { get; set; } //KK
    }
}
