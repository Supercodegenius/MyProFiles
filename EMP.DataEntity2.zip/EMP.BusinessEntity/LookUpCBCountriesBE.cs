﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_lookup_caribbeancountries")]
    public class LookUpCBCountriesBE: BaseEMPAuditableBusinessEntity<FileProcessingTasksBE>
    {
        [Column("t_emp_lkup_cbcountries_guid")]
        public int? LookupGuid { get; set; }
        [Column("ISO2ACountryCode")]
        public string CountryCode { get; set; }
        [Column("Country")]
        public string Country { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.LookupGuid;
            }
            set
            {
                this.LookupGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

    }
}
