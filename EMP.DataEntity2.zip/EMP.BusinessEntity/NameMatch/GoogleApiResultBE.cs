﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class GoogleApiResultBE
    {
        public string Title { get; set; }
        public string Website { get; set; }
        public string Description { get; set; }
        public string Address { get; set; }
    }
}
