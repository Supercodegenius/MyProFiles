﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_rms_fields")]
    public class SOVRMSMappedColumnsBE
    {

        [Column("rms_field_guid")]
        public int RMSFieldGuid { get; set; }

        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }

        [Column("field_order")]
        public int FieldOrder { get; set; }

        [Column("filter_type")] 
        public string FilterType { get; set; }

       
    }
}
