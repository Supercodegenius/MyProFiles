﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
    public  class UnmatchedCompaniesBE
    {
        [Column("CompanyGuid")]
        public int CompanyGuid { get; set; }
        [Column("CompanyName")]
        public string CompanyName { get; set; }
        [Column("Country")]
        public string Country { get; set; }
        [Column("Industry")]
        public string Industry { get; set; }

    }
}
