﻿namespace EMP.BusinessEntity
{
    public class AllMatchedMappingData
    {
        public string fileProcessingTaskGuids { get; set; }
    }
}
