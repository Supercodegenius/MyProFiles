﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class ApiMatchBE
    {
        public int FileProcessingGuid { get; set; }
        public string OriginalCompany { get; set; }
        public string OriginalCountry { get; set; }
        public string MatchedCompany { get; set; }
    }
}
