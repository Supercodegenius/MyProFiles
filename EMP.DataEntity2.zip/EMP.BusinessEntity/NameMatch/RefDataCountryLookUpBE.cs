﻿using System;
using System.Runtime.Serialization;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class RefDataCountryLookUpBE
    {
        [Column("Location")]
        public string Location { get; set; }

        [Column("MappedCountry")]
        public string MappedCountry { get; set; }

        [Column("ValidatedDate")]
        public DateTime ValidateDate { get; set; }

        [DataMember]
        public string ValidatedDate
        {
            get { return this.ValidateDate.ToString("MM/dd/yyyy"); }
            set { this.ValidateDate = DateTime.Parse(value); }
        }
    }
}

