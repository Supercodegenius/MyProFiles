﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class CountryMatchBE
    {
        public string OriginalName { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
    }
}
