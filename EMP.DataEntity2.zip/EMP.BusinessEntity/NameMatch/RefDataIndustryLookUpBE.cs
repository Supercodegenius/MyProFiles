﻿using System;
using System.Runtime.Serialization;
using XLCapital.XLRE.Framework.DataAccessHelper;


namespace EMP.BusinessEntity
{
    [Serializable]
    public class RefDataIndustryLookUpBE
    {
        [Column("Industry")]
        public string Industry { get; set; }

        [Column("MappedIndustry")]
        public string MappedIndustry { get; set; }

        [Column("ValidatedDate")]
        public DateTime ValidateDate { get; set; }
        
        [DataMember]
        public string ValidatedDate
        {
            get { return this.ValidateDate.ToString("MM/dd/yyyy"); }
            set { this.ValidateDate = DateTime.Parse(value); }
        }

    }
}
