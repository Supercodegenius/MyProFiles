﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class RefDataMatchBE
    {
        public int InsuranceGuid { get; set; }
        public string OriginalName { get; set; }
        public string OriginalCountry { get; set; }
        public string OriginalIndustry { get; set; }
        public string MappedName { get; set; }
        public string MappedCountry { get; set; }
        public string MasterType { get; set; }
        public bool addNewRow { get; set; }
        public string Ciq { get; set; }
    }
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

    public class LoopTable
    {
        public int id { get; set; }
        public int emt_insurance_guid { get; set; }
        public string primary_TM { get; set; }
        public string nonprimary_TM { get; set; }
        public string final_TM { get; set; }
    }
    




}
