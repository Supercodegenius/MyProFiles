﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class MatchDataBE
    {
        [Column("matchId")]
        public int MatchId { get; set; }

        [Column("original")]
        public string Original { get; set; }

        [Column("mapped")]
        public string Mapped { get; set; }

        [Column("original_country")]
        public string original_country { get; set; }

        [Column("conformed_country")]
        public string conformed_country { get; set; }

        [Column("drillcountry")]
        public string drillcountry { get; set; }

        [Column("original_industry")]
        public string original_industry { get; set; }

        [Column("distance")]
        public int Distance { get; set; }

    }
}
