﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
   public class SaveMatchDataBE
    {
        public string MasterType { get; set; }
        public string InsertedData { get; set; }
    }
}
