﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
   public class NameMatchApiDataBE
    {
        public int InsuranceGuid { get; set; }
        public List<string> CIQ { get; set; }
        public List<string> ConformedCountry { get; set; }
        public List<string> ConformedIndustry { get; set; }
        public List<string> ConformedName { get; set; }
        public List<string> Likelihood { get; set; }
        public List<string> Predict { get; set; }
        public List<string> Location { get; set; }
        public List<string> NamedInsured { get; set; }
    }
}
