﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
   public class UnmatchedCountryBE
    {
        [Column("LOCATION")]
        public string Location { get; set; }
    }
}
