﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class UnMatchDataBE
    {

        [Column("emt_insurance_guid")]
        public int EmtInsuredGuid { get; set; }

        [Column("nameInsured")]
        public string NameInsured { get; set; }

        [Column("fileName")]
        public string FileName { get; set; }

        [Column("exposure")]
        public double Exposure { get; set; }

        [Column("country")]
        public string Country { get; set; }

        [Column("industry")]
        public string Industry { get; set; }

        [Column("row_count")]
        public int RowCount { get; set; }

        [Column("ciq")]
        public string Ciq { get; set; }

        [Column("orig_country")]
        public string OriginalCountry { get; set; }
    }
}




