﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class NameMatchStageBE
    {
        public int FileprocessingtaskGuid { get; set; }
        public int InsuranceGuid { get; set; }
        public string OriginalName { get; set; }
        public string MatchedName { get; set; }
        public string OriginalLocation { get; set; }
        public string MatchedLocation { get; set; }
        public string OriginalIndustry { get; set; }
        public string MatchedIndustry { get; set; }
    }
}
