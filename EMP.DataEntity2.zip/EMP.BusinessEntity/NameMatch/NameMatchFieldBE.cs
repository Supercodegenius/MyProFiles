﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("[t_emt_insurance_stage]")]
    public class NameMatchFieldBE
    {
        [Column("[emt_insurance_guid]")]
        public int InsuranceGuid { get; set; }
        [Column("[NAMEDINSURED]")]
        public string NamedInsured { get; set; }
        [Column("[LOCATION]")]
        public string Location { get; set; }
    }
}
