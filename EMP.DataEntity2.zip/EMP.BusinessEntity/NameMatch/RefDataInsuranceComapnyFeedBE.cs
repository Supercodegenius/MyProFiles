﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
    public class RefDataInsuranceComapnyFeed
    {
        [Column("Insured")]
        public string Insured { get; set; }

        [Column("SavedName")]
        public string SavedName { get; set; }

        [Column("Country")]
        public string Country { get; set; }

        [Column("ConformCountry")]
        public string ConformCountry { get; set; }

        [Column("Industry")]
        public string Industry { get; set; }

        [Column("ConformIndustry")]
        public string ConformIndustry { get; set; }

        [Column("ReferenceID")]
        public string ReferenceID { get; set; }

        [Column("ValidationDate")]
        public DateTime ValidateDate { get; set; }

        [DataMember]
        public string ValidationDate
        {
            get { return this.ValidateDate.ToString("MM/dd/yyyy"); }
            set { this.ValidateDate = DateTime.Parse(value); }
        }

        //[Column("Expire")]
        //public DateTime Expire { get; set; }

        [Column("Revenue")]
        public double? Revenue { get; set; }

        [Column("EmployeeCount")]
        public double? EmployeeCount { get; set; }
    }
}
