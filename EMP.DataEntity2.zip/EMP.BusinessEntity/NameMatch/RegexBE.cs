﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
    public class RegexBE
    {
       
        [Column("regex")]
        public string Regex { get; set; }
    }
}
