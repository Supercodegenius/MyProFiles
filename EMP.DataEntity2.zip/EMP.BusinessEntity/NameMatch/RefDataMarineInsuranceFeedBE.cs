﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Serializable]
   public class RefDataMarineInsuranceFeedBE
    {
        [Column("ObjectId")]
        public string ObjectId { get; set; }

        [Column("ClarksonId")]
        public string ClarksonId { get; set; }

        [Column("Source")]
        public string Source { get; set; }

        [Column("GroupInstallation")]
        public string GroupInstallation { get; set; }

        [Column("MatchName")]
        public string MatchName { get; set; }

        [Column("Type")]
        public string Type { get; set; }

        [Column("SubType")]
        public string SubType { get; set; }

        [Column("Latitude")]
        public string Latitude { get; set; }

        [Column("Longitude")]
        public string Longitude { get; set; }

        [Column("InstalationYear")]
        public string InstalationYear { get; set; }

        [Column("WaterDepth")]
        public double? WaterDepth { get; set; }

        [Column("Platform")]
        public string Platform { get; set; }

        [Column("Complex")]
        public string Complex { get; set; }

        [Column("Field")]
        public string Field { get; set; }

        [Column("Area")]
        public string Area { get; set; }

        [Column("Imo")]
        public string Imo { get; set; }

        [Column("Mmsi")]
        public string Mmsi { get; set; }

        [Column("EPM_type")]
        public string EpmType { get; set; }

    }
}
