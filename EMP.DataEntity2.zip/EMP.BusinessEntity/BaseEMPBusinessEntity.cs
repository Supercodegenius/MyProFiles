﻿/*************************************************************************************
* 1. Class Name				: BaseEMPBusinessEntity					
* 2. Description		    : Base class for Business Entity in UWWB.
*                                                              
* 3. Modification Log
* Date 		   Author	       Request No		 Description     
* 10/11/2019   Tony Zhang          N/A                Created
*************************************************************************************/
using EMP.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.Constants;

namespace EMP.BusinessEntity
{
    public abstract class BaseEMPBusinessEntity<T> : BaseBusinessEntity, IDataEntity, IBaseEntity
          where T : BaseBusinessEntity
    {
        #region constructor
        /// <summary>
        /// Constructor.
        /// </summary>
        public BaseEMPBusinessEntity() : base()
        {
            //this.Version = 1;
            this.ChangedStatus = EntityStatus.StatusUnchanged;
        }

        #endregion

        #region Overrides of BaseBusinessEntity
        /// <summary>
        /// Override ConvertToDE.  In this scenario, this method just return the object itself.
        /// </summary>
        /// <returns></returns>
        public override IDataEntity ConvertToDE()
        {
            return this;
        }

        public override BaseBusinessEntity ConvertToBE(IDataEntity argDataEntity)
        {
            return argDataEntity as T;
        }

        public override void CreateEntityAssociations()
        {
        }

        public override int GetPrimaryKeyID()
        {
            throw new NotImplementedException();
        }

        public override void SetForeignKey(string argForeignKey, int? argForeignKeyValue)
        {
        }


        #endregion

    }
    
}
