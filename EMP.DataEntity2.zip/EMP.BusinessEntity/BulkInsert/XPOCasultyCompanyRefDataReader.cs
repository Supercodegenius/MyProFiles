﻿

# region Using Directive
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
# endregion

/// <summary>
/// DataReader used to bulk save the EMP Converted Locations
/// </summary>
namespace EMP.BusinessEntity.BulkInsert
{
    public class XPOCasultyCompanyRefDataReader : IDataReader
    {
        public DataTable m_SchemaTable = null;

        # region Columns
        //new columns
        public const string C_SQL_INSERT_XPO_INSURANCE_COMPANY_GUID = "xpo_insurance_company_guid";
        public const string C_SQL_INSERT_ORIGINAL_NAME = "original_name";
        public const string C_SQL_INSERT_ORIGINAL_COUNTRY = "original_country";
        public const string C_SQL_INSERT_ORIGINAL_INDUSTRY = "original_industry";
        public const string C_SQL_INSERT_SAVED_NAME = "saved_name";
        public const string C_SQL_INSERT_CONFORMED_COUNTRY = "conformed_country";
        public const string C_SQL_INSERT_CONFORMED_INDUSTRY = "conformed_industry";
        public const string C_SQL_INSERT_REFERENCE_ID = "reference_id";
        public const string C_SQL_INSERT_VALIDATION_DATE = "validation_date";
        //public const string C_SQL_INSERT_EXPIRE = "expire";
        public const string C_SQL_INSERT_REVENUE = "revenue";
        public const string C_SQL_INSERT_EMPLOYEE_COUNT = "employee_count";
        public const string C_SQL_INSERT_REF_VERSION = "ref_version";
        public const string C_SQL_INSERT_MODIFYDT = "modify_dt";
        public const string C_SQL_INSERT_MODIFYBY = "modify_by";
        public const string C_SQL_INSERT_ADDEDDT = "added_dt";
        public const string C_SQL_INSERT_ADDEDBY = "added_by";
        public const string C_SQL_INSERT_VERSION = "version";
        public const string C_SQL_INSERT_ADDEDAPP = "added_app";
        public const string C_SQL_INSERT_MODIFYAPP = "modify_app";

        #endregion

        #region Constructor
        public XPOCasultyCompanyRefDataReader()
            : base()
        {
            this.IsReaderClosed = false;
            this.CurrentIndex = -1;
            this.GetSchemaTable();
        }

        public XPOCasultyCompanyRefDataReader(
            List<XPOCasultyCompanyLookupBE> argSourceData,
            int argStartIndex,
            int argEndIndex,
            string argTableName)
            : this()
        {
            this.SourceData = argSourceData;
            this.StartIndex = argStartIndex;
            this.EndIndex = argEndIndex;
            this.TableName = argTableName;
        }
        # endregion

        public int GetOrdinal(string name)
        {
            return this.GetSchemaTable().Columns.IndexOf(name);
        }

        # region Schema information
        private Object GetDataValue(int argRow, int argCol)
        {            
            switch (argCol)
            {
                //case 0:
                //    return this.SourceData[argRow].xpo_country_lookup_guid;
                case 1:
                    //return this.SourceData[argRow].location;
                    return this.SetValueFromSourceData(C_SQL_INSERT_ORIGINAL_NAME, 250, argRow);
                case 2:
                    return this.SourceData[argRow].original_country;
                case 3:
                    return this.SourceData[argRow].original_industry;
                case 4:
                    return this.SourceData[argRow].saved_name;
                case 5:
                    return this.SourceData[argRow].conformed_country;
                case 6:
                    return this.SourceData[argRow].conformed_industry;
                case 7:
                    return this.SourceData[argRow].reference_id;
                case 8:
                    return this.SourceData[argRow].validation_date;
                //case 9:
                //   // return this.SourceData[argRow].expire;
                case 9:
                    return this.SourceData[argRow].revenue;
                case 10:
                    return this.SourceData[argRow].employee_count;


                case 11:
                    return this.SourceData[argRow].ModifyDt;
                case 12:
                    return this.SetValueFromSourceData("ModifyBy", 40, argRow);
                case 13:
                    return this.SetValueFromSourceData("ModifyApp", 50, argRow);
                case 14:
                    return this.SourceData[argRow].AddedDt;
                case 15:
                    return this.SetValueFromSourceData("AddedBy", 40, argRow);
                case 16:
                    return this.SetValueFromSourceData("AddedApp", 40, argRow);
                case 17:
                    return this.SourceData[argRow].Version;
                case 18:
                    return this.SourceData[argRow].ref_version;
                default:
                    throw new InvalidOperationException("Column index out of range: " + argCol);
            }
        }

        private Object SetValueFromSourceData(string argField, int argLength,int argRow)
        {
            var property = this.SourceData[argRow].GetType().GetProperty(argField);

          
            if (property != null && property.GetValue(this.SourceData[argRow])!=null && property.GetValue(this.SourceData[argRow]).ToString().Length > argLength)
            {
                return property.GetValue(this.SourceData[argRow]).ToString().Substring(0, argLength);
            }
            else
            {
                return Convert.ToString(property.GetValue(this.SourceData[argRow]));
            }
        }

        public DataTable GetSchemaTable()
        {
            if (this.m_SchemaTable == null)
            {
                m_SchemaTable = new DataTable(this.TableName);

                m_SchemaTable.Columns.Add(C_SQL_INSERT_XPO_INSURANCE_COMPANY_GUID, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINAL_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINAL_COUNTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINAL_INDUSTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SAVED_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CONFORMED_COUNTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CONFORMED_INDUSTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_REFERENCE_ID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_VALIDATION_DATE, typeof(DateTime));
                //m_SchemaTable.Columns.Add(C_SQL_INSERT_EXPIRE, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_REVENUE, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMPLOYEE_COUNT, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_VERSION, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_REF_VERSION, typeof(int));
            }
            return m_SchemaTable;
        }

        public void CreateBulkCopyMappings(SqlBulkCopy argSqlBulkCopy)
        {
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("xpo_insurance_company_guid", "xpo_insurance_company_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("original_name", "original_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("original_country", "original_country"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("original_industry", "original_industry"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("saved_name", "saved_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("conformed_country", "conformed_country"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("conformed_industry", "conformed_industry"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("reference_id", "reference_id"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("validation_date", "validation_date"));
            //argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("expire", "expire"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("revenue", "revenue"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("employee_count", "employee_count"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_by", "modify_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_app", "modify_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_dt", "added_dt"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_by", "added_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_app", "added_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("version", "version"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ref_version", "ref_version"));

        }
        # endregion

        # region Other methods
        public List<XPOCasultyCompanyLookupBE> SourceData
        {
            get;
            set;
        }
        public string TableName
        {
            get;
            set;
        }

        public int StartIndex
        {
            get;
            set;
        }

        public int EndIndex
        {
            get;
            set;
        }

        public int CurrentIndex
        {
            get;
            set;
        }

        private bool IsReaderClosed
        {
            get;
            set;
        }

        public void Close()
        {
            this.IsReaderClosed = true;
        }

        public int Depth
        {
            get { return 0; }
        }

        public bool IsClosed
        {
            get { return this.IsReaderClosed; }
        }

        public bool NextResult()
        {
            bool l_NextAvailable = true;
            if (this.IsReaderClosed)
            {
                l_NextAvailable = false;
            }
            else
            {
                if (this.CurrentIndex < 0)
                {
                    this.CurrentIndex = this.StartIndex;
                }
                else
                {
                    this.CurrentIndex++;
                }
                if (this.CurrentIndex > this.EndIndex)
                {
                    l_NextAvailable = false;
                    this.CurrentIndex = this.EndIndex;
                    this.IsReaderClosed = true;
                }
                else
                {
                    l_NextAvailable = true;
                }
            }
            return l_NextAvailable;
        }

        public bool Read()
        {
            return this.NextResult();
        }

        public int RecordsAffected
        {
            get { return -1; }
        }

        public void Dispose()
        {

        }

        public int FieldCount
        {
            get { return this.GetSchemaTable().Columns.Count; }
        }

        public bool GetBoolean(int i)
        {
            return (bool)this.GetDataValue(this.CurrentIndex, i);
        }

        public byte GetByte(int i)
        {
            throw new NotImplementedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public char GetChar(int i)
        {
            return (char)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotImplementedException();
        }

        public string GetDataTypeName(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i).GetType().ToString();
        }

        public DateTime GetDateTime(int i)
        {
            return (DateTime)this.GetDataValue(this.CurrentIndex, i);
        }

        public decimal GetDecimal(int i)
        {
            return (decimal)this.GetDataValue(this.CurrentIndex, i);
        }

        public double GetDouble(int i)
        {
            return (double)this.GetDataValue(this.CurrentIndex, i);
        }

        public Type GetFieldType(int i)
        {
            return this.GetSchemaTable().Columns[i].DataType;
        }

        public float GetFloat(int i)
        {
            return (float)this.GetDataValue(this.CurrentIndex, i);
        }

        public Guid GetGuid(int i)
        {
            return (Guid)this.GetDataValue(this.CurrentIndex, i);
        }

        public short GetInt16(int i)
        {
            return (short)this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetInt32(int i)
        {
            return (int)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetInt64(int i)
        {
            return (long)this.GetDataValue(this.CurrentIndex, i);
        }

        public string GetName(int i)
        {
            return this.GetSchemaTable().Columns[i].ColumnName;
        }

        public string GetString(int i)
        {
            return (string)this.GetDataValue(this.CurrentIndex, i);
        }

        public object GetValue(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetValues(object[] values)
        {
            throw new NotImplementedException();
        }

        public bool IsDBNull(int i)
        {
            return (this.GetDataValue(this.CurrentIndex, i) == null);
        }

        public object this[string name]
        {
            get
            {
                int l_ColIndex = -1;
                Object l_Value = null;
                if ((l_ColIndex = this.GetSchemaTable().Columns.IndexOf(name)) >= 0)
                {
                    l_Value = this.GetDataValue(this.CurrentIndex, l_ColIndex);
                }
                return l_Value;
            }
        }

        public object this[int i]
        {
            get { return this.GetDataValue(this.CurrentIndex, i); }
        }
        # endregion

    }
}
