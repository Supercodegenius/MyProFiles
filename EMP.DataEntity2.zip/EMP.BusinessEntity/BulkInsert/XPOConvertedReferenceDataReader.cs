﻿

# region Using Directive
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
# endregion

/// <summary>
/// DataReader used to bulk save the EMP Converted Locations
/// </summary>
namespace EMP.BusinessEntity.BulkInsert
{
    public class XPOConvertedReferenceDataReader : IDataReader
    {
        public DataTable m_SchemaTable = null;

        # region Columns
        //new columns
        public const string C_SQL_INSERT_XPO_COUNTRY_LOOKUP_GUID = "xpo_country_lookup_guid";
        public const string C_SQL_INSERT_LOCATION = "location";
        public const string C_SQL_INSERT_MAPPED_COUNTRY = "mapped_country";
        public const string C_SQL_INSERT_VALIDATED_DATE = "validated_date";
        public const string C_SQL_INSERT_REF_VERSION = "ref_version";
        public const string C_SQL_INSERT_MODIFYDT = "modify_dt";
        public const string C_SQL_INSERT_MODIFYBY = "modify_by";
        public const string C_SQL_INSERT_ADDEDDT = "added_dt";
        public const string C_SQL_INSERT_ADDEDBY = "added_by";
        public const string C_SQL_INSERT_VERSION = "version";
        public const string C_SQL_INSERT_ADDEDAPP = "added_app";
        public const string C_SQL_INSERT_MODIFYAPP = "modify_app";

        #endregion

        #region Constructor
        public XPOConvertedReferenceDataReader()
            : base()
        {
            this.IsReaderClosed = false;
            this.CurrentIndex = -1;
            this.GetSchemaTable();
        }

        public XPOConvertedReferenceDataReader(
            List<XPOCountryLookupBE> argSourceData,
            int argStartIndex,
            int argEndIndex,
            string argTableName)
            : this()
        {
            this.SourceData = argSourceData;
            this.StartIndex = argStartIndex;
            this.EndIndex = argEndIndex;
            this.TableName = argTableName;
        }
        # endregion

        public int GetOrdinal(string name)
        {
            return this.GetSchemaTable().Columns.IndexOf(name);
        }

        # region Schema information
        private Object GetDataValue(int argRow, int argCol)
        {            
            switch (argCol)
            {
                //case 0:
                //    return this.SourceData[argRow].xpo_country_lookup_guid;
                case 1:
                    //return this.SourceData[argRow].location;
                    return this.SetValueFromSourceData(C_SQL_INSERT_LOCATION, 250, argRow);
                case 2:
                    return this.SourceData[argRow].mapped_country;
                case 3:
                    return this.SourceData[argRow].validated_date;
                
                case 4:
                    return this.SourceData[argRow].ModifyDt;
                case 5:
                    return this.SetValueFromSourceData("ModifyBy", 40, argRow);
                case 6:
                    return this.SetValueFromSourceData("ModifyApp", 50, argRow);
                case 7:
                    return this.SourceData[argRow].AddedDt;
                case 8:
                    return this.SetValueFromSourceData("AddedBy", 40, argRow);
                case 9:
                    return this.SetValueFromSourceData("AddedApp", 40, argRow);
                case 10:
                    return this.SourceData[argRow].Version;
                case 11:
                    return this.SourceData[argRow].ref_version;
                default:
                    throw new InvalidOperationException("Column index out of range: " + argCol);
            }
        }

        private Object SetValueFromSourceData(string argField, int argLength,int argRow)
        {
            var property = this.SourceData[argRow].GetType().GetProperty(argField);

          
            if (property != null && property.GetValue(this.SourceData[argRow])!=null && property.GetValue(this.SourceData[argRow]).ToString().Length > argLength)
            {
                return property.GetValue(this.SourceData[argRow]).ToString().Substring(0, argLength);
            }
            else
            {
                return Convert.ToString(property.GetValue(this.SourceData[argRow]));
            }
        }

        public DataTable GetSchemaTable()
        {
            if (this.m_SchemaTable == null)
            {
                m_SchemaTable = new DataTable(this.TableName);

                m_SchemaTable.Columns.Add(C_SQL_INSERT_XPO_COUNTRY_LOOKUP_GUID, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LOCATION, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MAPPED_COUNTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_VALIDATED_DATE, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_VERSION, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_REF_VERSION, typeof(int));
            }
            return m_SchemaTable;
        }

        public void CreateBulkCopyMappings(SqlBulkCopy argSqlBulkCopy)
        {
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("xpo_country_lookup_guid", "xpo_country_lookup_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("location", "location"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("mapped_country", "mapped_country"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("validated_date", "validated_date"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_dt", "modify_dt"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_by", "modify_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_app", "modify_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_dt", "added_dt"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_by", "added_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_app", "added_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("version", "version"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ref_version", "ref_version"));

        }
        # endregion

        # region Other methods
        public List<XPOCountryLookupBE> SourceData
        {
            get;
            set;
        }
        public string TableName
        {
            get;
            set;
        }

        public int StartIndex
        {
            get;
            set;
        }

        public int EndIndex
        {
            get;
            set;
        }

        public int CurrentIndex
        {
            get;
            set;
        }

        private bool IsReaderClosed
        {
            get;
            set;
        }

        public void Close()
        {
            this.IsReaderClosed = true;
        }

        public int Depth
        {
            get { return 0; }
        }

        public bool IsClosed
        {
            get { return this.IsReaderClosed; }
        }

        public bool NextResult()
        {
            bool l_NextAvailable = true;
            if (this.IsReaderClosed)
            {
                l_NextAvailable = false;
            }
            else
            {
                if (this.CurrentIndex < 0)
                {
                    this.CurrentIndex = this.StartIndex;
                }
                else
                {
                    this.CurrentIndex++;
                }
                if (this.CurrentIndex > this.EndIndex)
                {
                    l_NextAvailable = false;
                    this.CurrentIndex = this.EndIndex;
                    this.IsReaderClosed = true;
                }
                else
                {
                    l_NextAvailable = true;
                }
            }
            return l_NextAvailable;
        }

        public bool Read()
        {
            return this.NextResult();
        }

        public int RecordsAffected
        {
            get { return -1; }
        }

        public void Dispose()
        {

        }

        public int FieldCount
        {
            get { return this.GetSchemaTable().Columns.Count; }
        }

        public bool GetBoolean(int i)
        {
            return (bool)this.GetDataValue(this.CurrentIndex, i);
        }

        public byte GetByte(int i)
        {
            throw new NotImplementedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public char GetChar(int i)
        {
            return (char)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotImplementedException();
        }

        public string GetDataTypeName(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i).GetType().ToString();
        }

        public DateTime GetDateTime(int i)
        {
            return (DateTime)this.GetDataValue(this.CurrentIndex, i);
        }

        public decimal GetDecimal(int i)
        {
            return (decimal)this.GetDataValue(this.CurrentIndex, i);
        }

        public double GetDouble(int i)
        {
            return (double)this.GetDataValue(this.CurrentIndex, i);
        }

        public Type GetFieldType(int i)
        {
            return this.GetSchemaTable().Columns[i].DataType;
        }

        public float GetFloat(int i)
        {
            return (float)this.GetDataValue(this.CurrentIndex, i);
        }

        public Guid GetGuid(int i)
        {
            return (Guid)this.GetDataValue(this.CurrentIndex, i);
        }

        public short GetInt16(int i)
        {
            return (short)this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetInt32(int i)
        {
            return (int)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetInt64(int i)
        {
            return (long)this.GetDataValue(this.CurrentIndex, i);
        }

        public string GetName(int i)
        {
            return this.GetSchemaTable().Columns[i].ColumnName;
        }

        public string GetString(int i)
        {
            return (string)this.GetDataValue(this.CurrentIndex, i);
        }

        public object GetValue(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetValues(object[] values)
        {
            throw new NotImplementedException();
        }

        public bool IsDBNull(int i)
        {
            return (this.GetDataValue(this.CurrentIndex, i) == null);
        }

        public object this[string name]
        {
            get
            {
                int l_ColIndex = -1;
                Object l_Value = null;
                if ((l_ColIndex = this.GetSchemaTable().Columns.IndexOf(name)) >= 0)
                {
                    l_Value = this.GetDataValue(this.CurrentIndex, l_ColIndex);
                }
                return l_Value;
            }
        }

        public object this[int i]
        {
            get { return this.GetDataValue(this.CurrentIndex, i); }
        }
        # endregion

    }
}
