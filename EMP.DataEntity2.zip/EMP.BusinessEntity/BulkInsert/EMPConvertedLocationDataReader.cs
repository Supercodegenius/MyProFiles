﻿#region revs/comments
/****************************************************************************************************************************************
 * 1. Class Name            :   EMPConvertedLocationDataReader 
 * 2. Description           :   This class file represents the EMPConvertedLocation DataReader for bulk insert
 * 3. Modification Log      :
 * ----------------------------------------------------------------------------------------------------------------
 * Date (mm/dd/yyyy)        Author              Request No              	Description
 * ----------------------------------------------------------------------------------------------------------------
 *  06/02/2020				Bavisha                                         Created the Inital version
 * *************************************************************************************************************************************/
#endregion

# region Using Directive
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
# endregion

/// <summary>
/// DataReader used to bulk save the EMP Converted Locations
/// </summary>
namespace EMP.BusinessEntity.BulkInsert
{
    public class EMPConvertedLocationDataReader : IDataReader
    {
        public DataTable m_SchemaTable = null;

        # region Columns
        //new columns
        public const string C_SQL_INSERT_EMT_INSURANCE_GUID = "emt_insurance_guid";
        public const string C_SQL_INSERT_EMT_INSURANCE_COMPANY_GUID = "emt_insurance_company_guid";
        public const string C_SQL_INSERT_EMT_SPREADSHEET_GUID = "emt_spreadsheet_guid";
        public const string C_SQL_INSERT_EMT_REINSURANCE_PROGRAM_GUID = "emt_reinsurance_program_guid";
        public const string C_SQL_INSERT_ORIGINAL_NAME = "NAMEDINSURED";
        public const string C_SQL_INSERT_TICKER_SYMBOL = "TICKERSYMBOL";
        public const string C_SQL_INSERT_SAVED_NAME = "saved_name";
        public const string C_SQL_INSERT_EXCHANGE = "EXCHANGE";
        public const string C_SQL_INSERT_CLASS_DESC = "COVERAGE";
        public const string C_SQL_INSERT_LOCATION = "LOCATION";
        public const string C_SQL_INSERT_CONFORMEDCOUNTRY = "conformed_country";
        public const string C_SQL_INSERT_CLASS_GUID = "class_guid";
        public const string C_SQL_INSERT_Limit = "LIMIT";
        public const string C_SQL_INSERT_EXCESS_AMT = "ATTACHMENTPOINT";
        public const string C_SQL_INSERT_SHARE = "SHARE";
        public const string C_SQL_INSERT_EFFECTIVE_DATE = "EFFECTIVEDATE";
        public const string C_SQL_INSERT_EXPIRY_DATE = "EXPIRYDATE";
        public const string C_SQL_INSERT_PREMIUM = "PREMIUM";
        public const string C_SQL_INSERT_TREATY_EXPOSURE_AMT = "POLICYEXPOSURE";
        public const string C_SQL_INSERT_TREATY_EXPOSURE_BASE = "EXPOSUREBASE";
        public const string C_SQL_INSERT_EXPOSURE_COUNT = "EXPOSURECOUNT";
        public const string C_SQL_INSERT_INDUSTRY_DESC = "INDUSTRY";
        public const string C_SQL_INSERT_CONFORMED_INDUSTRY = "conformed_industry";
        public const string C_SQL_INSERT_CIQ = "ciq";
        public const string C_SQL_INSERT_PREDICT = "predict";
        public const string C_SQL_INSERT_LIKELIHOOD = "likelihood";
        public const string C_SQL_INSERT_CURR_GUID = "CURRENCY";
        public const string C_SQL_INSERT_MODIFYDT = "modify_dt";
        public const string C_SQL_INSERT_MODIFYBY = "modify_by";
        public const string C_SQL_INSERT_ADDEDDT = "added_dt";
        public const string C_SQL_INSERT_ADDEDBY = "added_by";
        public const string C_SQL_INSERT_DELETEDIND = "deleted_ind";
        public const string C_SQL_INSERT_VERSION = "version";
        public const string C_SQL_INSERT_ADDEDAPP = "added_app";
        public const string C_SQL_INSERT_MODIFYAPP = "modify_app";
        public const string C_SQL_INSERT_OLDER_NAME = "older_name";
        public const string C_SQL_INSERT_POLICY_PART_OF_LIMIT = "POLICYPARTOFLIMIT";
        public const string C_SQL_INSERT_INDUSTRY_CODE = "INDUSTRYCODE";
        public const string C_SQL_INSERT_ORIGINAL_REFERENCE = "ORIGINALREFERENCE";
        public const string C_SQL_INSERT_BASIS_OF_COVER = "BASISOFCOVER";
        public const string C_SQL_INSERT_PRIMARY_EXCESS = "PRIMARYEXCESS";
        public const string C_SQL_INSERT_POLICY_COVER_BASIS = "POLICYCOVERBASIS";
        public const string C_SQL_INSERT_ADDITIONAL_DATA1 = "ADDITIONALDATA1";
        public const string C_SQL_INSERT_ADDITIONAL_DATA2 = "ADDITIONALDATA2";
        public const string C_SQL_INSERT_ADDITIONAL_DATA3 = "ADDITIONALDATA3";
        public const string C_SQL_INSERT_ADDITIONAL_DATA4 = "ADDITIONALDATA4";
        public const string C_SQL_INSERT_ADDITIONAL_DATA5 = "ADDITIONALDATA5";
        public const string C_SQL_INSERT_TREATY_CURRENCY = "TREATYCURRENCY";
        public const string C_SQL_INSERT_TREATY_LIMIT = "TREATYLIMIT";
        public const string C_SQL_INSERT_TREATY_EXCESS_AMT = "TREATYATTACHMENTPOINT";
        public const string C_SQL_INSERT_TREATY_PREMIUM = "TREATYPREMIUM";
        public const string C_SQL_INSERT_SICS_SEARCHED = "sics_searched";
        public const string C_SQL_INSERT_FAC_SHARE_PCT = "Fac_Share_pct";
        public const string C_SQL_INSERT_OTHER_CEDANTS_PCT = "Other_Cedants_pct";
        public const string C_SQL_INSERT_Industry_Code_Type = "INDUSTRYCODETYPE";
        public const string C_SQL_INSERT_Year = "YEAR";
        public const string C_SQL_INSERT_ADDITIONAL_DATA6 = "ADDITIONALDATA6";
        public const string C_SQL_INSERT_ADDITIONAL_DATA7 = "ADDITIONALDATA7";
        public const string C_SQL_INSERT_ADDITIONAL_DATA8 = "ADDITIONALDATA8";
        public const string C_SQL_INSERT_ADDITIONAL_DATA9 = "ADDITIONALDATA9";
        public const string C_SQL_INSERT_ADDITIONAL_DATA10 = "ADDITIONALDATA10";
        public const string C_SQL_INSERT_ADDITIONAL_DATA11 = "ADDITIONALDATA11";
        public const string C_SQL_INSERT_ADDITIONAL_DATA12 = "ADDITIONALDATA12";
        public const string C_SQL_INSERT_ADDITIONAL_DATA13 = "ADDITIONALDATA13";
        public const string C_SQL_INSERT_ADDITIONAL_DATA14 = "ADDITIONALDATA14";
        public const string C_SQL_INSERT_ADDITIONAL_DATA15 = "ADDITIONALDATA15";
        public const string C_SQL_INSERT_ADDITIONAL_DATA16 = "ADDITIONALDATA16";
        public const string C_SQL_INSERT_ADDITIONAL_DATA17 = "ADDITIONALDATA17";
        public const string C_SQL_INSERT_ADDITIONAL_DATA18 = "ADDITIONALDATA18";
        public const string C_SQL_INSERT_ADDITIONAL_DATA19 = "ADDITIONALDATA19";
        public const string C_SQL_INSERT_ADDITIONAL_DATA20 = "ADDITIONALDATA20";
        public const string C_SQL_INSERT_EMP_FILEPROCESSINGTASK_GUID = "emp_fileprocessingtask_guid";
        public const string C_SQL_INSERT_PROGRAMGUID = "PROGRAMGUID";

        public const string C_SQL_INSERT_Location1 = "LOCATION1";
        public const string C_SQL_INSERT_Location2 = "LOCATION2";
        public const string C_SQL_INSERT_Industry1 = "INDUSTRY1";
        public const string C_SQL_INSERT_Industry2 = "INDUSTRY2";
        public const string C_SQL_INSERT_PolicyID = "POLICYID";
        public const string C_SQL_INSERT_StackingID = "STACKINGID";
        public const string C_SQL_INSERT_Revenue = "REVENUE";
        public const string C_SQL_INSERT_EmployeeCount = "EMPLOYEECOUNT";
        public const string C_SQL_INSERT_AssetType = "ASSETTYPE";
        public const string C_SQL_INSERT_ClarksonID = "CLARKSONID";
        public const string C_SQL_INSERT_Latitude = "LATITUDE";
        public const string C_SQL_INSERT_Longitude = "LONGITUDE";
        public const string C_SQL_INSERT_Interest = "INTEREST";

        // new code //
        public const string C_SQL_INSERT_Area = "AREA";
        public const string C_SQL_INSERT_Complex = "COMPLEX";
        public const string C_SQL_INSERT_Field = "FIELD";
        public const string C_SQL_INSERT_Platform = "PLATFORM";
        public const string C_SQL_INSERT_Object_id = "object_id";
        public const string C_SQL_INSERT_ORIGINALCOVERAGE = "ORIGINALCOVERAGE";
        //end New code 

        //Aviation Columns
        public const string C_SQL_INSERT_SCHEDULE = "SCHEDULE";
        public const string C_SQL_INSERT_INCEPTION = "INCEPTION";
        public const string C_SQL_INSERT_HCCY = "HCCY";
        public const string C_SQL_INSERT_HLIMIT = "HLIMIT";
        public const string C_SQL_INSERT_HEXCESS = "HEXCESS";
        public const string C_SQL_INSERT_Hull_CLI_PCT_LINE = "Hull_CLI_PCT_LINE";
        public const string C_SQL_INSERT_LIA_CCY = "LIA_CCY";
        public const string C_SQL_INSERT_LIA_LIMIT = "LIA_LIMIT";
        public const string C_SQL_INSERT_LIA_EXCESS = "LIA_EXCESS";
        public const string C_SQL_INSERT_Lia_CLI_PCT_LINE = "Lia_CLI_PCT_LINE";
        public const string C_SQL_INSERT_US_REG_LINE_OBLIGATION = "US_REG_LINE_OBLIGATION";
        public const string C_SQL_INSERT_AVN52_CCY = "AVN52_CCY";
        public const string C_SQL_INSERT_PRIMARY_AVN52_SUB_LIMIT = "PRIMARY_AVN52_SUB_LIMIT";
        public const string C_SQL_INSERT_GROUNDING_CCY = "GROUNDING_CCY";
        public const string C_SQL_INSERT_GROUNDING_LIA_SUB_LIMIT = "GROUNDING_LIA_SUB_LIMIT";

        //End Aviation Columns

        #endregion

        #region Constructor
        public EMPConvertedLocationDataReader()
            : base()
        {
            this.IsReaderClosed = false;
            this.CurrentIndex = -1;
            this.GetSchemaTable();
        }

        public EMPConvertedLocationDataReader(
            List<RMSConvertedDataBE> argSourceData,
            int argStartIndex,
            int argEndIndex,
            string argTableName)
            : this()
        {
            this.SourceData = argSourceData;
            this.StartIndex = argStartIndex;
            this.EndIndex = argEndIndex;
            this.TableName = argTableName;
        }
        # endregion

        public int GetOrdinal(string name)
        {
            return this.GetSchemaTable().Columns.IndexOf(name);
        }

        # region Schema information
        private Object GetDataValue(int argRow, int argCol)
        {
            switch (argCol)
            {
                case 0:
                    return this.SourceData[argRow].emt_insurance_guid;
                case 1:
                    return this.SourceData[argRow].emt_insurance_company_guid;
                case 2:
                    return this.SourceData[argRow].emt_spreadsheet_guid;
                case 3:
                    return this.SourceData[argRow].emt_reinsurance_program_guid;
                case 4:
                    return this.SetValueFromSourceData(C_SQL_INSERT_TICKER_SYMBOL, 10, argRow);
                case 5:
                    return this.SetValueFromSourceData(C_SQL_INSERT_EXCHANGE, 50, argRow);
                case 6:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ORIGINAL_NAME, 350, argRow); ;
                case 7:
                    return this.SetValueFromSourceData(C_SQL_INSERT_SAVED_NAME, 350, argRow);
                case 8:
                    return this.SetValueFromSourceData(C_SQL_INSERT_LOCATION, 250, argRow);
                case 9:
                    return this.SetValueFromSourceData(C_SQL_INSERT_CONFORMEDCOUNTRY, 250, argRow);
                case 10:
                    return this.SourceData[argRow].class_guid;
                case 11:
                    return this.SetValueFromSourceData(C_SQL_INSERT_CLASS_DESC, 50, argRow);
                case 12:
                    return this.SourceData[argRow].LIMIT;
                case 13:
                    return this.SourceData[argRow].ATTACHMENTPOINT;
                case 14:
                    return this.SourceData[argRow].SHARE;
                case 15:
                    return this.SourceData[argRow].EFFECTIVEDATE;
                case 16:
                    return this.SourceData[argRow].EXPIRYDATE;
                case 17:
                    return this.SourceData[argRow].PREMIUM;
                case 18:
                    return this.SourceData[argRow].POLICYEXPOSURE;
                case 19:
                    return this.SetValueFromSourceData(C_SQL_INSERT_TREATY_EXPOSURE_BASE, 50, argRow);
                case 20:
                    return this.SourceData[argRow].EXPOSURECOUNT;
                case 21:
                    return this.SetValueFromSourceData(C_SQL_INSERT_INDUSTRY_DESC, 100, argRow);
                case 22:
                    return this.SetValueFromSourceData(C_SQL_INSERT_CONFORMED_INDUSTRY, 100, argRow);
                case 23:
                    return this.SetValueFromSourceData(C_SQL_INSERT_CIQ, 100, argRow);
                case 24:
                    return this.SetValueFromSourceData(C_SQL_INSERT_PREDICT, 100, argRow);
                case 25:
                    return this.SetValueFromSourceData(C_SQL_INSERT_LIKELIHOOD, 100, argRow);
                case 26:
                    return this.SourceData[argRow].CURRENCY;
                case 27:
                    return this.SourceData[argRow].ModifyDt;
                case 28:
                    return this.SetValueFromSourceData("ModifyBy", 40, argRow);
                case 29:
                    return this.SourceData[argRow].AddedDt;
                case 30:
                    return this.SetValueFromSourceData("AddedBy", 40, argRow);
                case 31:
                    return this.SourceData[argRow].Deleted_Ind;
                case 32:
                    return this.SourceData[argRow].Version;
                case 33:
                    return this.SetValueFromSourceData("AddedApp", 40, argRow);
                case 34:
                    return this.SetValueFromSourceData("ModifyApp", 50, argRow);
                case 35:
                    return this.SetValueFromSourceData(C_SQL_INSERT_OLDER_NAME, 350, argRow);
                case 36:
                    return this.SourceData[argRow].POLICYPARTOFLIMIT;
                case 37:
                    return this.SetValueFromSourceData(C_SQL_INSERT_INDUSTRY_CODE, 10, argRow);
                case 38:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ORIGINAL_REFERENCE, 250, argRow);
                case 39:
                    return this.SetValueFromSourceData(C_SQL_INSERT_BASIS_OF_COVER, 75, argRow);
                case 40:
                    return this.SetValueFromSourceData(C_SQL_INSERT_PRIMARY_EXCESS, 25, argRow);
                case 41:
                    return this.SetValueFromSourceData(C_SQL_INSERT_POLICY_COVER_BASIS, 75, argRow);
                case 42:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA1, 500, argRow);
                case 43:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA2, 500, argRow);
                case 44:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA3, 500, argRow);
                case 45:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA4, 500, argRow);
                case 46:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA5, 500, argRow);
                case 47:
                    return this.SetValueFromSourceData(C_SQL_INSERT_TREATY_CURRENCY, 3, argRow);
                case 48:
                    return this.SourceData[argRow].TREATYLIMIT;
                case 49:
                    return this.SourceData[argRow].TREATYATTACHMENTPOINT;
                case 50:
                    return this.SourceData[argRow].TREATYPREMIUM;
                case 51:
                    return this.SourceData[argRow].sics_searched;
                case 52:
                    return this.SourceData[argRow].Fac_Share_pct;
                case 53:
                    return this.SourceData[argRow].Other_Cedants_pct;
                case 54:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Industry_Code_Type, 10, argRow);
                case 55:
                    return this.SourceData[argRow].YEAR;
                case 56:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA6, 500, argRow);
                case 57:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA7, 500, argRow);
                case 58:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA8, 500, argRow);
                case 59:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA9, 500, argRow);
                case 60:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA10, 500, argRow);
                case 61:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA11, 500, argRow);
                //case 62:
                // return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA11, 500, argRow);  // X138892 - Commented this duplicate and renamed next case # sequences to fix save issue for new new columns.
                case 62:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA12, 500, argRow);
                case 63:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA13, 500, argRow);
                case 64:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA14, 500, argRow);
                case 65:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA15, 500, argRow);
                case 66:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA16, 500, argRow);
                case 67:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA17, 500, argRow);
                case 68:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA18, 500, argRow);
                case 69:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA19, 500, argRow);
                case 70:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ADDITIONAL_DATA20, 500, argRow);
                case 71:
                    return this.SourceData[argRow].Emp_fileprocessingtask_guid;
                case 72:
                    return this.SourceData[argRow].PROGRAMGUID;
                case 73:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Location1, 500, argRow);
                case 74:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Location2, 500, argRow);
                case 75:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Industry1, 500, argRow);
                case 76:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Industry2, 500, argRow);
                case 77:
                    return this.SetValueFromSourceData(C_SQL_INSERT_PolicyID, 500, argRow);
                case 78:
                    return this.SetValueFromSourceData(C_SQL_INSERT_StackingID, 500, argRow);
                case 79:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Revenue, 500, argRow);
                case 80:
                    //return this.SourceData[argRow].EmployeeCount;
                    return this.SetValueFromSourceData(C_SQL_INSERT_EmployeeCount, 500, argRow);
                case 81:
                    return this.SetValueFromSourceData(C_SQL_INSERT_AssetType, 500, argRow);
                case 82:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ClarksonID, 500, argRow);
                case 83:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Latitude, 500, argRow);
                case 84:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Longitude, 500, argRow);
                case 85:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Interest, 500, argRow);

                // new code //
                case 86:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Area, 500, argRow);
                case 87:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Platform, 500, argRow);
                case 88:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Complex, 500, argRow);
                case 89:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Field, 500, argRow);
                case 90:
                    return this.SetValueFromSourceData(C_SQL_INSERT_Object_id, 50, argRow);
                case 91:
                    return this.SetValueFromSourceData(C_SQL_INSERT_ORIGINALCOVERAGE, 250, argRow);

              // end new code

                // Aviation code
                case 92:
                    return this.SetValueFromSourceData(C_SQL_INSERT_SCHEDULE, 1, argRow);
                case 93:
                    return this.SourceData[argRow].INCEPTION;
                case 94:
                   return this.SourceData[argRow].HCCY;
                case 95:
                    return this.SourceData[argRow].HLIMIT;
                case 96:
                    return this.SourceData[argRow].HEXCESS;
                case 97:
                    return this.SourceData[argRow].Hull_CLI_PCT_LINE;
                case 98:
                    return this.SourceData[argRow].LIA_CCY;
                case 99:
                    return this.SourceData[argRow].LIA_LIMIT;
                case 100:
                    return this.SourceData[argRow].LIA_EXCESS;
                case 101:
                    return this.SourceData[argRow].Lia_CLI_PCT_LINE;
                case 102:
                    return this.SetValueFromSourceData(C_SQL_INSERT_US_REG_LINE_OBLIGATION, 120, argRow);
                case 103:
                    return this.SourceData[argRow].AVN52_CCY;
                case 104:
                    return this.SourceData[argRow].PRIMARY_AVN52_SUB_LIMIT;
                case 105:
                    return this.SourceData[argRow].GROUNDING_CCY;
                case 106:
                    return this.SourceData[argRow].GROUNDING_LIA_SUB_LIMIT;
                // End Aviation code


                default:
                    throw new InvalidOperationException("Column index out of range: " + argCol);
            }
        }

        private Object SetValueFromSourceData(string argField, int argLength, int argRow)
        {
            var property = this.SourceData[argRow].GetType().GetProperty(argField);


            if (property != null && property.GetValue(this.SourceData[argRow]) != null && property.GetValue(this.SourceData[argRow]).ToString().Length > argLength)
            {
                return property.GetValue(this.SourceData[argRow]).ToString().Substring(0, argLength);
            }
            else
            {
                return Convert.ToString(property.GetValue(this.SourceData[argRow]));
            }
        }

        public DataTable GetSchemaTable()
        {
            if (this.m_SchemaTable == null)
            {
                m_SchemaTable = new DataTable(this.TableName);

                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMT_INSURANCE_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMT_INSURANCE_COMPANY_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMT_SPREADSHEET_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMT_REINSURANCE_PROGRAM_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TICKER_SYMBOL, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EXCHANGE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINAL_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SAVED_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LOCATION, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CONFORMEDCOUNTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CLASS_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CLASS_DESC, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Limit, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EXCESS_AMT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SHARE, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EFFECTIVE_DATE, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EXPIRY_DATE, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PREMIUM, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_EXPOSURE_AMT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_EXPOSURE_BASE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EXPOSURE_COUNT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_INDUSTRY_DESC, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CONFORMED_INDUSTRY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CIQ, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PREDICT, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIKELIHOOD, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CURR_GUID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDDT, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDBY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_DELETEDIND, typeof(bool));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_VERSION, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDEDAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_MODIFYAPP, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_OLDER_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_POLICY_PART_OF_LIMIT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_INDUSTRY_CODE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINAL_REFERENCE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_BASIS_OF_COVER, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PRIMARY_EXCESS, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_POLICY_COVER_BASIS, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA1, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA2, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA3, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA4, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA5, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_CURRENCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_LIMIT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_EXCESS_AMT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TREATY_PREMIUM, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SICS_SEARCHED, typeof(bool));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_FAC_SHARE_PCT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_OTHER_CEDANTS_PCT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Industry_Code_Type, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Year, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA6, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA7, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA8, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA9, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA10, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA11, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA12, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA13, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA14, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA15, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA16, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA17, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA18, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA19, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ADDITIONAL_DATA20, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMP_FILEPROCESSINGTASK_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PROGRAMGUID, typeof(int));

                m_SchemaTable.Columns.Add(C_SQL_INSERT_Location1, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Location2, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Industry1, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Industry2, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PolicyID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_StackingID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Revenue, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EmployeeCount, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_AssetType, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ClarksonID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Latitude, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Longitude, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Interest, typeof(string));

                // new code //
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Area, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Platform, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Complex, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Field, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Object_id, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ORIGINALCOVERAGE, typeof(string));
                //end new code 

                //Aviation columns
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SCHEDULE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_INCEPTION, typeof(DateTime));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_HCCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_HLIMIT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_HEXCESS, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Hull_CLI_PCT_LINE, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIA_CCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIA_LIMIT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIA_EXCESS, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_Lia_CLI_PCT_LINE, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_US_REG_LINE_OBLIGATION, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_AVN52_CCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PRIMARY_AVN52_SUB_LIMIT, typeof(double));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_GROUNDING_CCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_GROUNDING_LIA_SUB_LIMIT, typeof(double));
                //end Aviation columns



            }
            return m_SchemaTable;
        }

        public void CreateBulkCopyMappings(SqlBulkCopy argSqlBulkCopy)
        {
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("emt_insurance_guid", "emt_insurance_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("emt_insurance_company_guid", "emt_insurance_company_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("emt_spreadsheet_guid", "emt_spreadsheet_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("emt_reinsurance_program_guid", "emt_reinsurance_program_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("TICKERSYMBOL", "TICKERSYMBOL"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EXCHANGE", "EXCHANGE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("NAMEDINSURED", "NAMEDINSURED"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("saved_name", "saved_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LOCATION", "LOCATION"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("conformed_country", "conformed_country"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("class_guid", "class_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("COVERAGE", "COVERAGE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LIMIT", "LIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ATTACHMENTPOINT", "ATTACHMENTPOINT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("SHARE", "SHARE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EFFECTIVEDATE", "EFFECTIVEDATE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EXPIRYDATE", "EXPIRYDATE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("PREMIUM", "PREMIUM"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("POLICYEXPOSURE", "POLICYEXPOSURE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EXPOSUREBASE", "EXPOSUREBASE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EXPOSURECOUNT", "EXPOSURECOUNT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INDUSTRY", "INDUSTRY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("conformed_industry", "conformed_industry"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ciq", "ciq"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("predict", "predict"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("likelihood", "likelihood"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("CURRENCY", "CURRENCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_dt", "modify_dt"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_by", "modify_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_dt", "added_dt"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_by", "added_by"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("deleted_ind", "deleted_ind"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("version", "version"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("added_app", "added_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("modify_app", "modify_app"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("older_name", "older_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("POLICYPARTOFLIMIT", "POLICYPARTOFLIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INDUSTRYCODE", "INDUSTRYCODE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ORIGINALREFERENCE", "ORIGINALREFERENCE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("BASISOFCOVER", "BASISOFCOVER"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("PRIMARYEXCESS", "PRIMARYEXCESS"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("POLICYCOVERBASIS", "POLICYCOVERBASIS"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA1", "ADDITIONALDATA1"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA2", "ADDITIONALDATA2"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA3", "ADDITIONALDATA3"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA4", "ADDITIONALDATA4"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA5", "ADDITIONALDATA5"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("TREATYCURRENCY", "TREATYCURRENCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("TREATYLIMIT", "TREATYLIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("TREATYATTACHMENTPOINT", "TREATYATTACHMENTPOINT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("TREATYPREMIUM", "TREATYPREMIUM"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("sics_searched", "sics_searched"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("Fac_Share_pct", "Fac_Share_pct"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("Other_Cedants_pct", "Other_Cedants_pct"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INDUSTRYCODETYPE", "INDUSTRYCODETYPE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("YEAR", "YEAR"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA6", "ADDITIONALDATA6"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA7", "ADDITIONALDATA7"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA8", "ADDITIONALDATA8"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA9", "ADDITIONALDATA9"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA10", "ADDITIONALDATA10"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA11", "ADDITIONALDATA11"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA12", "ADDITIONALDATA12"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA13", "ADDITIONALDATA13"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA14", "ADDITIONALDATA14"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA15", "ADDITIONALDATA15"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA16", "ADDITIONALDATA16"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA17", "ADDITIONALDATA17"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA18", "ADDITIONALDATA18"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA19", "ADDITIONALDATA19"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ADDITIONALDATA20", "ADDITIONALDATA20"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("Emp_fileprocessingtask_guid", "emp_fileprocessingtask_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("PROGRAMGUID", "PROGRAMGUID"));

            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LOCATION1", "LOCATION1"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LOCATION2", "LOCATION2"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INDUSTRY1", "INDUSTRY1"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INDUSTRY2", "INDUSTRY2"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("POLICYID", "POLICYID"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("STACKINGID", "STACKINGID"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("REVENUE", "REVENUE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("EMPLOYEECOUNT", "EMPLOYEECOUNT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ASSETTYPE", "ASSETTYPE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("CLARKSONID", "CLARKSONID"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LATITUDE", "LATITUDE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LONGITUDE", "LONGITUDE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INTEREST", "INTEREST"));

            // new code //
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("AREA", "AREA"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("PLATFORM", "PLATFORM"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("COMPLEX", "COMPLEX"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("FIELD", "FIELD"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("object_id", "object_id"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ORIGINALCOVERAGE", "ORIGINALCOVERAGE"));
            //End New code

            //Aviation columns
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("SCHEDULE", "SCHEDULE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("INCEPTION", "INCEPTION"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("HCCY", "HCCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("HLIMIT", "HLIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("HEXCESS", "HEXCESS"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("Hull_CLI_PCT_LINE", "Hull_CLI_PCT_LINE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LIA_CCY", "LIA_CCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LIA_LIMIT", "LIA_LIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LIA_EXCESS", "LIA_EXCESS"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("Lia_CLI_PCT_LINE", "Lia_CLI_PCT_LINE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("US_REG_LINE_OBLIGATION", "US_REG_LINE_OBLIGATION"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("AVN52_CCY", "AVN52_CCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("PRIMARY_AVN52_SUB_LIMIT", "PRIMARY_AVN52_SUB_LIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("GROUNDING_CCY", "GROUNDING_CCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("GROUNDING_LIA_SUB_LIMIT", "GROUNDING_LIA_SUB_LIMIT"));
            //End Aviation columns

        }
        # endregion

        # region Other methods
        public List<RMSConvertedDataBE> SourceData
        {
            get;
            set;
        }
        public string TableName
        {
            get;
            set;
        }

        public int StartIndex
        {
            get;
            set;
        }

        public int EndIndex
        {
            get;
            set;
        }

        public int CurrentIndex
        {
            get;
            set;
        }

        private bool IsReaderClosed
        {
            get;
            set;
        }

        public void Close()
        {
            this.IsReaderClosed = true;
        }

        public int Depth
        {
            get { return 0; }
        }

        public bool IsClosed
        {
            get { return this.IsReaderClosed; }
        }

        public bool NextResult()
        {
            bool l_NextAvailable = true;
            if (this.IsReaderClosed)
            {
                l_NextAvailable = false;
            }
            else
            {
                if (this.CurrentIndex < 0)
                {
                    this.CurrentIndex = this.StartIndex;
                }
                else
                {
                    this.CurrentIndex++;
                }
                if (this.CurrentIndex > this.EndIndex)
                {
                    l_NextAvailable = false;
                    this.CurrentIndex = this.EndIndex;
                    this.IsReaderClosed = true;
                }
                else
                {
                    l_NextAvailable = true;
                }
            }
            return l_NextAvailable;
        }

        public bool Read()
        {
            return this.NextResult();
        }

        public int RecordsAffected
        {
            get { return -1; }
        }

        public void Dispose()
        {

        }

        public int FieldCount
        {
            get { return this.GetSchemaTable().Columns.Count; }
        }

        public bool GetBoolean(int i)
        {
            return (bool)this.GetDataValue(this.CurrentIndex, i);
        }

        public byte GetByte(int i)
        {
            throw new NotImplementedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public char GetChar(int i)
        {
            return (char)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotImplementedException();
        }

        public string GetDataTypeName(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i).GetType().ToString();
        }

        public DateTime GetDateTime(int i)
        {
            return (DateTime)this.GetDataValue(this.CurrentIndex, i);
        }

        public decimal GetDecimal(int i)
        {
            return (decimal)this.GetDataValue(this.CurrentIndex, i);
        }

        public double GetDouble(int i)
        {
            return (double)this.GetDataValue(this.CurrentIndex, i);
        }

        public Type GetFieldType(int i)
        {
            return this.GetSchemaTable().Columns[i].DataType;
        }

        public float GetFloat(int i)
        {
            return (float)this.GetDataValue(this.CurrentIndex, i);
        }

        public Guid GetGuid(int i)
        {
            return (Guid)this.GetDataValue(this.CurrentIndex, i);
        }

        public short GetInt16(int i)
        {
            return (short)this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetInt32(int i)
        {
            return (int)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetInt64(int i)
        {
            return (long)this.GetDataValue(this.CurrentIndex, i);
        }

        public string GetName(int i)
        {
            return this.GetSchemaTable().Columns[i].ColumnName;
        }

        public string GetString(int i)
        {
            return (string)this.GetDataValue(this.CurrentIndex, i);
        }

        public object GetValue(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetValues(object[] values)
        {
            throw new NotImplementedException();
        }

        public bool IsDBNull(int i)
        {
            return (this.GetDataValue(this.CurrentIndex, i) == null);
        }

        public object this[string name]
        {
            get
            {
                int l_ColIndex = -1;
                Object l_Value = null;
                if ((l_ColIndex = this.GetSchemaTable().Columns.IndexOf(name)) >= 0)
                {
                    l_Value = this.GetDataValue(this.CurrentIndex, l_ColIndex);
                }
                return l_Value;
            }
        }

        public object this[int i]
        {
            get { return this.GetDataValue(this.CurrentIndex, i); }
        }
        # endregion

    }
}
