﻿

# region Using Directive
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
# endregion

/// <summary>
/// DataReader used to bulk save the EMP Converted Locations
/// </summary>
namespace EMP.BusinessEntity.BulkInsert
{
    public class XPOTowerMatchDataReader : IDataReader
    {
        public DataTable m_SchemaTable = null;

        #region Columns
        //new columns

        public const string C_SQL_INSERT_ID = "id";
        public const string C_SQL_INSERT_EMT_INSURANCE_GUID = "emt_insurance_guid";
        public const string C_SQL_INSERT_NAMEDINSURED = "NAMEDINSURED";
        public const string C_SQL_INSERT_SAVED_NAME = "saved_name";
        public const string C_SQL_INSERT_COVERAGE = "COVERAGE";
        public const string C_SQL_INSERT_LIMIT = "LIMIT";
        public const string C_SQL_INSERT_ATTACHMENTPOINT = "ATTACHMENTPOINT";
        public const string C_SQL_INSERT_LIMIT_USD = "limit_USD";
        public const string C_SQL_INSERT_AT_USD = "AT_USD";
        public const string C_SQL_INSERT_SHARE = "SHARE";
        public const string C_SQL_INSERT_CURRENCY = "CURRENCY";
        public const string C_SQL_INSERT_TOWER_ID = "tower_id";
        public const string C_SQL_INSERT_FILE_NAME = "file_name";
        public const string C_SQL_INSERT_RISK_COUNT = "risk_count";
        public const string C_SQL_INSERT_PRIMARY_IND = "primary_ind";
        public const string C_SQL_INSERT_P_SAVED_NAME = "p_saved_name";
        public const string C_SQL_INSERT_PLIMIT = "plimit";
        public const string C_SQL_INSERT_PAT = "pat";
        public const string C_SQL_INSERT_P_FILENAME = "p_filename";
        public const string C_SQL_INSERT_PREVSUM = "prevsum";
        public const string C_SQL_INSERT_PRIMARY_TM = "primary_TM";
        public const string C_SQL_INSERT_NONPRIMARY_TM = "nonprimary_TM";
        public const string C_SQL_INSERT_FINAL_TM = "final_TM";

        #endregion

        #region Constructor
        public XPOTowerMatchDataReader()
            : base()
        {
            this.IsReaderClosed = false;
            this.CurrentIndex = -1;
            this.GetSchemaTable();
        }

        public XPOTowerMatchDataReader(
            List<MainStage> argSourceData,
            int argStartIndex,
            int argEndIndex,
            string argTableName)
            : this()
        {
            this.SourceData = argSourceData;
            this.StartIndex = argStartIndex;
            this.EndIndex = argEndIndex;
            this.TableName = argTableName;
        }
        # endregion

        public int GetOrdinal(string name)
        {
            return this.GetSchemaTable().Columns.IndexOf(name);
        }

        # region Schema information
        private Object GetDataValue(int argRow, int argCol)
        {
            switch (argCol)
            {
                //case 0:
                //    return this.SourceData[argRow].xpo_country_lookup_guid;

                case 0:
                    return this.SourceData[argRow].id;
                case 1:
                    return this.SourceData[argRow].emt_insurance_guid;
                case 2:
                    return this.SourceData[argRow].NAMEDINSURED;
                case 3:
                    return this.SourceData[argRow].saved_name;
                case 4:
                    return this.SourceData[argRow].COVERAGE;
                case 5:
                    return this.SourceData[argRow].LIMIT;
                case 6:
                    return this.SourceData[argRow].ATTACHMENTPOINT;
                case 7:
                    return this.SourceData[argRow].limit_USD;
                case 8:
                    return this.SourceData[argRow].AT_USD;
                case 9:
                    return this.SourceData[argRow].SHARE;
                case 10:
                    return this.SourceData[argRow].CURRENCY;
                case 11:
                    return this.SourceData[argRow].tower_id;
                case 12:
                    return this.SourceData[argRow].file_name;
                case 13:
                    return this.SourceData[argRow].risk_count;
                case 14:
                    return this.SourceData[argRow].primary_ind;
                case 15:
                    return this.SourceData[argRow].p_saved_name;
                case 16:
                    return this.SourceData[argRow].plimit;
                case 17:
                    return this.SourceData[argRow].pat;
                case 18:
                    return this.SourceData[argRow].p_filename;
                case 19:
                    return this.SourceData[argRow].prevsum;
                case 20:
                    return this.SourceData[argRow].primary_TM;
                case 21:
                    return this.SourceData[argRow].nonprimary_TM;
                case 22:
                    return this.SourceData[argRow].final_TM;

                default:
                    throw new InvalidOperationException("Column index out of range: " + argCol);
            }
        }

        private Object SetValueFromSourceData(string argField, int argLength, int argRow)
        {
            var property = this.SourceData[argRow].GetType().GetProperty(argField);


            if (property != null && property.GetValue(this.SourceData[argRow]) != null && property.GetValue(this.SourceData[argRow]).ToString().Length > argLength)
            {
                return property.GetValue(this.SourceData[argRow]).ToString().Substring(0, argLength);
            }
            else
            {
                return Convert.ToString(property.GetValue(this.SourceData[argRow]));
            }
        }

        public DataTable GetSchemaTable()
        {
            if (this.m_SchemaTable == null)
            {
                m_SchemaTable = new DataTable(this.TableName);

                m_SchemaTable.Columns.Add(C_SQL_INSERT_ID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_EMT_INSURANCE_GUID, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_NAMEDINSURED, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SAVED_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_COVERAGE, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIMIT, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_ATTACHMENTPOINT, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_LIMIT_USD, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_AT_USD, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_SHARE, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_CURRENCY, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_TOWER_ID, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_FILE_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_RISK_COUNT, typeof(int));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PRIMARY_IND, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_P_SAVED_NAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PLIMIT, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PAT, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_P_FILENAME, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PREVSUM, typeof(long));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_PRIMARY_TM, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_NONPRIMARY_TM, typeof(string));
                m_SchemaTable.Columns.Add(C_SQL_INSERT_FINAL_TM, typeof(string));
            }
            return m_SchemaTable;
        }

        public void CreateBulkCopyMappings(SqlBulkCopy argSqlBulkCopy)
        {
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("id", "id"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("emt_insurance_guid", "emt_insurance_guid"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("NAMEDINSURED", "NAMEDINSURED"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("saved_name", "saved_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("COVERAGE", "COVERAGE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("LIMIT", "LIMIT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("ATTACHMENTPOINT", "ATTACHMENTPOINT"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("limit_USD", "limit_USD"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("AT_USD", "AT_USD"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("SHARE", "SHARE"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("CURRENCY", "CURRENCY"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("tower_id", "tower_id"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("file_name", "file_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("risk_count", "risk_count"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("primary_ind", "primary_ind"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("p_saved_name", "p_saved_name"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("plimit", "plimit"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("pat", "pat"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("p_filename", "p_filename"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("prevsum", "prevsum"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("primary_TM", "primary_TM"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("nonprimary_TM", "nonprimary_TM"));
            argSqlBulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping("final_TM", "final_TM"));

        }
        # endregion

        # region Other methods
        public List<MainStage> SourceData
        {
            get;
            set;
        }
        public string TableName
        {
            get;
            set;
        }

        public int StartIndex
        {
            get;
            set;
        }

        public int EndIndex
        {
            get;
            set;
        }

        public int CurrentIndex
        {
            get;
            set;
        }

        private bool IsReaderClosed
        {
            get;
            set;
        }

        public void Close()
        {
            this.IsReaderClosed = true;
        }

        public int Depth
        {
            get { return 0; }
        }

        public bool IsClosed
        {
            get { return this.IsReaderClosed; }
        }

        public bool NextResult()
        {
            bool l_NextAvailable = true;
            if (this.IsReaderClosed)
            {
                l_NextAvailable = false;
            }
            else
            {
                if (this.CurrentIndex < 0)
                {
                    this.CurrentIndex = this.StartIndex;
                }
                else
                {
                    this.CurrentIndex++;
                }
                if (this.CurrentIndex > this.EndIndex)
                {
                    l_NextAvailable = false;
                    this.CurrentIndex = this.EndIndex;
                    this.IsReaderClosed = true;
                }
                else
                {
                    l_NextAvailable = true;
                }
            }
            return l_NextAvailable;
        }

        public bool Read()
        {
            return this.NextResult();
        }

        public int RecordsAffected
        {
            get { return -1; }
        }

        public void Dispose()
        {

        }

        public int FieldCount
        {
            get { return this.GetSchemaTable().Columns.Count; }
        }

        public bool GetBoolean(int i)
        {
            return (bool)this.GetDataValue(this.CurrentIndex, i);
        }

        public byte GetByte(int i)
        {
            throw new NotImplementedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public char GetChar(int i)
        {
            return (char)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotImplementedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotImplementedException();
        }

        public string GetDataTypeName(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i).GetType().ToString();
        }

        public DateTime GetDateTime(int i)
        {
            return (DateTime)this.GetDataValue(this.CurrentIndex, i);
        }

        public decimal GetDecimal(int i)
        {
            return (decimal)this.GetDataValue(this.CurrentIndex, i);
        }

        public double GetDouble(int i)
        {
            return (double)this.GetDataValue(this.CurrentIndex, i);
        }

        public Type GetFieldType(int i)
        {
            return this.GetSchemaTable().Columns[i].DataType;
        }

        public float GetFloat(int i)
        {
            return (float)this.GetDataValue(this.CurrentIndex, i);
        }

        public Guid GetGuid(int i)
        {
            return (Guid)this.GetDataValue(this.CurrentIndex, i);
        }

        public short GetInt16(int i)
        {
            return (short)this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetInt32(int i)
        {
            return (int)this.GetDataValue(this.CurrentIndex, i);
        }

        public long GetInt64(int i)
        {
            return (long)this.GetDataValue(this.CurrentIndex, i);
        }

        public string GetName(int i)
        {
            return this.GetSchemaTable().Columns[i].ColumnName;
        }

        public string GetString(int i)
        {
            return (string)this.GetDataValue(this.CurrentIndex, i);
        }

        public object GetValue(int i)
        {
            return this.GetDataValue(this.CurrentIndex, i);
        }

        public int GetValues(object[] values)
        {
            throw new NotImplementedException();
        }

        public bool IsDBNull(int i)
        {
            return (this.GetDataValue(this.CurrentIndex, i) == null);
        }

        public object this[string name]
        {
            get
            {
                int l_ColIndex = -1;
                Object l_Value = null;
                if ((l_ColIndex = this.GetSchemaTable().Columns.IndexOf(name)) >= 0)
                {
                    l_Value = this.GetDataValue(this.CurrentIndex, l_ColIndex);
                }
                return l_Value;
            }
        }

        public object this[int i]
        {
            get { return this.GetDataValue(this.CurrentIndex, i); }
        }
        # endregion

    }
}
