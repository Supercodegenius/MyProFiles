﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class TowerMatchBE
    {
        [Column("file_name")]
        public string FileName { get; set; }
        [Column("saved_name")] 
        public string SavedName { get; set; }

        [Column("LIMIT")] 
        public double Limit { get; set; }
        [Column("ATTACHMENTPOINT")]  
        public double AttachmentPoint { get; set; }
        [Column("SHARE")] 
        public double Share { get; set; }

        [Column("CURRENCY")]
        public string Currency { get; set; }

        [Column("tower_id")]
        public string TowerId { get; set; }

        [Column("fpGuid")]
        public int fpGuid { get; set; }

    }
}
