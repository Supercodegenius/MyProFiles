﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class MainStage
    {
        public int? id { get; set; }
        public int? emt_insurance_guid { get; set; }
        public string NAMEDINSURED { get; set; }
        public string saved_name { get; set; }
        public string COVERAGE { get; set; }
        public double LIMIT { get; set; }
        public double ATTACHMENTPOINT { get; set; }
        public double limit_USD { get; set; }
        public double AT_USD { get; set; }
        public double SHARE { get; set; }
        public string CURRENCY { get; set; }
        public string tower_id { get; set; }
        public string file_name { get; set; }
        public int? risk_count { get; set; }
        public string primary_ind { get; set; }
        public string p_saved_name { get; set; }
        public double? plimit { get; set; }
        public double? pat { get; set; }
        public string p_filename { get; set; }
        public double? prevsum { get; set; }
        public string primary_TM { get; set; }
        public string nonprimary_TM { get; set; }
        public string final_TM { get; set; }
    }
}
