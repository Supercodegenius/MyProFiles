﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class FileNamesBE
    {
        [Column("file_name")]
        public string FileName { get; set; }

        //[Column("doc_guid")]
        //public int doc_guid { get; set; }

    }
}
