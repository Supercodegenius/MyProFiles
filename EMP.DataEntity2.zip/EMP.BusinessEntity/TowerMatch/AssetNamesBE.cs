﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class AssetNamesBE
    {
        [Column("saved_name")]
        public string AssetName { get; set; }
        

    }

    [Serializable]
    public class RefreshExtractBE
    {
        [Column("description")]
        public string description { get; set; }

        


    }
}
