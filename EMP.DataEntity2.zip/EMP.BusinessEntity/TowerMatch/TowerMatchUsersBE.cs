﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class TowerMatchUsersBE
    {

        [Column("id")]
        public int id { get; set; }
        [Column("UserId")]
        public string UserId { get; set; }
        [Column("UserName")]
        public string UserName { get; set; }


    }
}
