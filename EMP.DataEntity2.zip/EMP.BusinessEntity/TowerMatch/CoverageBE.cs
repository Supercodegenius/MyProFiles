﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class CoverageBE
    {
        [Column("DisplayText")]
        public string DisplayText { get; set; }
        [Column("COVERAGE")]
        public string Coverage { get; set; }

    }
}
