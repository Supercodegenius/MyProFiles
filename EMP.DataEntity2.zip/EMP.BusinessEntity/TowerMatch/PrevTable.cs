﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class PrevTable
    {

        [Column("id")]
        public int id { get; set; }

        [Column("prev_savedname")]
        public string prev_savedname { get; set; }

        [Column("prev_filename")]
        public string prev_filename { get; set; }

        [Column("next_id")]
        public int next_id { get; set; }

        [Column("prev_limit")]
        public double prev_limit { get; set; }

        [Column("prev_at")]
        public double prev_at { get; set; }

        [Column("prev_sum")]
        public double prev_sum { get; set; }

        

        

        

    }
}
