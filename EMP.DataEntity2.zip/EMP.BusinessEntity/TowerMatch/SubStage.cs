﻿using System;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Serializable]
    public class SubStage
    {
        [Column("id")]
        public int id { get; set; }

        [Column("emt_insurance_guid")]
        public int emt_insurance_guid { get; set; }

        [Column("NAMEDINSURED")]
        public string NAMEDINSURED { get; set; }

        [Column("saved_name")]
        public string saved_name { get; set; }

        [Column("COVERAGE")]
        public string COVERAGE { get; set; }

        [Column("LIMIT")]
        public double LIMIT { get; set; }

        [Column("ATTACHMENTPOINT")]
        public double ATTACHMENTPOINT { get; set; }

        [Column("limit_USD")]
        public double limit_USD { get; set; }

        [Column("AT_USD")]
        public double AT_USD { get; set; }

        [Column("SHARE")]
        public double SHARE { get; set; }

        [Column("CURRENCY")]
        public string CURRENCY { get; set; }

        [Column("tower_id")]
        public string  tower_id { get; set; }

        [Column("file_name")]
        public string file_name { get; set; }

        [Column("risk_count")]
        public int risk_count { get; set; }

        [Column("primary_ind")]
        public string primary_ind { get; set; }

        [Column("p_saved_name")]
        public string p_saved_name { get; set; }

        [Column("plimit")]
        public double plimit { get; set; }

        [Column("pat")]
        public double pat { get; set; }

        [Column("p_filename")]
        public string p_filename { get; set; }

        [Column("prevsum")]
        public double prevsum { get; set; }

        [Column("primary_TM")]
        public string primary_TM { get; set; }

        [Column("nonprimary_TM")]
        public string nonprimary_TM { get; set; }

        [Column("final_TM")]
        public string final_TM { get; set; }

        

    }
}
