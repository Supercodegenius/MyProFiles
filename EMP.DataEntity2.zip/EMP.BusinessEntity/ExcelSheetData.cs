﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMP.BusinessEntity
{
    public class ExcelSheetData
    {
        public string SheetName { get; set; }
        public int SheetColumnCount { get; set; }
        public bool IsInvalidHeaders { get; set; }
        public bool IsEmptySheet { get; set; }

        public bool IsMergeCellExist { get; set; }
    }
}
