﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    public class SecModLookupBE
    {
        [Column("rms_field_guid")]
        public int RMSFieldGUID { get; set; }
        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("iso2a_countrycode")]
        public string Country_Code { get; set; }
        [Column("emp_scheme_guid")]
        public int SchemeGuid { get; set; }
        [Column("schemeName")]
        public string SchemeName { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("Lookup")]
        public string LookUp { get; set; }
        [Column("code")]
        public string Code { get; set; }
        [Column("is_secondary_mods")]
        public bool ISSecMods{ get; set;}
        [Column("order_num")]
        public int OrderNum { get; set; }
        [Column("bulk_option")]
        public int BulkOption { get; set; }
    }
}
