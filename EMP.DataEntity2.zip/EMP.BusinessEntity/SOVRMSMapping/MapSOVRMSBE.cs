﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Interfaces.BusinessEntity;
using XLCapital.XLRE.Framework.BaseLibrary;
using EMP.Utilities;
using EMP.ViewModel;

namespace EMP.BusinessEntity
{
    [Connection(DatabaseConnnections.C_DEFAULT)]
    public class MapSOVRMSBE :  IMappedSOVRMS
    {
        [Column("sov_field_guid")]
        public int? SOVFieldGuid { get; set; }
        [Column("from_field_name")]
        public string FromFieldName { get; set; }
        [Column("to_field_name")]
        public string ToFieldName { get; set; }
        [Column("bulk_load_value")]
        public string BulkCodeValue { get; set; }
        [Column("adjust_value")]
        public string AdjustValue { get; set; }
        [Column("occupancy")]
        public string SelectedOccupancy { get; set; }
        [Column("filtervalue")]
        public string FilteredValue { get; set; }
        [Column("owner_guid")]
        public int FileProcessingId { get; set; }
        [Column("bulk_code_item")]
        public string BulkCodeItem { get; set; }

        [Column("keyword_search_value")]
        public string KeyWordSearch { get; set; }
        
        [Column ("is_temporary_mapping")]
        public bool IsTemporaryMapping { get; set; }

    }
}
