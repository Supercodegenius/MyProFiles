﻿
using System.Collections.Generic;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{

    [Table("t_emp_mapping_io_linkingdef")]
    public class MappingIODefBE : BaseEMPAuditableBusinessEntity<MappingIODefBE>
    {
        [Column("emp_mapping_linkingdef_guid")]
        public int? MappingLinkingDefGuid { get; set; }
        [Column("emp_mappingdef_guid",true)]
        public int? MappingDefGuid { get; set; }     
        [Column("from_field_name")]
        public string FromFieldName { get; set; }
        [Column("to_field_name")]
        public string ToFieldName { get; set; }
        [Column("bulk_load_value")]
        public string BulkCodeValue { get; set; }
        [Column("adjust_value")]
        public string AdjustValue { get; set; }
        [Column("bulk_code_item")]
        public string BulkCodeItem { get; set; }

        [Column("keyword_search_value")]
        public string KeyWordSearch { get; set; }

        [Column("sov_field_guid")]
        public int ? SOVFieldGuid { get; set; }

        [Column("program_guid")]
        public int? ProgramGuid { get; set; }

        [Column("active_ind")]
        public bool ActiveInd { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.MappingLinkingDefGuid;
            }
            set
            {
                this.MappingLinkingDefGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        public override void SetForeignKey(string argForeignKey, int? argForeignKeyValue)
        {
            switch (argForeignKey)
            {
                case "MappingIOForeignKey":
                    this.MappingDefGuid = argForeignKeyValue;
                    break;

            }
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        public class MappingIODefBECollection:List<MappingIODefBE>
        {

        }
    }
}
