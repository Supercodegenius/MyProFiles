﻿using EMP.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_mapping_issues_def")]
    public class MappingIssuesDefBE: BaseEMPAuditableBusinessEntity<MappingIssuesDefBE>
    {
        [Column("t_emp_mapping_issues_def_guid", IsPrimaryKey = true)]
        public int? IssuesDefGuid { get; set; }
        [Column("owner_guid")]
        public int OwnerGuid { get; set; }
        [Column("rms_field_guid")]
        public int RMSFieldGuid { get; set; }
        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("sov_field_name")]
        public string  SOVFieldName { get; set; }
        [Column("sov_source_value")]
        public string SOVSourceData { get; set; }
        [Column("count")]
        public int Count { get; set; }
        [Column("rms_selected_value")]
        public string RMSSelectedValue { get; set; }

        [Column("is_primary_char")]
        public bool ISPrimaryCharact { get; set; }
        [Column("is_secondary_mods")]
        public bool ISSecondCharact { get; set; }
        [Column("is_state_code")]
        public bool ISStateCodeIssue { get; set; }
        [Column("is_active")]
        public bool IsActive { get; set; }
        [Column("mapping_count")]
        public int MappingCount { get; set; }
        [Column("country_code")]
        public string CountryCode { get; set; }


        public override int? PrimaryKey
        {
            get
            {

                return this.IssuesDefGuid;
            }
            set
            {
                this.IssuesDefGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        [Serializable]
        public class MappingIssuesDefBECollection : List<MappingIssuesDefBE>
        {
        }

    }
}
