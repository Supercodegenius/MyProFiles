﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Interfaces.BusinessEntity;
using XLCapital.XLRE.Framework.BaseLibrary;
using EMP.Utilities;

namespace EMP.BusinessEntity
{
    [Connection(DatabaseConnnections.C_DEFAULT)]
    public class OccBldClassLookupBE: BaseEMPBusinessEntity<OccBldClassLookupBE>, IOccBldClassLookupBE
    {
        [Column("emp_bldgclass_occtype_lookup_guid")]
        public int ? OccTypeBldClassLookupGuid { get; set; }

        [Column("rms_field_guid")]
        public int RMSFieldGuid { get; set; }

        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("emp_scheme_guid")]
        public int EMPSchemeGuid { get; set; }
        [Column("schemename")]
        public string EMPSchemeName { get; set; }
        [Column("Description")]
        public string Description { get; set; }
        [Column("Lookup")]
        public string LookUp { get; set; }
        [Column("Code")]
        public string Code { get; set; }
        [Column("order_num")]
        public int OrderNum { get; set; }
        [Column("bulk_option")]
        public int BulkOption { get; set; }
        [Column("ISO2ACountryCode")]
        public string ISO2ACountryCode { get; set; }
        [Column("C_ATC")]
        public string C_ATC { get; set; }
        [Column("C_RMS")]
        public string C_RMS { get; set; }
        [Column("C_IFMDescription")]
        public string C_IFMDescription { get; set; }
        [Column("O_ATC")]
        public string O_ATC { get; set; }
        [Column("O_IFM_2digit")]
        public string O_IFM_2digit { get; set; }
        [Column("O_IFM_4digit")]
        public string O_IFM_4digit { get; set; }
        //[Column("active_ind")]
        //public int ActiveInd { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.OccTypeBldClassLookupGuid;
            }
            set
            {
                this.OccTypeBldClassLookupGuid = value;
            }
        }

    }
}
