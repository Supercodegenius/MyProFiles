﻿using EMP.Interfaces.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;
using static EMP.BusinessEntity.MappingIODefBE;

namespace EMP.BusinessEntity
{
    [Table("t_emp_mappingdef")]
    public class MappingDefBE : BaseEMPAuditableBusinessEntity<MappingDefBE>
    {
        public MappingDefBE() {
            this.MappingIODefCollection = new MappingIODefBECollection();
            }
        [Column("emp_mappingdef_guid")]
        public int? MappingDefGuid { get; set; }
        [Column("owner_guid",true)]
        public int? OwnerGuid { get; set; }
        [Column("program_file_guid")]
        public int? ProgramFileGuid { get; set; }
        [Column("source_columns")]
        public string SourceColumns { get; set; }
        [Column("name")]
        public string Name { get; set; }

        [Column("occupancy")]
        public string SelectedOccupancy { get; set; }

        [Column("filtervalue")]
        public string FilterValue { get; set; }
        public MappingIODefBECollection MappingIODefCollection { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.MappingDefGuid;
            }
            set
            {
                this.MappingDefGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }
        public override void SetForeignKey(string argForeignKey, int? argForeignKeyValue)
        {
            switch (argForeignKey)
            {
                case "MappingDefForiegnKey":
                    this.OwnerGuid = argForeignKeyValue;
                    break;

            }
        }
        public override void CreateEntityAssociations()
        {

            base.EntityAssociations = new List<EntityAssociation>();

            base.EntityAssociations.Add(new EntityAssociation(
               argParentEntity: this,
               argChildEntityListName: "MappingIODefCollection",
               argChildEntityType: typeof(MappingIODefBE),
               argForeignKey: "MappingIOForeignKey",
               argAdditionalForeignKeys: null));
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        [Serializable]
        public class MappingDefBECollection : List<MappingDefBE>
        {
        }

    }
}
