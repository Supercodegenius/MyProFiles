﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_sov_fields")]
    public class TempSOVRMSMappingBE : BaseEMPAuditableBusinessEntity<TempSOVRMSMappingBE>
    {
        [Column("sov_field_guid", IsPrimaryKey = true)]
        public int? SOVFieldGuid { get; set; }

        [Column("sov_field_name")]
        public string SOVFieldName { get; set; }

        [Column("rms_field_guid")]
        public int RMSFieldGuid { get; set; }

        [Column("priority")]
        public int Priority { get; set; }

        [Column("is_temporary_mapping")]
        public bool IsTempMapping { get; set; }

        [Column("active_ind")] 
        public bool ActiveInd { get; set; }

        [Column("mapping_count")]
        public int ? MappingCount { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.SOVFieldGuid;
            }
            set
            {
                this.SOVFieldGuid = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }
        
    }
}
