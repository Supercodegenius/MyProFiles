﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("[t_emp_occupancy_keyword_search]")]
   public class OccKeyWordSearchBE : BaseEMPAuditableBusinessEntity<OccKeyWordSearchBE>
    {

        [Column("program_file_guid")]
        public int ? ProgramFileGuid { get; set; }

        [Column("sov_field_name")]
        public string SovFieldName { get; set; }

        [Column("bulk_code_item")]
        public string BulkCodeItem { get; set; }
        [Column("priority")]
        public int Priority { get; set; }
        [Column("keyword_search")]
        public string KeyWordSearch { get; set; }
        [Column("is_use_flag")]
        public bool IsUseFlag { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.ProgramFileGuid;
            }
            set
            {
                this.ProgramFileGuid = value;
            }
        }

    }
}
