﻿using EMP.Interfaces.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Utilities;
using EMP.ViewModel;

namespace EMP.BusinessEntity
{
    [Connection(DatabaseConnnections.C_DEFAULT)] 
    public class SOVtoRMSFieldBE : BaseEMPAuditableBusinessEntity<SOVtoRMSFieldBE>, ISOVtoRMSFieldsBE
    {

        [Column("sov_field_guid",true)]
        public int ? SOVFieldGUID { get; set; }

        [Column("rms_field_guid")]
        public int RMSFieldGUID { get; set; }

        [Column("sov_field_name")]
        public string SOVFieldName { get; set; }

        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }

        [Column("short_name")]
        public string DescriptiveName { get; set; }

        [Column("description")]
        public string RMSDescription { get; set; }
        [Column("is_most_common_field")]
        public bool IsMostCommon { get; set; }
        [Column("is_required_field")]
        public bool IsRequired { get; set; }
        [Column("Priority")]
        public int Priority { get; set; }
        [Column("is_value_field")]
        public bool IsValueField { get; set; }
        [Column("is_primary_characteristics_field")]
        public bool IsPrimaryChar { get; set; }
        [Column("is_secondary_mods")]
        public bool IsSecMods { get; set; }
        public bool IsMappAvailable { get; set; }
        [Column("is_bulk_option_available")]
        public bool IsBulkCodeAvailable { get; set; }
        [Column("req_optional")]
        public string RequiredOptionalOrBoth { get; set; }
        [Column("is_adjust_value")]
        public bool IsAdjustValue { get; set; }
        [Column("order")]
        public int orderNum { get; set; }
        [Column("rmsfieldtype")]
        public string RMSFieldType { get; set; }
        [Column("is_limitto_list")]
        public bool IsLimitToList { get; set; }
        [Column("is_secondary_mods_bycntry")]
        public bool IsSecModByCntry { get; set; }

        [Column("is_keyword_search")]
        public bool IsKeyWordSearchAvailable { get; set; }
        public BulkCodeItem BulkCodeItem { get; set; }
        public string BulkOptionCode{ get; set; }
        [Column("is_temporary_mapping")]
        public bool IsTemporaryMapping { get; set; }

        [Column("mapping_count")]
        public int? MappingCount { get; set; }

        public override int? PrimaryKey
        {
            get
            {
                return this.SOVFieldGUID;
            }
            set
            {
                this.SOVFieldGUID = value;
            }
        }

    }
    
}
