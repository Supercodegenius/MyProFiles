﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Interfaces.BusinessEntity;
using EMP.Utilities;

namespace EMP.BusinessEntity
{
    public class SecurityPrincipalBE : BaseEMPBusinessEntity<SecurityPrincipalBE>, ISecurityPrincipalBE
    {
        public SecurityPrincipalBE()
        {
            this.Roles = new List<string>();
        }

        /// <summary>
        /// Property to hold the Login Name
        /// </summary>	
        [Column("login_name", true, true)]
        public string LoginName { get; set; }

        /// <summary>
        /// Property to hold the Principal Type
        /// </summary>
        [Column("principal_type", true)]
        public string PrincipalType { get; set; }

        /// <summary>
        /// Property to hold the User Guid
        /// </summary>
        [Column("user_guid", true)]
        public int? UserGuid { get; set; }

        /// <summary>
        /// Property to hold the Last Name
        /// </summary>
        [Column("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// Property to hold the First Name
        /// </summary>
        [Column("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Property to hold the Middle Initial
        /// </summary>
        [Column("middle_initial")]
        public string MiddleInitial { get; set; }

        /// <summary>
        /// Property to hold the Bus Role
        /// </summary>
        [Column("bus_role")]
        public string BusRole { get; set; }

        /// <summary>
        /// Property to hold the Title
        /// </summary>
        [Column("title")]
        public string Title { get; set; }

        /// <summary>
        /// Property to hold the Active Ind
        /// </summary>
        [Column("active_ind", IsIdentifer = true)]
        public bool? ActiveInd { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get => CommonMethods.UserDisplayName(this.FirstName, this.LastName); }

        /// <summary>
        /// 
        /// </summary>
        public string ReverseDisplayName
        {
            get => string.Format("{0}, {1}",
        string.IsNullOrEmpty(this.LastName) ? string.Empty : this.LastName.Trim(),
        string.IsNullOrEmpty(this.FirstName) ? string.Empty : this.FirstName.Trim());
        }

        /// <summary>
        /// 
        /// </summary>
        public List<string> Roles { get; set; }

        public override int? PrimaryKey
        {
            get
            {
                return this.UserGuid;
            }
            set
            {
                this.UserGuid = value;
            }
        }
    }
}
