﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMP.Interfaces.BusinessEntity;
using System.Xml;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_exp_location")]
    public class ExpLocationBE
    {
        //: BaseEMPAuditableBusinessEntity<ExpLocationBE>, IExpLocationBE
        //[Column("program_guid", IsPrimaryKey = false)]
        //public long? ProgramGuid { get; set; }

        [Column("LOCNUM")]
        public string LocNum { get; set; }

        [Column("LOCNAME")]
        public string LocName { get; set; }

        [Column("PRIMARYBLDG")]
        public string PrimaryBldg { get; set; }

        [Column("SITENAME")]
        public string SiteName { get; set; }

        [Column("STREETNAME")]
        public string StreetName { get; set; }

        [Column("DISTRICT")]
        public string District { get; set; }

        [Column("CITY")]
        public string City { get; set; }

        [Column("STATE")]
        public string State { get; set; }

        [Column("STATECODE")]
        public string StateCode { get; set; }

        [Column("POSTALCODE")]
        public string PostalCode { get; set; }

        [Column("county")]
        public string County { get; set; }

        [Column("ISO2ACOUNTRYCODE")]
        public string Iso2aCountryCode { get; set; }

        [Column("CNTRYSCHEME")]
        public string CntryScheme { get; set; }

        [Column("CNTRYCODE")]
        public string CntryCode { get; set; }

        [Column("LATITUDE")]
        public decimal? Latitude { get; set; }

        [Column("LONGITUDE")]
        public decimal? Longitude { get; set; }

        [Column("RMS_LATITUDE")]
        public decimal? Rms_Latitude { get; set; }

        [Column("RMS_LONGITUDE")]
        public decimal? Rms_Longitude { get; set; }

        [Column("RMS_GEOCODING_RESOLUTION")]
        public string Rms_Geocoding_Resolution { get; set; }

        [Column("CRESTA")]
        public string Cresta { get; set; }

        [Column("BLDGSCHEME")]
        public string BldgScheme { get; set; }

        [Column("BLDGCLASS")]
        public string BldgClass { get; set; }

        [Column("C_ATC")]
        public string C_Atc { get; set; }

        [Column("C_RMS")]
        public string C_Rms { get; set; }

        [Column("C_IFMDESCRIPTION")]
        public string C_Ifm_Description { get; set; }

        [Column("OCCSCHEME")]
        public string OccScheme { get; set; }

        [Column("OCCTYPE")]
        public string OccType { get; set; }

        [Column("O_ATC")]
        public string O_Atc { get; set; }

        [Column("O_IFM_2_DIGIT")]
        public string O_Ifm_2_Digit { get; set; }

        [Column("O_IFM_4_DIGIT")]
        public string O_Ifm_4_Digit { get; set; }

        [Column("YEARBUILT")]
        public DateTime? YearBuilt { get; set; }

        [Column("FLOORAREA")]
        public int? FloorArea { get; set; }

        [Column("NUMSTORIES")]
        public int? NumStories { get; set; }

        [Column("USERID1")]
        public string UserId1 { get; set; }

        [Column("USERID2")]
        public string UserId2 { get; set; }

        [Column("USERTXT1")]
        public string UserTxt1 { get; set; }

        [Column("USERTXT2")]
        public string UserTxt2 { get; set; }

        [Column("USERTXT3")]
        public string UserTxt3 { get; set; }

        [Column("USERTXT4")]
        public string UserTxt4 { get; set; }

        [Column("USERTXT5")]
        public string UserTxt5 { get; set; }

        [Column("USERTXT6")]
        public string UserTxt6 { get; set; }

        [Column("SITECURRENCY")]
        public string SiteCurrency { get; set; }

        [Column("CV1VAL")]
        public decimal Cv1Val { get; set; }

        [Column("CV2VAL")]
        public decimal Cv2Val { get; set; }

        [Column("CV2CVM")]
        public string Cv2Cvm { get; set; }

        [Column("EQCV2EQSLG")]
        public string Eqcv2Eqslg { get; set; }

        [Column("CV3VAL")]
        public decimal Cv3Val { get; set; }

        //[Column("cv6_cvm")]
        //public string Cv6Cvm { get; set; }

        //[Column("eqcv6_eqslg")]
        //public string Eqcv6Eqslg { get; set; }

        [Column("CV9VAL")]
        public decimal Cv9Val { get; set; }

        [Column("CV9CVM")]
        public string Cv9Cvm { get; set; }

        [Column("EQCV9EQSLG")]
        public string Eqcv9Eqslg { get; set; }

        [Column("TOTALVALUE")]
        public decimal TotalValue { get; set; }

        [Column("STORYPROF")]
        public string StoryProf { get; set; }

        //public override int? PrimaryKey
        //{
        //    get
        //    {

        //        return Convert.ToInt32(this.ProgramGuid);

        //    }
        //    set
        //    {
        //        this.ProgramGuid = Convert.ToInt32(value);
        //    }
        //}
    }
}
