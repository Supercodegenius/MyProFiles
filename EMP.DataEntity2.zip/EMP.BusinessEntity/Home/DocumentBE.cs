﻿
using System;
using System.Collections.Generic;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_doc")]
    public class DocumentBE : BaseEMPAuditableBusinessEntity<DocumentBE>
    {
        [Column("doc_guid", IsPrimaryKey = true, IsIdentifer = true)]
        public int ? DocGuid { get; set; }
        [Column("id")]
        public string Id { get; set; }
        [Column("file_type")]
        public string Type { get; set; }
        [Column("owner_guid",true)]
        public int? OwnerGuid { get; set; }

        [Column("description")]
        public string Description { get; set; }
        [Column("file_name")]
        public string FileName { get; set; }

        [Column("file_status")]
        public int? FileStatus { get; set; }
        [Column("record_count")]
        public int? RecordCount { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public override int? PrimaryKey
        {
            get
            {

                return this.DocGuid;
            }
            set
            {
                this.DocGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }
        public override void SetForeignKey(string argForeignKey, int? argForeignKeyValue)
        {
            switch (argForeignKey)
            {
                case "DocumentForiegnKey":
                    this.OwnerGuid = argForeignKeyValue;
                    break;

            }
        }


        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        [Serializable]
        public class DocumentBECollection : List<DocumentBE>
        {
        }

    }
}
