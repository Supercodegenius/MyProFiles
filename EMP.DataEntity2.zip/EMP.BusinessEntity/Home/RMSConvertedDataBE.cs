﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    //[Table("[t_emp_converted_rms]")]
    [Table("[t_emt_insurance_stage]")]
    public class RMSConvertedDataBE : BaseEMPAuditableBusinessEntity<RMSConvertedDataBE>
    {
        [Column("[emt_insurance_guid]")]
        public int? emt_insurance_guid { get; set; }

        //[Column("[emp_converted_rms_guid]")]
        //public int ? Emp_converted_rms_guid { get; set; }
        [Column("[emp_fileprocessingtask_guid]")]
        public int? Emp_fileprocessingtask_guid { get; set; }

        [Column("[PROGRAMGUID]")]
        public int? PROGRAMGUID { get; set; }

        [Column("[emt_insurance_company_guid]")]
        public int? emt_insurance_company_guid { get; set; }

        //[Column("[emt_insurance_company_guid]")]
        //public int? emt_insurance_company_guid { get; set; }

        [Column("[emt_spreadsheet_guid]")]
        public int? emt_spreadsheet_guid { get; set; }

        [Column("[emt_reinsurance_program_guid]")]
        public int? emt_reinsurance_program_guid { get; set; }

        [Column("[TICKERSYMBOL]")]
        public string TICKERSYMBOL { get; set; }

        [Column("[EXCHANGE]")]
        public string EXCHANGE { get; set; }

        [Column("[NAMEDINSURED]")]
        public string NAMEDINSURED { get; set; }

        [Column("[saved_name]")]
        public string saved_name { get; set; }

        [Column("[LOCATION]")]
        public string LOCATION { get; set; }

        [Column("[conformed_country]")]
        public string conformed_country { get; set; }

        [Column("[class_guid]")]
        public int? class_guid { get; set; }

        [Column("[COVERAGE]")]
        public string COVERAGE { get; set; }

        [Column("[LIMIT]")]
        public double? LIMIT { get; set; }

        [Column("[ATTACHMENTPOINT]")]
        public double? ATTACHMENTPOINT { get; set; }

        [Column("[SHARE]")]
        public double? SHARE { get; set; }

        [Column("[EFFECTIVEDATE]")]
        public DateTime? EFFECTIVEDATE { get; set; }

        [Column("[EXPIRYDATE]")]
        public DateTime? EXPIRYDATE { get; set; }

        [Column("[PREMIUM]")]
        public double? PREMIUM { get; set; }

        [Column("[POLICYEXPOSURE]")]
        public double? POLICYEXPOSURE { get; set; }

        [Column("[EXPOSUREBASE]")]
        public string EXPOSUREBASE { get; set; }

        [Column("[EXPOSURECOUNT]")]
        public double? EXPOSURECOUNT { get; set; }

        [Column("[INDUSTRY]")]
        public string INDUSTRY { get; set; }

        [Column("[conformed_industry]")]
        public string conformed_industry { get; set; }

        [Column("[ciq]")]
        public string ciq { get; set; }

        [Column("[predict]")]
        public string predict { get; set; }

        [Column("[likelihood]")]
        public string likelihood { get; set; }

        [Column("[CURRENCY]")]
        public string CURRENCY { get; set; }


        [Column("[older_name]")]
        public string older_name { get; set; }

        [Column("[POLICYPARTOFLIMIT]")]
        public double? POLICYPARTOFLIMIT { get; set; }

        [Column("[INDUSTRYCODE]")]
        public string INDUSTRYCODE { get; set; }

        [Column("[ORIGINALREFERENCE]")]
        public string ORIGINALREFERENCE { get; set; }

        [Column("[BASISOFCOVER]")]
        public string BASISOFCOVER { get; set; }

        [Column("[PRIMARYEXCESS]")]
        public string PRIMARYEXCESS { get; set; }

        [Column("[POLICYCOVERBASIS]")]
        public string POLICYCOVERBASIS { get; set; }

        [Column("[ADDITIONALDATA1]")]
        public string ADDITIONALDATA1 { get; set; }

        [Column("[ADDITIONALDATA2]")]
        public string ADDITIONALDATA2 { get; set; }

        [Column("[ADDITIONALDATA3]")]
        public string ADDITIONALDATA3 { get; set; }

        [Column("[ADDITIONALDATA4]")]
        public string ADDITIONALDATA4 { get; set; }

        [Column("[ADDITIONALDATA5]")]
        public string ADDITIONALDATA5 { get; set; }

        [Column("[TREATYCURRENCY]")]
        public string TREATYCURRENCY { get; set; }

        [Column("[TREATYLIMIT]")]
        public double TREATYLIMIT { get; set; }

        [Column("[TREATYATTACHMENTPOINT]")]
        public double TREATYATTACHMENTPOINT { get; set; }

        [Column("[TREATYPREMIUM]")]
        public double TREATYPREMIUM { get; set; }

        [Column("[sics_searched]")]
        public bool sics_searched { get; set; }

        [Column("[Fac_Share_pct]")]
        public double? Fac_Share_pct { get; set; }

        [Column("[Other_Cedants_pct]")]
        public double? Other_Cedants_pct { get; set; }

        [Column("[INDUSTRYCODETYPE]")]
        public string INDUSTRYCODETYPE { get; set; }

        [Column("[YEAR]")]
        public int? YEAR { get; set; }

        [Column("[ADDITIONALDATA6]")]
        public string ADDITIONALDATA6 { get; set; }

        [Column("[ADDITIONALDATA7]")]
        public string ADDITIONALDATA7 { get; set; }

        [Column("[ADDITIONALDATA8]")]
        public string ADDITIONALDATA8 { get; set; }

        [Column("[ADDITIONALDATA9]")]
        public string ADDITIONALDATA9 { get; set; }

        [Column("[ADDITIONALDATA10]")]
        public string ADDITIONALDATA10 { get; set; }

        [Column("[ADDITIONALDATA11]")]
        public string ADDITIONALDATA11 { get; set; }

        [Column("[ADDITIONALDATA12]")]
        public string ADDITIONALDATA12 { get; set; }

        [Column("[ADDITIONALDATA13]")]
        public string ADDITIONALDATA13 { get; set; }

        [Column("[ADDITIONALDATA14]")]
        public string ADDITIONALDATA14 { get; set; }

        [Column("[ADDITIONALDATA15]")]
        public string ADDITIONALDATA15 { get; set; }

        [Column("[ADDITIONALDATA16]")]
        public string ADDITIONALDATA16 { get; set; }

        [Column("[ADDITIONALDATA17]")]
        public string ADDITIONALDATA17 { get; set; }

        [Column("[ADDITIONALDATA18]")]
        public string ADDITIONALDATA18 { get; set; }

        [Column("[ADDITIONALDATA19]")]
        public string ADDITIONALDATA19 { get; set; }

        [Column("[ADDITIONALDATA20]")]
        public string ADDITIONALDATA20 { get; set; }

        [Column("[deleted_ind]")]
        public bool Deleted_Ind { get; set; }

        [Column("[LOCATION1]")]
        public string LOCATION1 { get; set; }

        [Column("[LOCATION2]")]
        public string LOCATION2 { get; set; }

        [Column("[INDUSTRY1]")]
        public string INDUSTRY1 { get; set; }

        [Column("[INDUSTRY2]")]
        public string INDUSTRY2 { get; set; }

        
        [Column("[POLICYID]")]
        public string POLICYID { get; set; }
        [Column("[STACKINGID]")]
        public string STACKINGID { get; set; }

        [Column("[REVENUE]")]
        public double REVENUE { get; set; }
        [Column("[EMPLOYEECOUNT]")]
        public long EMPLOYEECOUNT { get; set; }
        [Column("[ASSETTYPE]")]
        public string ASSETTYPE { get; set; }
        [Column("[CLARKSONID]")]
        public string CLARKSONID { get; set; }
        [Column("[LATITUDE]")]
        public string LATITUDE { get; set; }
        [Column("[LONGITUDE]")]
        public string LONGITUDE { get; set; }
        [Column("[INTEREST]")]
        public string INTEREST { get; set; }

        // new code //
        [Column("[AREA]")]
        public string AREA { get; set; }
        [Column("[PLATFORM]")]
        public string PLATFORM { get; set; }
        [Column("[COMPLEX]")]
        public string COMPLEX { get; set; }
        [Column("[FIELD]")]
        public string FIELD { get; set; }
        [Column("[object_id]")]
        public int object_id { get; set; }
        [Column("[ORIGINALCOVERAGE]")]
        public string ORIGINALCOVERAGE { get; set; }
        //End New code

        //Aviation Columns
        [Column("[SCHEDULE]")]
        public string SCHEDULE { get; set; }

        [Column("[INCEPTION]")]
        public DateTime? INCEPTION { get; set; }

        [Column("[HCCY]")]
        public string HCCY { get; set; }

        [Column("[HLIMIT]")]
        public double? HLIMIT { get; set; }

        [Column("[HEXCESS]")]
        public double? HEXCESS { get; set; }

        [Column("[Hull_CLI_PCT_LINE]")]
        public double? Hull_CLI_PCT_LINE { get; set; }

        [Column("[LIA_CCY]")]
        public string LIA_CCY { get; set; }

        [Column("[LIA_LIMIT]")]
        public double? LIA_LIMIT { get; set; }

        [Column("[LIA_EXCESS]")]
        public double? LIA_EXCESS { get; set; }

        [Column("[Lia_CLI_PCT_LINE]")]
        public double? Lia_CLI_PCT_LINE { get; set; }

        [Column("[US_REG_LINE_OBLIGATION]")]
        public string US_REG_LINE_OBLIGATION { get; set; }

        [Column("[AVN52_CCY]")]
        public string AVN52_CCY { get; set; }

        [Column("[PRIMARY_AVN52_SUB_LIMIT]")]
        public double? PRIMARY_AVN52_SUB_LIMIT { get; set; }

        [Column("[GROUNDING_CCY]")]
        public string GROUNDING_CCY { get; set; }

        [Column("[GROUNDING_LIA_SUB_LIMIT]")]
        public double? GROUNDING_LIA_SUB_LIMIT { get; set; }
        
        //End NAviation Columns

        public override int? PrimaryKey
        {
            get
            {

                return this.emt_insurance_guid;
            }
            set
            {
                this.emt_insurance_guid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }


        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

    }
}
