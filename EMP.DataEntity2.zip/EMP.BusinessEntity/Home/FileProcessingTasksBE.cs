﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Interfaces.BusinessEntity;
using EMP.Interfaces;
using EMP.Utilities;
using XLCapital.XLRE.Framework.BaseLibrary;
using static EMP.BusinessEntity.DocumentBE;
using static EMP.BusinessEntity.FileDataProcessingBE;
using System;
using static EMP.BusinessEntity.MappingDefBE;

namespace EMP.BusinessEntity
{
    [Table("t_emp_fileprocessing_tasks")]
    [Serializable]
    public class FileProcessingTasksBE : BaseEMPAuditableBusinessEntity<FileProcessingTasksBE>
    {
        public FileProcessingTasksBE()
        {
            this.DocumentBEColl = new DocumentBECollection();
            this.FileDataColl = new FileDataProcessingBECollection();
            this.MappingDefColl = new MappingDefBECollection();
        }

        [Column("emp_fileprocessing_task_guid", IsPrimaryKey = true, IsIdentifer = true)]
        public int ? FileProcessingTaskGuid { get; set; }

        [Column("program_guid")]
        public int ? ProgramGuid { get; set; }

        [Column("program_file_guid")]
        public int ? ProgramFileGuid { get; set; }

        [Column("source_sheet")]
        public string SourceSheet { get; set; }

        [Column("status_guid")]
        public int StatusGuid { get; set; }

        [Column("completed_ind")]
        public int CompletedInd { get; set; }

        public DocumentBECollection DocumentBEColl { get; set; }
        public FileDataProcessingBECollection FileDataColl { get; set; }
        public MappingDefBECollection MappingDefColl { get; set; }
        public override int? PrimaryKey
        {
            get
            {
                
                return this.FileProcessingTaskGuid;
            }
            set
            {
                this.FileProcessingTaskGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        public override void CreateEntityAssociations()
        {

            base.EntityAssociations = new List<EntityAssociation>();

            base.EntityAssociations.Add(new EntityAssociation(
                argParentEntity: this,
                argChildEntityListName: "DocumentBEColl",
                argChildEntityType: typeof(DocumentBE),
                argForeignKey: "DocumentForiegnKey",
                argAdditionalForeignKeys: null));

            base.EntityAssociations.Add(new EntityAssociation(
               argParentEntity: this,
               argChildEntityListName: "FileDataColl",
               argChildEntityType: typeof(FileDataProcessingBE),
               argForeignKey: "FileDataProcessingForiegnKey",
               argAdditionalForeignKeys: null));
            base.EntityAssociations.Add(new EntityAssociation(
               argParentEntity: this,
               argChildEntityListName: "MappingDefColl",
               argChildEntityType: typeof(MappingDefBE),
               argForeignKey: "MappingDefForiegnKey",
               argAdditionalForeignKeys: null));
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

    }

}