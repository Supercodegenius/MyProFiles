﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_lookups")]
    public class LookupBE
    {
        [Column("lookups_guid")]
        public int? LookupGuid { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("lookups_group_guid")]
        public int LookupGroupGuid { get; set; }       

    }
}
