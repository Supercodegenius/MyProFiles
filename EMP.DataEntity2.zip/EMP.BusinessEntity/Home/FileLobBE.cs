﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("[t_emt_lob]")]
    public class FileLobBE
    {
        [Column("lob_guid")]
        public int LobGuid { get; set; }

        [Column("lob_name")]
        public string LobName { get; set; }
        //public bool active_ind { get; set; }
    }
}
