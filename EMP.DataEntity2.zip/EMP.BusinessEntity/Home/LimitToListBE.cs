﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Interfaces.BusinessEntity;
using XLCapital.XLRE.Framework.BaseLibrary;
using EMP.Utilities;

namespace EMP.BusinessEntity
{
    [Connection(DatabaseConnnections.C_DEFAULT)]
    public class LimitToListBE : BaseEMPBusinessEntity<LimitToListBE>, ILimitToListBE
    {
        [Column("emp_limit_to_list_values_guid", true)]
        public int? LimitToListValuesGuid { get; set; }

        [Column("rms_field_guid")]
        public int RMSFieldGuid { get; set; }
        [Column("emp_scheme_guid")]
        public int EMPSchemeGuid { get; set; }
        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("schemename")]
        public string EMPSchemeName { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("Lookup")]
        public string LookUp { get; set; }
        [Column("Code")]
        public string Code { get; set; }
        //[Column("IFM2or4digitOcc")]
        //public string IFM2or4digitOcc { get; set; }
        [Column("ISO2ACountryCode")]
        public string ISO2ACountryCode { get; set; }
        [Column("active_ind")]
        public int ActiveInd { get; set; }
        [Column("order_num")]
        public int OrderNum { get; set; }
        [Column("bulk_option")]
        public bool BulkOption { get; set; }
        

        public override int? PrimaryKey
        {
            get
            {

                return this.LimitToListValuesGuid;
            }
            set
            {
                this.LimitToListValuesGuid = value;
            }
        }
    }
}
