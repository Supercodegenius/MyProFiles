﻿using EMP.Interfaces.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using XLCapital.XLRE.Framework.BaseLibrary;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_filedata_processing")]
    public class FileDataProcessingBE: BaseEMPAuditableBusinessEntity<FileDataProcessingBE>, IFileDataProcessingBE
    {
        [Column("emp_filedata_processing_guid", IsPrimaryKey = true, IsIdentifer = true)]
        public int? FileDataProcessingGuid { get; set; }
        [Column("emp_file_processing_task_guid",true)]
        public int? FileProcessingTaskGuid { get; set; }
        [Column("source_data")]
        public string SourceData { get; set; }
        [Column("stage_data")]
        public string StageData { get; set; }
        [Column("converted_data")]
        public string ConvertedData { get; set; }

        [Column("occupancy")]
        public string SelectedOccupancy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override int? PrimaryKey
        {
            get
            {

                return this.FileDataProcessingGuid;
            }
            set
            {
                this.FileDataProcessingGuid = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetPrimaryKeyID()
        {
            return 1;
        }

        public override void SetForeignKey(string argForeignKey, int? argForeignKeyValue)
        {
            switch (argForeignKey)
            {
                case "FileDataProcessingForiegnKey":
                    this.FileProcessingTaskGuid = argForeignKeyValue;
                    break;

            }
        }
        /// <summary>
        /// Returns the DAC object for the ReportHeader business Entity.
        /// This method returns instance of the BaseDataAccessComponent.
        /// </summary>
        /// <returns></returns>
        public override BaseDataAccessComponent GetDAC()
        {
            return base.GetDAC();
        }

        [Serializable]
        public class FileDataProcessingBECollection : List<FileDataProcessingBE>
        {
        }

    }
}
