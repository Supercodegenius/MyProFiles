﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;

namespace EMP.BusinessEntity
{
    [Table("t_emp_ifm_occupancy")]
    [Serializable]
    public class IFMOccupancyBE : BaseEMPAuditableBusinessEntity<IFMOccupancyBE>
    {
        [Column("emp_ifm_occupancy_guid")]
        public int? IfmOccGuid { get; set; }

        [Column("O_ATC")]
        public string O_ATC { get; set; }
        [Column("O_2digit")]
        public int? Occ2digit { get; set; }
        [Column("O_4digit")]
        public int Occ4digit { get; set; }

        [Column("structure")]
        public int? Structure { get; set; }
        [Column("contents")]
        public int? Contents { get; set; }

        //[Column("active_ind")]
        //public int ActiveInd { get; set; }

        public override int? PrimaryKey
        {
            get
            {

                return this.IfmOccGuid;
            }
            set
            {
                this.IfmOccGuid = value;
            }
        }

    }
}
