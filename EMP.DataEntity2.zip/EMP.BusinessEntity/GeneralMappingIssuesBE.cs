﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.DataAccessHelper;
using EMP.Utilities;
using EMP.Interfaces.BusinessEntity;

namespace EMP.BusinessEntity
{
    [Connection(DatabaseConnnections.C_DEFAULT)]
    public class GeneralMappingIssuesBE : BaseEMPAuditableBusinessEntity<GeneralMappingIssuesBE>, IGeneralMappingIssuesBE
    {
     
        [Column("rms_field_guid")]    
        public int ? RMSFieldGUID { get; set; }
        [Column("rms_field_name")]
        public string RMSFieldName { get; set; }
        [Column("description")]
        public string Description { get; set; }

        public override int? PrimaryKey
        {
            get
            {
                return this.RMSFieldGUID;
            }
            set
            {
                this.RMSFieldGUID = value;
            }
        }

    }
}
