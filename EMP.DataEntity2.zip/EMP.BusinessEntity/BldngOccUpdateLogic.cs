﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace EMP.BusinessEntity
{
    [XmlRoot(ElementName = "Target")]
    public class Target
    {
        [XmlElement(ElementName = "Column")]
        public string Column { get; set; }
        [XmlElement(ElementName = "Operator")]
        public string Operator { get; set; }
        [XmlElement(ElementName = "SourceColumn")]
        public string SourceColumn { get; set; }
        [XmlElement(ElementName = "Value")]
        public string Value { get; set; }
    }

    [XmlRoot(ElementName = "Filter")]
    public class Filter
    {
        [XmlElement(ElementName = "Column")]
        public string Column { get; set; }
        [XmlElement(ElementName = "Operator")]
        public string Operator { get; set; }
        [XmlElement(ElementName = "Value")]
        public string Value { get; set; }
        [XmlElement(ElementName = "ColumnName")]
        public string ColumnName { get; set; }
        [XmlElement(ElementName = "JoiningOperator")]
        public string JoiningOperator { get; set; }
    }

    [XmlRoot(ElementName = "Filters")]
    public class Filters
    {
        [XmlElement(ElementName = "Filter")]
        public List<Filter> Filter { get; set; }
    }

    [XmlRoot(ElementName = "FilterExpression")]
    public class FilterExpression
    {
        [XmlElement(ElementName = "Filters")]
        public Filters Filters { get; set; }
        [XmlElement(ElementName = "JoiningExpression")]
        public string JoiningExpression { get; set; }
    }

    [XmlRoot(ElementName = "UpdateLogic")]
    public class UpdateLogic
    {
        [XmlElement(ElementName = "Target")]
        public List<Target> Target { get; set; }
        [XmlElement(ElementName = "FilterExpression")]
        public List<FilterExpression> FilterExpression { get; set; }

        [XmlAttribute(AttributeName = "category")]
        public string Category { get; set; }
        [XmlAttribute(AttributeName = "order")]
        public string Order { get; set; }
    }

    [XmlRoot(ElementName = "BldOccUpdates")]
    public class BldOccUpdates
    {
        [XmlElement(ElementName = "UpdateLogic")]
        public List<UpdateLogic> UpdateLogic { get; set; }
    }

}
