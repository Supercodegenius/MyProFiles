﻿using EMP.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.Cache;

namespace EMP.DataProvider
{
    public class GetOccBldClassDataProvider :ICacheLoader
    {
        public object FetchData(string argKey)
        {
            return FetchData(argKey, null);
        }

        public object FetchData(string argKey, string argFilterDataValue)
        {
            var blo = new EMPBLO();
            return blo.GetOccBldClassValues();
        }
    }
}
