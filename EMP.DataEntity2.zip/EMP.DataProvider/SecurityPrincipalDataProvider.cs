﻿using System.Collections.Generic;
using System.Threading.Tasks;
using XLCapital.XLRE.Framework.Cache;
using EMP.BusinessEntity;
using EMP.BusinessLogic;
using EMP.Interfaces.BusinessEntity;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;

namespace EMP.DataProvider
{
    public class SecurityPrincipalDataProvider:ICacheLoader
    {
        //ICacheLoader
        public object FetchData(string argKey)
        {
            return FetchData(argKey, null);
        }

        public object FetchData(string argKey, string argFilterDataValue)
        {
            var blo = new EMPBLO();

            //principal
            var getUsers = Task<List<ISecurityPrincipalBE>>.Factory.StartNew(() =>
              {
                  return blo.RetrieveSecurityPrinciple(new SecurityPrincipalBE() { PrincipalType = "U" });
                 
              });

            ////user roles
            //var getRoles = Task.Factory.StartNew<List<IUserRoleBE>>(() =>
            //{
            //    return blo.RetrieveUserRole(new UserRoleBE());
            //});

             Task.WaitAll(new Task[] { getUsers });

            //object users = new object();
            var users = getUsers.Result;
           // var roles = getRoles.Result;

            //foreach (var user in users)
            //{
            //    user.Roles.AddRange(
            //            from role in roles
            //            where role.UserLoginId == user.LoginName
            //            select role.UserRole.ToUpper()
            //        );
            //}

            return users;
        }
    }
}
